# Разработка

## Устройство проекта

```
src/OAuthM2M.Client/
  ClientAuthMethod.cs, OAuthClientOptions.cs, OAuthClientOptionsValidator.cs   настройки и их проверка
  Security/       ключи и подпись: PrivateKeyLoader, KeyIdProvider, KeyPairGenerator, ClientAssertionFactory,
                  JwksExporter, ClientCertificateLoader, SecretMasker
  Tokens/         OAuthTokenClient: запрос client_credentials, разбор ответа и ошибок
  Transport/      HttpHandlerFactory (mTLS, доверенный УЦ), ServerCertificateValidator
  Nifi/           NiFiHttpClient: отправка JSON в NiFi
  Diagnostics/    PreflightRunner (doctor), ErrorAdvisor, JwtInspector, AnsiConsole и вывод отчёта
  ServiceCollectionExtensions.cs                                                  AddOAuthM2MClient
src/OAuthM2M.Cli/
  Program.cs      флаги, Serilog, диспетчер, коды возврата
  Commands/       ICommand, CommandDispatcher, run, init, assertion, doctor, CommandConfiguration
  Logging/        SerilogSetup
tests/OAuthM2M.Client.Tests/
```

Основная логика находится в библиотеке, CLI только разбирает аргументы и печатает результат.

## Поток запроса токена

1. `RunCommand` собирает конфигурацию и приводит пути к абсолютным.
2. `OAuthTokenClient` формирует форму `grant_type=client_credentials&client_id=...`.
3. В режиме `PrivateKeyJwt` `ClientAssertionFactory` подписывает JWT (RS256, `kid`, `iss`, `sub`, `aud`, `jti`, `iat`, `nbf`, `exp`)
   и клиент добавляет `client_assertion` и `client_assertion_type`. В режиме `TlsClientAuth` assertion нет,
   сертификат подключает `HttpHandlerFactory`.
4. Ответ разбирается в `TokenResponse`; при ошибке выбрасывается `TokenRequestException`
   с HTTP-статусом и полем `error`, по которым `ErrorAdvisor` подбирает подсказки.

## Как добавить команду

1. Создайте класс, реализующий `ICommand` (`Name`, `Description`, `ExecuteAsync`), в `src/OAuthM2M.Cli/Commands`.
2. Добавьте его в список команд в `Program.cs`.
3. Для чтения настроек без DI используйте `CommandConfiguration.LoadOptions(args)`.

## Тесты

```bash
dotnet test -c Release
dotnet test -c Release --filter "FullyQualifiedName~ClientAssertionFactoryTests"
```

Тесты используют временные ключи и сертификаты, сеть не нужна. Запросы к серверу подменяются
тестовым `HttpMessageHandler`. Покрыты: подпись и claims assertion, формат запроса в обоих режимах,
разбор ошибок, загрузка ключей и сертификатов, проверка УЦ сервера, генерация ключей, разбор JWT, подсказки.
Команды CLI автоматическими тестами не покрыты.

## Версии и пакеты

Версии пакетов заданы централизованно в `Directory.Packages.props`. Проект собирается под `net10.0`
(`Directory.Build.props`); для .NET 8 используйте `-p:TargetFramework=net8.0`. Для проверки обновлений:

```bash
dotnet list package --outdated
```

## Правила стиля

Настройки форматирования лежат в `.editorconfig` (отступы, file-scoped namespace, именование).
Комментарии пишутся по-русски и объясняют причину решения, а не пересказывают код.
