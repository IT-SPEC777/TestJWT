# Настройка Keycloak

Названия пунктов приведены для административной консоли Keycloak 26.x. В других версиях подписи могут отличаться.

## Локальный Keycloak для проверки

```bash
docker run --rm -p 5050:8080 \
  -e KC_BOOTSTRAP_ADMIN_USERNAME=admin -e KC_BOOTSTRAP_ADMIN_PASSWORD=admin \
  quay.io/keycloak/keycloak:26.0 start-dev
```

Консоль: http://localhost:5050 (admin / admin). Токен-эндпоинт realm `master`:
`http://localhost:5050/realms/master/protocol/openid-connect/token`. Адрес с `http` допускается только
для localhost и только в режиме `PrivateKeyJwt`; mTLS работает только по https.

## private_key_jwt

1. Подготовьте конфиг и ключ:

   ```bash
   cp config/keycloak.private_key_jwt.json config/local.json     # укажите TokenEndpoint, Audience, ClientId
   oauth-m2m init --config config/local.json
   ```

   Рядом с конфигом появятся `secrets/private.pem`, `secrets/private.public.pem` и `secrets/private.jwks.json`.

2. В Keycloak создайте клиента: Clients, Create client, тип OpenID Connect, Client ID такой же, как `OAuth:ClientId`.
   Включите Client authentication и в способах аутентификации оставьте только Service accounts roles.

3. Вкладка Credentials: Client Authenticator = Signed JWT.

4. Вкладка Keys. Публичный ключ можно передать двумя способами (набор зависит от версии):

   - по JWKS URL: опубликуйте `private.jwks.json` по адресу, доступному Keycloak, включите Use JWKS URL
     и укажите этот адрес. `kid` в документе совпадает с `kid` в JWT;
   - импортом: выключите Use JWKS URL и импортируйте ключ (Public Key PEM, JSON Web Key Set
     или Certificate PEM, если такие форматы есть в диалоге). Если нужен сертификат, выпускайте его
     в вашем УЦ на этот же ключ.

5. Вкладка Service accounts roles: назначьте сервисному аккаунту нужные роли.

6. Проверка и получение токена:

   ```bash
   oauth-m2m doctor --config config/local.json
   oauth-m2m run --config config/local.json
   ```

### Параметры, на которые стоит обратить внимание

- `Audience`. По умолчанию клиент отправляет в `aud` адрес токен-эндпоинта. Keycloak 26 принимает
  адрес токен-эндпоинта или issuer realm'а (`https://host/realms/<realm>`), причём `aud` должен быть одной строкой.
  Если сервер отвечает `invalid_client` и в описании есть `audience`, укажите `OAuth:Audience` равным issuer.
  `doctor` показывает issuer из discovery.
- `KeyId`. Если параметр пуст, `kid` вычисляется из ключа (RFC 7638). Он совпадает с `kid` в `private.jwks.json`.
  При импорте ключа напрямую Keycloak сам находит ключ клиента; при ошибке про ключ или подпись
  используйте JWKS URL, где `kid` задан явно.
- Время. JWT живёт 60-300 секунд, расхождение часов клиента и сервера в несколько секунд уже приводит к отказу.

## mTLS (X.509-аутентификация клиента)

Сертификат клиента должен быть выпущен УЦ, которому доверяет Keycloak.

1. Для тестового стенда можно создать тестовый УЦ и клиентский сертификат скриптом
   `scripts/gen-mtls-certs.sh` (OpenSSL; пароль PFX скрипт выводит в конце). Для рабочей среды используйте сертификат вашего УЦ.

2. Keycloak должен принимать https и запрашивать клиентский сертификат, например:

   ```bash
   kc.sh start \
     --https-certificate-file=/certs/server.crt --https-certificate-key-file=/certs/server.key \
     --https-client-auth=request \
     --https-trust-store-file=/certs/truststore.p12 --https-trust-store-password=<пароль> \
     --hostname=keycloak.example.local
   ```

   В хранилище доверия должен быть УЦ, выдавший клиентские сертификаты:

   ```bash
   keytool -importcert -alias m2m-ca -file ca.crt -keystore truststore.p12 -storetype PKCS12 -storepass <пароль>
   ```

   Флаги приведены для Keycloak 26.x. Если перед Keycloak стоит прокси или балансировщик, он должен
   передавать клиентский сертификат дальше (в Keycloak для этого настраивается провайдер x509cert-lookup,
   см. раздел про mTLS в документации Keycloak). Иначе сертификат до сервера не дойдёт и клиент получит `invalid_client`.

3. Создайте клиента (Client authentication включён, Service accounts roles) и в Credentials
   выберите Client Authenticator = X509 Certificate. В поле Subject DN укажите, например, `CN=my-service`
   (для регулярного выражения включите сравнение по шаблону).

4. Конфиг (`config/keycloak.mtls.json`):

   ```json
   {
     "OAuth": {
       "AuthMethod": "TlsClientAuth",
       "TokenEndpoint": "https://keycloak.example.local:8443/realms/demo/protocol/openid-connect/token",
       "ClientId": "my-service",
       "ClientCertificatePath": "secrets/mtls/client.pfx",
       "ServerCaCertificatePath": "secrets/ca.crt"
     }
   }
   ```

   Пароль PFX передайте переменной окружения: `export OAuth__ClientCertificatePassword='<пароль>'`.
   `ServerCaCertificatePath` нужен, если сертификат самого Keycloak выдан непубличным УЦ.

5. Запуск: `oauth-m2m run --config config/keycloak.mtls.json`.

## Проверка без клиента

```bash
curl -v --cacert secrets/ca.crt --cert secrets/mtls/client.crt --key secrets/mtls/client.key \
  -d grant_type=client_credentials -d client_id=my-service \
  https://keycloak.example.local:8443/realms/demo/protocol/openid-connect/token
```

Если curl получает токен, а клиент нет, сверяйте пути и пароли в конфиге. Если не получает и curl,
причина в настройке Keycloak или прокси.
