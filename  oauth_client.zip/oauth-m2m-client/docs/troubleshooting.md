# Диагностика ошибок

Начните с `oauth-m2m doctor --config <файл>`: он проверит конфигурацию, ключ и discovery-документ сервера.
При отказе сервера `run` печатает сообщение сервера и подсказки. Подробный журнал лежит в каталоге `logs`
рядом с программой; флаг `--verbose` выводит его на консоль.

| Симптом | Вероятная причина | Что сделать |
|---|---|---|
| `Ошибка конфигурации: ... не задан` | не заполнены обязательные параметры | заполните `TokenEndpoint`, `ClientId`, для JWT `PrivateKeyPath`; ключ создаёт `init` |
| `Файл приватного ключа не найден` | неверный путь | пути в конфиге считаются от каталога файла конфигурации; проверьте путь или запустите `init` |
| `invalid_client`, в описании signature, key или kid | на сервере зарегистрирован другой ключ | зарегистрируйте актуальный `private.jwks.json`; `kid` в JWT и в JWKS должен совпадать |
| `invalid_client`, в описании audience | `aud` не тот | задайте `OAuth:Audience`: `token_endpoint` или `issuer` из discovery (для Keycloak 26+ обычно issuer) |
| `invalid_client`, в описании expired или not yet valid | расхождение часов | синхронизируйте время (NTP) на клиенте и сервере |
| `invalid_client` при mTLS и верном сертификате | сертификат не дошёл до сервера или не сопоставился с клиентом | проверьте прокси и балансировщик (должны передавать сертификат), Subject DN в настройках клиента |
| `unauthorized_client` | клиенту не разрешён `client_credentials` | Keycloak: включите Service accounts roles; FAM: разрешите grant для клиента |
| `invalid_scope` | запрошен недоступный scope | уберите `OAuth:Scope` или назначьте scope клиенту |
| `Сетевая или TLS-ошибка: The SSL connection could not be established` | сервер подписан корпоративным УЦ | укажите УЦ в `OAuth:ServerCaCertificatePath` |
| ошибка имени хоста (`RemoteCertificateNameMismatch`) | адрес в URL не совпадает с SAN сертификата | используйте имя из сертификата; отключить эту проверку нельзя |
| `Размер ключа 1024 бит; требуется RSA-2048` | слишком короткий ключ | создайте новый: `init --force` |
| ошибка `ImportFromPem` про зашифрованный ключ | ключ зашифрован, пароль не задан | передайте `OAuth__PrivateKeyPassword` |
| `Таймаут запроса к серверу авторизации` | сеть, файрвол, прокси | проверьте доступность адреса, увеличьте `OAuth:HttpTimeoutSeconds` |
| `NiFi вернул 401` или `403` | NiFi не принял токен | проверьте настройку проверки токена на стороне NiFi |
| `NiFi: Сетевая или TLS-ошибка` | сертификат NiFi не доверенный | укажите УЦ в `NiFi:ServerCaCertificatePath` |
| `doctor`: не удалось получить discovery | нестандартный путь discovery или корпоративный УЦ | проверьте адрес вручную через curl; на работу `run` предупреждение не влияет |
| `NU1102` / `NU1101` при `dotnet restore` | пакет недоступен | проверьте `nuget.config` (зеркало) и версии в `Directory.Packages.props` |

## Содержимое client_assertion

```bash
oauth-m2m assertion --config config/local.json --Inspect=true
```

Заголовок должен содержать `alg=RS256` и `kid`, а `aud` должен совпадать с тем, что ожидает сервер.
Не вставляйте рабочие JWT в онлайн-сервисы.

## Ручной запрос

```bash
curl -v -d grant_type=client_credentials -d client_id=my-service \
  -d client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer \
  -d client_assertion="$(oauth-m2m assertion --config config/local.json)" \
  "<token_endpoint>"
```
