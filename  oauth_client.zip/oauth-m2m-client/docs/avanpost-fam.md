# Avanpost FAM

Публичной документации Avanpost FAM по настройке `private_key_jwt` и mTLS для OAuth-клиентов
найти не удалось, поэтому этот документ описывает требования к серверной стороне, а не последовательность
действий в интерфейсе. Названия разделов зависят от версии FAM: сверяйтесь с руководством администратора
или обратитесь к вендору.

## Что нужно узнать у сервера

Адреса и возможности сервера опубликованы в discovery-документе (путь зависит от настройки FAM):

```bash
curl -s https://fam.example.local/.well-known/openid-configuration
```

| Поле | Для чего |
|---|---|
| `token_endpoint` | значение для `OAuth:TokenEndpoint` |
| `issuer` | второй вариант для `OAuth:Audience` |
| `token_endpoint_auth_methods_supported` | должен содержать `private_key_jwt` (режим JWT) или `tls_client_auth` / `self_signed_tls_client_auth` (mTLS) |
| `token_endpoint_auth_signing_alg_values_supported` | должен содержать `RS256` |
| `grant_types_supported` | должен содержать `client_credentials` |

Если нужного метода в списке нет, режим на этом сервере не включён или не поддерживается этой версией.
`oauth-m2m doctor` сверяет конфиг с этими полями автоматически (при условии, что discovery доступен
по стандартному пути и не требует корпоративного УЦ, см. ограничения в README).

## private_key_jwt

На стороне FAM нужно:

1. Зарегистрировать конфиденциального клиента с `client_id`, равным `OAuth:ClientId`, и разрешить grant `client_credentials`.
2. Выбрать метод аутентификации клиента `private_key_jwt` и алгоритм подписи `RS256`.
3. Передать публичный ключ клиента. Доступные способы зависят от версии:
   - JWKS: файл `private.jwks.json`, который создаёт `oauth-m2m init`;
   - публичный ключ в PEM: `private.public.pem` из того же каталога;
   - сертификат: выпустите его в вашем УЦ на этот же ключ.
4. Выдать клиенту нужные scope и роли.

Клиент:

```bash
cp config/avanpost-fam.private_key_jwt.json config/local.json
# впишите TokenEndpoint, Audience (token_endpoint или issuer из discovery), ClientId,
# при необходимости ServerCaCertificatePath
oauth-m2m init --config config/local.json
oauth-m2m doctor --config config/local.json
oauth-m2m run --config config/local.json
```

`kid` в заголовке JWT должен совпадать с `kid` зарегистрированного ключа. Если `KeyId` в конфиге пуст,
он вычисляется из ключа и совпадает с `kid` в `private.jwks.json`. При ошибке `invalid_client`, связанной с `aud`,
попробуйте второе значение (`token_endpoint` или `issuer`).

## mTLS

На стороне FAM нужно:

1. Чтобы TLS на токен-эндпоинте запрашивал клиентский сертификат и доверял УЦ, выпустившему сертификат клиента.
2. Зарегистрировать клиента с методом `tls_client_auth` (сертификат, выданный УЦ) или
   `self_signed_tls_client_auth` (самоподписанный) и настроить сопоставление сертификата с клиентом
   (по Subject DN, SAN или отпечатку, как принято в вашем FAM).
3. Если перед FAM стоит прокси или балансировщик, он должен либо пропускать mTLS насквозь, либо проверять
   сертификат и передавать его в FAM, иначе сертификат до FAM не дойдёт.

Клиент:

```bash
cp config/avanpost-fam.mtls.json config/local.json
# впишите TokenEndpoint, пути к сертификату и ключу, ServerCaCertificatePath
oauth-m2m run --config config/local.json
```

Для PEM-пары укажите `ClientCertificatePath` и `ClientCertificateKeyPath`, для PFX
`ClientCertificatePath` и пароль в `OAuth__ClientCertificatePassword`.

## Проверка curl'ом

```bash
curl -v --cacert corp-root-ca.crt --cert client.crt --key client.key \
  -d grant_type=client_credentials -d client_id=my-service "<token_endpoint>"
```

Если curl работает, а клиент нет, сверяйте `ClientId`, формат сертификата и пути. Если не работает и curl,
вопрос в настройке FAM или прокси.
