# Отправка данных в NiFi

Команда `run` после получения токена может передать JSON-файл в Apache NiFi.
Отправка выполняется, только если заданы `NiFi:Endpoint` и `JsonPath`; иначе команда просто получает токен.

## Что делает клиент

- читает файл из `JsonPath` (относительный путь считается от каталога файла конфигурации);
- отправляет его POST-запросом на `NiFi:Endpoint` с `Content-Type: application/json`;
- передаёт токен в заголовке `Authorization: Bearer <access_token>`;
- считает успешным любой ответ 2xx; при другом статусе, сетевой или TLS-ошибке и таймауте завершается с кодом 1.

Адрес рассчитан на процессор HandleHttpRequest. Проверка токена выполняется на стороне NiFi
и в этот проект не входит: настройте её во flow (например, запросом к introspection-эндпоинту
сервера авторизации или проверкой подписи JWT).

## Настройка

```json
{
  "OAuth": { "...": "..." },
  "NiFi": {
    "Endpoint": "https://nifi.example.local:8443/data",
    "ServerCaCertificatePath": "secrets/nifi-ca.crt",
    "TimeoutSeconds": 30
  },
  "JsonPath": "payload.json"
}
```

Готовый пример: `config/nifi.example.json` и тестовый файл `config/payload.json`.

`NiFi:ServerCaCertificatePath` нужен, если сертификат NiFi выпущен непубличным УЦ. Проверка TLS при этом
остаётся включённой: УЦ добавляется как доверенный корень, но несовпадение имени хоста с сертификатом
считается ошибкой.

## FlowFile.proto

Файл `src/OAuthM2M.Client/Nifi/FlowFile.proto` описывает сообщение для процессора ListenGRPC. В сборку он
не подключён (нет пакетов gRPC и элемента `Protobuf` в проекте), данные уходят обычным HTTP.
Файл оставлен как справочный на случай перехода на gRPC.

## Запуск

```bash
oauth-m2m run --config config/local.json
```

Ожидаемый вывод после токена: `JSON отправлен в NiFi: <путь к файлу>`.
