# oauth-m2m-client

Консольный клиент OAuth 2.0 для обмена между сервисами: получает `access_token` по `client_credentials`
без `client_secret` и при необходимости передаёт JSON в Apache NiFi.

Клиент аутентифицируется на токен-эндпоинте одним из двух способов:

| Режим | Стандарт | Как клиент подтверждает себя |
|---|---|---|
| `PrivateKeyJwt` (по умолчанию) | RFC 7523 | JWT, подписанный приватным ключом, в параметре `client_assertion` |
| `TlsClientAuth` | RFC 8705 | клиентский сертификат при установке TLS-соединения (mTLS) |

Ориентирован на Keycloak. Для Avanpost FAM описан список требований к серверной стороне
(см. [docs/avanpost-fam.md](docs/avanpost-fam.md)).

## Состав репозитория

```
OAuthM2M.sln
src/OAuthM2M.Client/          библиотека: JWT, ключи, запрос токена, NiFi-клиент, диагностика
src/OAuthM2M.Cli/             консольное приложение oauth-m2m
tests/OAuthM2M.Client.Tests/  модульные тесты (xUnit)
config/                       примеры конфигурации
scripts/                      скрипты OpenSSL для тестового стенда
docs/                         подробная документация
gitflic-ci.yaml               конвейер GitFlic
```

## Требования

- .NET SDK 10. Проект собирается под `net10.0`. Для .NET 8 добавьте `-p:TargetFramework=net8.0`
  (поддержка .NET 8 завершилась 10 ноября 2026 года, для нового кода лучше .NET 10).
- Для проверки на локальном Keycloak нужен Docker.

## Сборка и тесты

```bash
dotnet restore
dotnet build -c Release
dotnet test -c Release
```

Тесты не обращаются к сети и внешним серверам.

## Быстрый старт

Ниже `oauth-m2m` означает `dotnet run --project src/OAuthM2M.Cli -c Release --`
или собранный файл из `publish/oauth-m2m`.

1. Скопируйте шаблон конфигурации и укажите адрес токен-эндпоинта и `ClientId`:

   ```bash
   cp config/keycloak.private_key_jwt.json config/local.json
   ```

2. Создайте ключ и допишите конфигурацию:

   ```bash
   oauth-m2m init --config config/local.json
   ```

   Команда создаст в каталоге `config/secrets` приватный ключ, публичный ключ и JWKS, а в конфиг
   добавит `KeyId` и `PrivateKeyPath`, если они были пустыми.

3. Зарегистрируйте публичный ключ на сервере авторизации (`config/secrets/private.jwks.json`,
   подробности в [docs/keycloak.md](docs/keycloak.md)).

4. Проверьте окружение и получите токен:

   ```bash
   oauth-m2m doctor --config config/local.json
   oauth-m2m run --config config/local.json
   ```

## Команды

Команда указывается первым аргументом. Если аргументов нет или первый начинается с `-`, выполняется `run`.

| Команда | Назначение |
|---|---|
| `run` | получить `access_token`; если заданы `NiFi:Endpoint` и `JsonPath`, отправить JSON в NiFi |
| `init` | создать пару ключей RSA-2048 и дописать `KeyId` и `PrivateKeyPath` в конфиг |
| `assertion` | сформировать `client_assertion` локально, без запроса к серверу |
| `doctor` | проверить конфигурацию, ключ и discovery-документ сервера |
| `help` | справка |

Общие параметры:

| Параметр | Описание |
|---|---|
| `--config <файл>` или `--config=<файл>` | файл конфигурации (JSON) |
| `--Секция:Ключ=значение` | переопределить параметр, например `--OAuth:ClientId=my-service` |
| `--force` | `init`: перезаписать существующий ключ |
| `--Inspect=true` | `assertion`: показать заголовок и claims вместо готовой строки JWT |
| `--verbose` | подробный журнал (уровень Debug) |
| `--no-color` | без цветов; учитывается и переменная окружения `NO_COLOR` |

Параметры со значением указывайте в форме `--имя=значение` либо `--config <файл>`.

`assertion` без `--Inspect=true` печатает только JWT, поэтому результат можно подставить в curl:

```bash
curl -sS -X POST "$TOKEN_ENDPOINT" \
  -d grant_type=client_credentials \
  -d client_id=my-service \
  -d client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer \
  -d client_assertion="$(oauth-m2m assertion --config config/local.json)"
```

Опасайтесь `--force`: старый приватный ключ после перезаписи восстановить нельзя,
а зарегистрированный на сервере JWKS придётся заменить.

## Конфигурация

Источники по возрастанию приоритета:

1. `appsettings.json` рядом с программой;
2. файл из `--config`;
3. переменные окружения (вместо `:` используется `__`, например `OAuth__ClientId`);
4. аргументы командной строки.

Относительные пути к ключам и сертификатам (секция `OAuth`) и к `NiFi:ServerCaCertificatePath` считаются от каталога файла
конфигурации, а при запуске без `--config` от текущего каталога. `JsonPath` в `run` считается от каталога файла конфигурации.

### Секция OAuth

| Параметр | Режим | Описание |
|---|---|---|
| `TokenEndpoint` | оба | адрес токен-эндпоинта; только https, http допускается для localhost (кроме mTLS) |
| `ClientId` | оба | идентификатор клиента |
| `AuthMethod` | оба | `PrivateKeyJwt` или `TlsClientAuth` |
| `Scope` | оба | необязательный список scope через пробел |
| `PrivateKeyPath` | JWT | приватный ключ в PEM |
| `KeyId` | JWT | необязателен: если пуст, вычисляется из ключа по RFC 7638 и совпадает с `kid` в созданном JWKS |
| `Audience` | JWT | необязателен: если пуст, используется `TokenEndpoint` (для Keycloak 26+ может понадобиться issuer) |
| `PrivateKeyPassword` | JWT | пароль зашифрованного ключа; лучше передавать переменной окружения |
| `AssertionLifetimeSeconds` | JWT | срок жизни assertion, 60-300; в коде 120, в `appsettings.json` 300 |
| `ClientCertificatePath` | mTLS | `.pfx`/`.p12` либо PEM-сертификат |
| `ClientCertificateKeyPath` | mTLS | ключ, если сертификат в PEM |
| `ClientCertificatePassword` | mTLS | пароль к PFX или к зашифрованному ключу |
| `ServerCaCertificatePath` | оба | УЦ сервера (PEM или DER), если его нет в системном хранилище |
| `HttpTimeoutSeconds` | оба | таймаут запроса, по умолчанию 30 |

Проверка TLS не отключается. `ServerCaCertificatePath` добавляет доверенный корень, но несовпадение имени
хоста с сертификатом остаётся ошибкой.

### NiFi и JsonPath

| Параметр | Описание |
|---|---|
| `NiFi:Endpoint` | адрес процессора HandleHttpRequest; если пуст, отправка не выполняется |
| `NiFi:ServerCaCertificatePath` | УЦ сервера NiFi |
| `NiFi:TimeoutSeconds` | таймаут запроса, по умолчанию 30 |
| `JsonPath` | файл с JSON, который отправляется в NiFi |

Пример: `config/nifi.example.json`. Подробности: [docs/nifi.md](docs/nifi.md).

## Журнал

Журнал ведёт Serilog. Файлы `oauth-m2m-ГГГГММДД.log` создаются в каталоге `logs` рядом с программой
(если туда нельзя писать, во временном каталоге), хранятся 14 дней. В файл пишутся сообщения от уровня Information,
на консоль только предупреждения и ошибки. С `--verbose` уровень снижается до Debug. Токены, ключи и assertion в журнал
не попадают.

## Коды возврата

| Код | Значение |
|---|---|
| 0 | успех |
| 1 | ошибка выполнения (сервер, сеть, ключ) или `doctor` нашёл ошибки |
| 2 | ошибка конфигурации или неизвестная команда |
| 130 | отмена по Ctrl+C |

## Документация

- [docs/keycloak.md](docs/keycloak.md): настройка Keycloak: private_key_jwt и mTLS;
- [docs/avanpost-fam.md](docs/avanpost-fam.md): требования к Avanpost FAM;
- [docs/nifi.md](docs/nifi.md): отправка данных в NiFi;
- [docs/troubleshooting.md](docs/troubleshooting.md): разбор типичных ошибок;
- [docs/development.md](docs/development.md): устройство проекта, тесты, CI, добавление команд;
- [CHANGELOG.md](CHANGELOG.md): что изменено относительно предыдущей версии.

## CI и публикация в GitFlic

В репозитории есть `gitflic-ci.yaml` (сборка, тесты с покрытием, публикация CLI). Нужен агент GitFlic
с Docker и доступом к `mcr.microsoft.com` и NuGet; в закрытом контуре замените образ и источник пакетов
в `nuget.config`.

```bash
git init -b main
git add .
git status   # убедитесь, что secrets/, logs/, *.pem, *.pfx, *.key не попали в индекс
git commit -m "Initial commit"
git remote add origin https://gitflic.ru/project/<владелец>/<проект>.git
git push -u origin main
```

## Безопасность

- Приватные ключи и сертификаты не хранятся в репозитории: `.gitignore` исключает `secrets/`, `*.pem`, `*.key`,
  `*.pfx`, `*.p12`. Перед коммитом проверяйте `git status`.
- Ключ, созданный `init`, на Unix получает права 0600.
- Пароли передавайте переменными окружения или секретами CI, не записывайте в конфиг.
- Если ключ попадал в репозиторий, почту или чат, замените его (`init --force`) и зарегистрируйте новый JWKS.
- Для рабочей среды ключ лучше держать вне репозитория и образа (смонтированный секрет, Vault).
  Интерфейс `IClientAssertionFactory` позволяет заменить подпись на внешнюю.
- Следите за точным временем на хосте: расхождение с сервером даёт отказ по `exp`/`nbf`.

## Известные ограничения

- `doctor` запрашивает discovery обычным HttpClient без пользовательского УЦ и без клиентского
  сертификата. Для серверов с корпоративным УЦ проверка может завершиться предупреждением, на работу `run` это не влияет.
- `doctor` не проверяет клиентский сертификат и TLS-рукопожатие, только конфигурацию, ключ (для JWT) и discovery.
- `init` не использует существующий ключ: если файл `secrets/private.pem` уже есть, нужен `--force`,
  либо укажите `PrivateKeyPath` вручную.
- Токен не кэшируется: каждый запуск `run` запрашивает новый.
- Файл `src/OAuthM2M.Client/Nifi/FlowFile.proto` не подключён к сборке (см. [docs/nifi.md](docs/nifi.md)).
