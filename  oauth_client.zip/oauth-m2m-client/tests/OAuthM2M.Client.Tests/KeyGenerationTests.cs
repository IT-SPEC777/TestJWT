using System.Security.Cryptography;
using System.Text.Json;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Client.Tests;

public sealed class KeyGenerationTests
{
    [Fact]
    public void Thumbprint_is_stable_for_a_key_and_differs_between_keys()
    {
        using var firstKey = RSA.Create(2048);
        using var secondKey = RSA.Create(2048);

        var first = KeyIdProvider.ComputeThumbprint(firstKey);

        Assert.Equal(first, KeyIdProvider.ComputeThumbprint(firstKey));
        Assert.NotEqual(first, KeyIdProvider.ComputeThumbprint(secondKey));
    }

    [Fact]
    public void Thumbprint_is_a_base64url_sha256_value()
    {
        using var key = RSA.Create(2048);

        var thumbprint = KeyIdProvider.ComputeThumbprint(key);

        // 32 байта SHA-256 в Base64Url без заполнения дают 43 символа.
        Assert.Equal(43, thumbprint.Length);
        Assert.DoesNotContain('=', thumbprint);
        Assert.DoesNotContain('+', thumbprint);
        Assert.DoesNotContain('/', thumbprint);
    }

    [Fact]
    public void Generator_creates_a_loadable_key_a_public_key_and_a_jwks()
    {
        using var directory = new TempDir();

        var artifacts = KeyPairGenerator.Generate(directory.FileIn("private.pem"));

        using var loadedKey = PrivateKeyLoader.Load(artifacts.PrivateKeyPath);
        Assert.Equal(2048, loadedKey.KeySize);
        Assert.Equal(KeyIdProvider.ComputeThumbprint(loadedKey), artifacts.KeyId);
        Assert.StartsWith("-----BEGIN PUBLIC KEY-----", File.ReadAllText(artifacts.PublicKeyPath));

        using var jwks = JsonDocument.Parse(File.ReadAllText(artifacts.JwksPath));
        Assert.Equal(artifacts.KeyId, jwks.RootElement.GetProperty("keys")[0].GetProperty("kid").GetString());
    }

    [Fact]
    public void Generator_does_not_overwrite_an_existing_key_without_the_flag()
    {
        using var directory = new TempDir();
        KeyPairGenerator.Generate(directory.FileIn("private.pem"));

        var exception = Assert.Throws<IOException>(() => KeyPairGenerator.Generate(directory.FileIn("private.pem")));

        Assert.Contains("--force", exception.Message);
    }

    [Fact]
    public void Generator_overwrites_with_the_flag_and_produces_a_different_key()
    {
        using var directory = new TempDir();
        var first = KeyPairGenerator.Generate(directory.FileIn("private.pem"));

        var second = KeyPairGenerator.Generate(directory.FileIn("private.pem"), overwrite: true);

        Assert.NotEqual(first.KeyId, second.KeyId);
    }

    [Fact]
    public void Generator_honours_an_explicit_kid_and_a_password()
    {
        using var directory = new TempDir();

        var artifacts = KeyPairGenerator.Generate(
            directory.FileIn("private.pem"), overwrite: false, keyId: "my-key-1", privateKeyPassword: "s3cret");

        Assert.Equal("my-key-1", artifacts.KeyId);
        Assert.Contains("ENCRYPTED PRIVATE KEY", File.ReadAllText(artifacts.PrivateKeyPath));
        using var loadedKey = PrivateKeyLoader.Load(artifacts.PrivateKeyPath, "s3cret");
        Assert.Equal(2048, loadedKey.KeySize);
    }

    [Fact]
    public void Generated_private_key_is_readable_only_by_the_owner_on_unix()
    {
        if (OperatingSystem.IsWindows())
        {
            return;   // права доступа POSIX на Windows не применяются
        }

        using var directory = new TempDir();
        var artifacts = KeyPairGenerator.Generate(directory.FileIn("private.pem"));

        Assert.Equal(UnixFileMode.UserRead | UnixFileMode.UserWrite, File.GetUnixFileMode(artifacts.PrivateKeyPath));
    }
}
