using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using OAuthM2M.Client.Security;
using OAuthM2M.Client.Transport;

namespace OAuthM2M.Client.Tests;

public sealed class CertificateAndTransportTests
{
    private static OAuthClientOptions MtlsOptions(string certificatePath) => new()
    {
        AuthMethod = ClientAuthMethod.TlsClientAuth,
        TokenEndpoint = TestKeys.TokenEndpoint,
        ClientId = "my-service",
        ClientCertificatePath = certificatePath
    };

    [Fact]
    public void Loads_pfx_with_a_private_key()
    {
        using var directory = new TempDir();
        var files = TestKeys.WriteSelfSignedCertificate(directory, "pfx-pass");
        var options = MtlsOptions(files.PfxPath);
        options.ClientCertificatePassword = "pfx-pass";

        using var certificate = ClientCertificateLoader.Load(options);

        Assert.True(certificate.HasPrivateKey);
        Assert.Equal("CN=my-service", certificate.Subject);
    }

    [Fact]
    public void Loads_a_pem_pair_with_a_private_key()
    {
        using var directory = new TempDir();
        var files = TestKeys.WriteSelfSignedCertificate(directory);
        var options = MtlsOptions(files.CertificatePath);
        options.ClientCertificateKeyPath = files.KeyPath;

        using var certificate = ClientCertificateLoader.Load(options);

        Assert.True(certificate.HasPrivateKey);
    }

    [Fact]
    public void A_pem_certificate_without_a_key_path_is_rejected()
    {
        using var directory = new TempDir();
        var files = TestKeys.WriteSelfSignedCertificate(directory);

        Assert.Throws<InvalidOperationException>(() => ClientCertificateLoader.Load(MtlsOptions(files.CertificatePath)));
    }

    [Fact]
    public void A_missing_certificate_file_fails()
    {
        using var directory = new TempDir();

        Assert.Throws<FileNotFoundException>(() => ClientCertificateLoader.Load(MtlsOptions(directory.FileIn("none.pfx"))));
    }

    [Fact]
    public void A_wrong_pfx_password_fails()
    {
        using var directory = new TempDir();
        var files = TestKeys.WriteSelfSignedCertificate(directory, "pfx-pass");
        var options = MtlsOptions(files.PfxPath);
        options.ClientCertificatePassword = "wrong";

        Assert.ThrowsAny<CryptographicException>(() => ClientCertificateLoader.Load(options));
    }

    [Fact]
    public void Mtls_handler_carries_the_client_certificate()
    {
        using var directory = new TempDir();
        var files = TestKeys.WriteSelfSignedCertificate(directory, "pfx-pass");
        var options = MtlsOptions(files.PfxPath);
        options.ClientCertificatePassword = "pfx-pass";

        using var handler = HttpHandlerFactory.Create(options);

        Assert.Equal(1, handler.SslOptions.ClientCertificates?.Count);
    }

    [Fact]
    public void PrivateKeyJwt_handler_has_no_client_certificate()
    {
        using var handler = HttpHandlerFactory.Create(TestKeys.JwtOptions("/unused.pem"));

        Assert.True(handler.SslOptions.ClientCertificates is null or { Count: 0 });
    }

    [Fact]
    public void A_custom_server_ca_installs_a_validation_callback()
    {
        using var directory = new TempDir();
        var pki = TestKeys.WriteCertificateIssuedByCa(directory);
        var options = TestKeys.JwtOptions("/unused.pem");
        options.ServerCaCertificatePath = pki.CaCertificatePath;

        using var handler = HttpHandlerFactory.Create(options);

        Assert.NotNull(handler.SslOptions.RemoteCertificateValidationCallback);
    }

    [Fact]
    public void A_missing_server_ca_file_fails()
    {
        using var directory = new TempDir();
        var options = TestKeys.JwtOptions("/unused.pem");
        options.ServerCaCertificatePath = directory.FileIn("ca.crt");

        Assert.Throws<FileNotFoundException>(() => HttpHandlerFactory.Create(options));
    }

    // ----- ServerCertificateValidator -----

    [Fact]
    public void Validator_accepts_a_certificate_issued_by_the_custom_ca()
    {
        using var directory = new TempDir();
        var pki = TestKeys.WriteCertificateIssuedByCa(directory);
        using var authority = TestKeys.LoadCertificate(pki.CaCertificatePath);
        using var leaf = TestKeys.LoadCertificate(pki.LeafCertificatePath);
        using var platformChain = new X509Chain();
        platformChain.Build(leaf);   // системное хранилище тестовому УЦ не доверяет

        var trusted = ServerCertificateValidator.IsTrusted(
            leaf, platformChain, SslPolicyErrors.RemoteCertificateChainErrors, new X509Certificate2Collection(authority));

        Assert.True(trusted);
    }

    [Fact]
    public void Validator_rejects_an_untrusted_certificate_without_custom_roots()
    {
        using var directory = new TempDir();
        var pki = TestKeys.WriteCertificateIssuedByCa(directory);
        using var leaf = TestKeys.LoadCertificate(pki.LeafCertificatePath);
        using var platformChain = new X509Chain();
        platformChain.Build(leaf);

        Assert.False(ServerCertificateValidator.IsTrusted(
            leaf, platformChain, SslPolicyErrors.RemoteCertificateChainErrors, customRoots: null));
    }

    [Fact]
    public void Validator_does_not_forgive_a_host_name_mismatch()
    {
        using var directory = new TempDir();
        var pki = TestKeys.WriteCertificateIssuedByCa(directory);
        using var authority = TestKeys.LoadCertificate(pki.CaCertificatePath);
        using var leaf = TestKeys.LoadCertificate(pki.LeafCertificatePath);
        using var platformChain = new X509Chain();
        platformChain.Build(leaf);

        var errors = SslPolicyErrors.RemoteCertificateChainErrors | SslPolicyErrors.RemoteCertificateNameMismatch;

        Assert.False(ServerCertificateValidator.IsTrusted(leaf, platformChain, errors, new X509Certificate2Collection(authority)));
    }

    [Fact]
    public void Validator_accepts_when_the_platform_reports_no_errors()
    {
        Assert.True(ServerCertificateValidator.IsTrusted(null, null, SslPolicyErrors.None, customRoots: null));
    }
}
