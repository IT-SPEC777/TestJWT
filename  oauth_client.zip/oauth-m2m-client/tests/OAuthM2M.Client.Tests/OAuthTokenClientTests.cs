using System.Net;
using System.Text;
using System.Web;
using Microsoft.Extensions.Logging.Abstractions;
using OAuthM2M.Client.Security;
using OAuthM2M.Client.Tokens;

namespace OAuthM2M.Client.Tests;

public sealed class OAuthTokenClientTests
{
    private const string SuccessJson = """{"access_token":"abc.def.ghi","expires_in":300,"token_type":"Bearer"}""";

    /// <summary>Запрос, который получил подставной «сервер».</summary>
    private sealed record ReceivedRequest(HttpMethod Method, Uri? Uri, string? ContentType, string Body);

    /// <summary>Подставной обработчик: запоминает запросы и возвращает заранее заданный ответ.</summary>
    private sealed class StubHandler(Func<HttpResponseMessage> createResponse) : HttpMessageHandler
    {
        public List<ReceivedRequest> Requests { get; } = [];

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            // Тело читается здесь: после возврата HttpClient освобождает запрос.
            var body = request.Content is null ? string.Empty : await request.Content.ReadAsStringAsync(cancellationToken);
            Requests.Add(new ReceivedRequest(request.Method, request.RequestUri, request.Content?.Headers.ContentType?.MediaType, body));
            return createResponse();
        }
    }

    /// <summary>Обработчик, который сразу бросает заданное исключение (сетевая ошибка, таймаут).</summary>
    private sealed class ThrowingHandler(Exception exceptionToThrow) : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken) =>
            throw exceptionToThrow;
    }

    /// <summary>Подставная фабрика assertion: считает вызовы и возвращает предсказуемые значения.</summary>
    private sealed class FakeAssertionFactory : IClientAssertionFactory
    {
        public int CreateCallCount { get; private set; }

        public string Create() => $"signed.jwt.{++CreateCallCount}";
    }

    private static HttpResponseMessage JsonResponse(HttpStatusCode status, string json) =>
        new(status) { Content = new StringContent(json, Encoding.UTF8, "application/json") };

    private static OAuthTokenClient CreateClient(HttpMessageHandler handler, OAuthClientOptions options, IClientAssertionFactory assertionFactory) =>
        new(new HttpClient(handler), assertionFactory, TestKeys.Wrap(options), NullLogger<OAuthTokenClient>.Instance);

    private static OAuthClientOptions JwtOptions() => TestKeys.JwtOptions("/unused.pem");

    private static OAuthClientOptions MtlsOptions() => new()
    {
        AuthMethod = ClientAuthMethod.TlsClientAuth,
        TokenEndpoint = TestKeys.TokenEndpoint,
        ClientId = "my-service",
        ClientCertificatePath = "/unused.pfx"
    };

    [Fact]
    public async Task PrivateKeyJwt_sends_expected_form_and_parses_the_response()
    {
        var handler = new StubHandler(() => JsonResponse(HttpStatusCode.OK, SuccessJson));
        var client = CreateClient(handler, JwtOptions(), new FakeAssertionFactory());

        var token = await client.RequestTokenAsync();

        var request = Assert.Single(handler.Requests);
        Assert.Equal(HttpMethod.Post, request.Method);
        Assert.Equal(TestKeys.TokenEndpoint, request.Uri!.ToString());
        Assert.Equal("application/x-www-form-urlencoded", request.ContentType);

        var form = HttpUtility.ParseQueryString(request.Body);
        Assert.Equal("client_credentials", form["grant_type"]);
        Assert.Equal("my-service", form["client_id"]);
        Assert.Equal("urn:ietf:params:oauth:client-assertion-type:jwt-bearer", form["client_assertion_type"]);
        Assert.Equal("signed.jwt.1", form["client_assertion"]);
        Assert.Null(form["client_secret"]);

        Assert.Equal("abc.def.ghi", token.AccessToken);
        Assert.Equal(300, token.ExpiresIn);
        Assert.Equal("Bearer", token.TokenType);
    }

    [Fact]
    public async Task Mtls_mode_sends_no_assertion_and_does_not_touch_the_key()
    {
        var handler = new StubHandler(() => JsonResponse(HttpStatusCode.OK, SuccessJson));
        var assertions = new FakeAssertionFactory();
        var client = CreateClient(handler, MtlsOptions(), assertions);

        await client.RequestTokenAsync();

        var form = HttpUtility.ParseQueryString(Assert.Single(handler.Requests).Body);
        Assert.Equal("client_credentials", form["grant_type"]);
        Assert.Equal("my-service", form["client_id"]);
        Assert.Null(form["client_assertion"]);
        Assert.Null(form["client_assertion_type"]);
        Assert.Null(form["client_secret"]);
        Assert.Equal(0, assertions.CreateCallCount);
    }

    [Fact]
    public async Task Scope_is_sent_when_configured()
    {
        var handler = new StubHandler(() => JsonResponse(HttpStatusCode.OK, SuccessJson));
        var options = JwtOptions();
        options.Scope = "api.read api.write";
        var client = CreateClient(handler, options, new FakeAssertionFactory());

        await client.RequestTokenAsync();

        var form = HttpUtility.ParseQueryString(Assert.Single(handler.Requests).Body);
        Assert.Equal("api.read api.write", form["scope"]);
    }

    [Fact]
    public async Task A_new_assertion_is_created_for_every_request()
    {
        var handler = new StubHandler(() => JsonResponse(HttpStatusCode.OK, SuccessJson));
        var assertions = new FakeAssertionFactory();
        var client = CreateClient(handler, JwtOptions(), assertions);

        await client.RequestTokenAsync();
        await client.RequestTokenAsync();

        Assert.Equal(2, assertions.CreateCallCount);
        Assert.NotEqual(
            HttpUtility.ParseQueryString(handler.Requests[0].Body)["client_assertion"],
            HttpUtility.ParseQueryString(handler.Requests[1].Body)["client_assertion"]);
    }

    [Fact]
    public async Task Error_response_exposes_status_and_oauth_error()
    {
        var handler = new StubHandler(() => JsonResponse(
            HttpStatusCode.Unauthorized,
            """{"error":"invalid_client","error_description":"Invalid client or Invalid client credentials"}"""));
        var client = CreateClient(handler, JwtOptions(), new FakeAssertionFactory());

        var exception = await Assert.ThrowsAsync<TokenRequestException>(() => client.RequestTokenAsync());

        Assert.Equal(401, exception.StatusCode);
        Assert.Equal("invalid_client", exception.Error);
        Assert.Contains("Invalid client", exception.Message);
    }

    [Fact]
    public async Task Non_json_error_body_is_included_in_the_message()
    {
        var handler = new StubHandler(() => new HttpResponseMessage(HttpStatusCode.BadGateway)
        {
            Content = new StringContent("<html>bad gateway</html>")
        });
        var client = CreateClient(handler, JwtOptions(), new FakeAssertionFactory());

        var exception = await Assert.ThrowsAsync<TokenRequestException>(() => client.RequestTokenAsync());

        Assert.Equal(502, exception.StatusCode);
        Assert.Null(exception.Error);
        Assert.Contains("bad gateway", exception.Message);
    }

    [Fact]
    public async Task Invalid_json_in_a_successful_response_fails()
    {
        var handler = new StubHandler(() => JsonResponse(HttpStatusCode.OK, "not json"));
        var client = CreateClient(handler, JwtOptions(), new FakeAssertionFactory());

        await Assert.ThrowsAsync<TokenRequestException>(() => client.RequestTokenAsync());
    }

    [Fact]
    public async Task Response_without_access_token_fails()
    {
        var handler = new StubHandler(() => JsonResponse(HttpStatusCode.OK, """{"expires_in":300}"""));
        var client = CreateClient(handler, JwtOptions(), new FakeAssertionFactory());

        var exception = await Assert.ThrowsAsync<TokenRequestException>(() => client.RequestTokenAsync());

        Assert.Contains("access_token", exception.Message);
    }

    [Fact]
    public async Task Network_error_is_wrapped()
    {
        var client = CreateClient(
            new ThrowingHandler(new HttpRequestException("connection refused")), JwtOptions(), new FakeAssertionFactory());

        var exception = await Assert.ThrowsAsync<TokenRequestException>(() => client.RequestTokenAsync());

        Assert.Null(exception.StatusCode);
        Assert.IsType<HttpRequestException>(exception.InnerException);
    }

    [Fact]
    public async Task Timeout_is_reported_as_a_token_request_failure()
    {
        var client = CreateClient(
            new ThrowingHandler(new TaskCanceledException("timeout")), JwtOptions(), new FakeAssertionFactory());

        var exception = await Assert.ThrowsAsync<TokenRequestException>(() => client.RequestTokenAsync());

        Assert.Contains("Таймаут", exception.Message);
    }

    [Fact]
    public async Task Cancellation_requested_by_the_caller_is_not_wrapped()
    {
        using var cancellation = new CancellationTokenSource();
        await cancellation.CancelAsync();
        var client = CreateClient(
            new ThrowingHandler(new OperationCanceledException(cancellation.Token)), JwtOptions(), new FakeAssertionFactory());

        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => client.RequestTokenAsync(cancellation.Token));
    }
}
