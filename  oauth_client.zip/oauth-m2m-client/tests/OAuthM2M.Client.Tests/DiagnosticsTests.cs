using System.IdentityModel.Tokens.Jwt;
using System.Text.Json;
using Microsoft.IdentityModel.Tokens;
using OAuthM2M.Client.Diagnostics;
using OAuthM2M.Client.Tokens;

namespace OAuthM2M.Client.Tests;

public sealed class JwtInspectorTests
{
    [Fact]
    public void Decodes_header_and_payload_without_verifying_the_signature()
    {
        // Подпись произвольным симметричным ключом: инспектору она не нужна.
        var signingKey = new SymmetricSecurityKey(new byte[32]);
        var credentials = new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256);
        var token = new JwtSecurityTokenHandler().WriteToken(new JwtSecurityToken(
            issuer: "issuer-1",
            audience: "aud-1",
            claims: null,
            notBefore: DateTime.UtcNow,
            expires: DateTime.UtcNow.AddMinutes(5),
            signingCredentials: credentials));

        Assert.True(JwtInspector.TryInspect(token, out var inspected));

        Assert.Equal("issuer-1", JwtInspector.GetString(inspected!.Payload, "iss"));
        Assert.Equal("HS256", JwtInspector.GetString(inspected.Header, "alg"));
    }

    [Theory]
    [InlineData("opaque-token")]
    [InlineData("a.b")]
    [InlineData("")]
    [InlineData(null)]
    public void Values_that_are_not_jwt_are_rejected(string? value) =>
        Assert.False(JwtInspector.TryInspect(value, out var inspected) && inspected is not null);

    [Fact]
    public void Reads_numeric_dates_and_formats_arrays()
    {
        var header = Base64UrlEncoder.Encode("""{"alg":"none"}""");
        var payload = Base64UrlEncoder.Encode("""{"exp":1767225600,"aud":["a","b"]}""");

        Assert.True(JwtInspector.TryInspect($"{header}.{payload}.signature", out var inspected));

        Assert.True(JwtInspector.TryGetUnixTime(inspected!.Payload, "exp", out var moment));
        Assert.Equal(DateTimeOffset.FromUnixTimeSeconds(1767225600), moment);
        Assert.Equal("a, b", JwtInspector.Format(inspected.Payload.GetProperty("aud")));
    }

    [Fact]
    public void Missing_claims_return_null_or_false()
    {
        using var document = JsonDocument.Parse("""{"iss":"x"}""");

        Assert.Null(JwtInspector.GetString(document.RootElement, "aud"));
        Assert.False(JwtInspector.TryGetUnixTime(document.RootElement, "exp", out var moment));
        Assert.Equal(default, moment);
    }
}

public sealed class ErrorAdvisorTests
{
    private static OAuthClientOptions JwtOptions() => TestKeys.JwtOptions("/unused.pem");

    [Fact]
    public void Invalid_client_in_jwt_mode_mentions_audience_and_the_jwks_file()
    {
        var exception = new TokenRequestException("отказ", 401, "invalid_client");

        var hints = ErrorAdvisor.Advise(exception, JwtOptions());

        Assert.Contains(hints, hint => hint.Contains("OAuth:Audience"));
        Assert.Contains(hints, hint => hint.Contains("jwks.json"));
    }

    [Fact]
    public void Invalid_client_in_mtls_mode_does_not_mention_jwt_settings()
    {
        var options = new OAuthClientOptions { AuthMethod = ClientAuthMethod.TlsClientAuth };
        var exception = new TokenRequestException("отказ", 401, "invalid_client");

        var hints = ErrorAdvisor.Advise(exception, options);

        Assert.Contains(hints, hint => hint.Contains("mTLS"));
        Assert.DoesNotContain(hints, hint => hint.Contains("OAuth:Audience"));
    }

    [Fact]
    public void Unauthorized_client_points_to_the_client_credentials_grant()
    {
        var exception = new TokenRequestException("отказ", 400, "unauthorized_client");

        Assert.Contains(ErrorAdvisor.Advise(exception, JwtOptions()), hint => hint.Contains("client_credentials"));
    }

    [Fact]
    public void Tls_failure_points_to_the_server_ca_setting()
    {
        var exception = new TokenRequestException("Сетевая или TLS-ошибка: The SSL connection could not be established");

        Assert.Contains(ErrorAdvisor.Advise(exception, JwtOptions()), hint => hint.Contains("ServerCaCertificatePath"));
    }
}
