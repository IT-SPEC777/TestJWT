using System.Text.Json;
using Microsoft.IdentityModel.Tokens;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Client.Tests;

public sealed class JwksExporterTests
{
    [Fact]
    public void Exports_only_public_parameters_with_configured_kid()
    {
        using var directory = new TempDir();
        var (keyPath, key) = TestKeys.WritePrivateKey(directory);
        using var keyOwner = key;

        var json = JwksExporter.ExportPublicJwks(TestKeys.JwtOptions(keyPath));

        using var document = JsonDocument.Parse(json);
        var jwk = document.RootElement.GetProperty("keys")[0];
        Assert.Equal("RSA", jwk.GetProperty("kty").GetString());
        Assert.Equal("RS256", jwk.GetProperty("alg").GetString());
        Assert.Equal("sig", jwk.GetProperty("use").GetString());
        Assert.Equal("key-1", jwk.GetProperty("kid").GetString());

        var expected = key.ExportParameters(includePrivateParameters: false);
        Assert.Equal(Base64UrlEncoder.Encode(expected.Modulus!), jwk.GetProperty("n").GetString());
        Assert.Equal(Base64UrlEncoder.Encode(expected.Exponent!), jwk.GetProperty("e").GetString());

        foreach (var privateField in new[] { "d", "p", "q", "dp", "dq", "qi" })
        {
            Assert.False(jwk.TryGetProperty(privateField, out var unexpected), $"в JWKS не должно быть поля {privateField} ({unexpected})");
        }
    }

    [Fact]
    public void Derives_kid_from_the_key_when_not_configured()
    {
        using var directory = new TempDir();
        var (keyPath, key) = TestKeys.WritePrivateKey(directory);
        using var keyOwner = key;
        var options = TestKeys.JwtOptions(keyPath);
        options.KeyId = null;

        using var document = JsonDocument.Parse(JwksExporter.ExportPublicJwks(options));

        Assert.Equal(
            KeyIdProvider.ComputeThumbprint(key),
            document.RootElement.GetProperty("keys")[0].GetProperty("kid").GetString());
    }

    [Fact]
    public void Requires_the_private_key_path()
    {
        var options = new OAuthClientOptions { ClientId = "my-service" };

        Assert.Throws<InvalidOperationException>(() => JwksExporter.ExportPublicJwks(options));
    }
}
