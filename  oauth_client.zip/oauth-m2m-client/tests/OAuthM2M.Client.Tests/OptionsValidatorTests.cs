namespace OAuthM2M.Client.Tests;

public sealed class OptionsValidatorTests
{
    private static readonly OAuthClientOptionsValidator Validator = new();

    private static OAuthClientOptions ValidJwt() => TestKeys.JwtOptions("/keys/private.pem");

    private static OAuthClientOptions ValidMtls() => new()
    {
        AuthMethod = ClientAuthMethod.TlsClientAuth,
        TokenEndpoint = TestKeys.TokenEndpoint,
        ClientId = "my-service",
        ClientCertificatePath = "/certs/client.pfx"
    };

    [Fact]
    public void Valid_private_key_jwt_options_pass() =>
        Assert.True(Validator.Validate(null, ValidJwt()).Succeeded);

    [Fact]
    public void Key_id_is_optional()
    {
        var options = ValidJwt();
        options.KeyId = null;

        Assert.True(Validator.Validate(null, options).Succeeded);
    }

    [Fact]
    public void Valid_mtls_options_pass() =>
        Assert.True(Validator.Validate(null, ValidMtls()).Succeeded);

    [Fact]
    public void Missing_required_values_are_reported_together()
    {
        var result = Validator.Validate(null, new OAuthClientOptions());

        Assert.True(result.Failed);
        Assert.Contains(result.Failures!, failure => failure.Contains("TokenEndpoint"));
        Assert.Contains(result.Failures!, failure => failure.Contains("ClientId"));
        Assert.Contains(result.Failures!, failure => failure.Contains("PrivateKeyPath"));
    }

    [Theory]
    [InlineData(59)]
    [InlineData(301)]
    public void Assertion_lifetime_outside_60_to_300_is_rejected(int seconds)
    {
        var options = ValidJwt();
        options.AssertionLifetimeSeconds = seconds;

        Assert.Contains(Validator.Validate(null, options).Failures!, failure => failure.Contains("AssertionLifetimeSeconds"));
    }

    [Theory]
    [InlineData(60)]
    [InlineData(300)]
    public void Assertion_lifetime_bounds_are_accepted(int seconds)
    {
        var options = ValidJwt();
        options.AssertionLifetimeSeconds = seconds;

        Assert.True(Validator.Validate(null, options).Succeeded);
    }

    [Fact]
    public void Plain_http_is_rejected_for_remote_hosts()
    {
        var options = ValidJwt();
        options.TokenEndpoint = "http://auth.example.com/token";

        Assert.True(Validator.Validate(null, options).Failed);
    }

    [Fact]
    public void Plain_http_is_accepted_for_localhost_with_private_key_jwt()
    {
        var options = ValidJwt();
        options.TokenEndpoint = "http://localhost:8080/realms/demo/protocol/openid-connect/token";

        Assert.True(Validator.Validate(null, options).Succeeded);
    }

    [Fact]
    public void Mtls_requires_https_even_on_localhost()
    {
        var options = ValidMtls();
        options.TokenEndpoint = "http://localhost:8080/token";

        Assert.True(Validator.Validate(null, options).Failed);
    }

    [Fact]
    public void Mtls_requires_a_certificate_path()
    {
        var options = ValidMtls();
        options.ClientCertificatePath = null;

        Assert.Contains(Validator.Validate(null, options).Failures!, failure => failure.Contains("ClientCertificatePath"));
    }
}
