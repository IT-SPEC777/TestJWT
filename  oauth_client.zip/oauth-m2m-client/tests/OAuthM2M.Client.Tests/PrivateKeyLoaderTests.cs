using System.Security.Cryptography;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Client.Tests;

public sealed class PrivateKeyLoaderTests
{
    [Fact]
    public void Loads_plain_pkcs8_pem()
    {
        using var directory = new TempDir();
        var (keyPath, sourceKey) = TestKeys.WritePrivateKey(directory);
        using var sourceKeyOwner = sourceKey;

        using var loadedKey = PrivateKeyLoader.Load(keyPath);

        Assert.Equal(2048, loadedKey.KeySize);
    }

    [Fact]
    public void Loads_encrypted_pem_with_password()
    {
        using var directory = new TempDir();
        var (keyPath, sourceKey) = TestKeys.WritePrivateKey(directory, password: "s3cret");
        using var sourceKeyOwner = sourceKey;

        using var loadedKey = PrivateKeyLoader.Load(keyPath, "s3cret");

        Assert.Equal(2048, loadedKey.KeySize);
    }

    [Fact]
    public void Wrong_password_fails()
    {
        using var directory = new TempDir();
        var (keyPath, sourceKey) = TestKeys.WritePrivateKey(directory, password: "s3cret");
        using var sourceKeyOwner = sourceKey;

        Assert.ThrowsAny<CryptographicException>(() => PrivateKeyLoader.Load(keyPath, "wrong"));
    }

    [Fact]
    public void Missing_file_throws_FileNotFound()
    {
        using var directory = new TempDir();

        Assert.Throws<FileNotFoundException>(() => PrivateKeyLoader.Load(directory.FileIn("missing.pem")));
    }

    [Fact]
    public void Keys_shorter_than_2048_bits_are_rejected()
    {
        using var directory = new TempDir();
        var (keyPath, sourceKey) = TestKeys.WritePrivateKey(directory, bits: 1024);
        using var sourceKeyOwner = sourceKey;

        Assert.Throws<CryptographicException>(() => PrivateKeyLoader.Load(keyPath));
    }
}
