using System.IdentityModel.Tokens.Jwt;
using System.Security.Cryptography;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.IdentityModel.Tokens;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Client.Tests;

public sealed class ClientAssertionFactoryTests : IDisposable
{
    private static readonly DateTimeOffset FixedNow = new(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);

    private readonly TempDir _directory = new();
    private readonly RSA _signingKey;
    private readonly OAuthClientOptions _options;
    private readonly ClientAssertionFactory _factory;

    public ClientAssertionFactoryTests()
    {
        var (keyPath, key) = TestKeys.WritePrivateKey(_directory);
        _signingKey = key;
        _options = TestKeys.JwtOptions(keyPath);
        _factory = CreateFactory(_options);
    }

    public void Dispose()
    {
        _factory.Dispose();
        _signingKey.Dispose();
        _directory.Dispose();
    }

    private static ClientAssertionFactory CreateFactory(OAuthClientOptions options) =>
        new(TestKeys.Wrap(options), new FixedTimeProvider(FixedNow), NullLogger<ClientAssertionFactory>.Instance);

    [Fact]
    public void Header_contains_RS256_typ_and_kid()
    {
        var jwt = new JwtSecurityTokenHandler().ReadJwtToken(_factory.Create());

        Assert.Equal("RS256", jwt.Header.Alg);
        Assert.Equal("JWT", jwt.Header.Typ);
        Assert.Equal("key-1", jwt.Header.Kid);
    }

    [Fact]
    public void Kid_is_derived_from_the_key_when_not_configured()
    {
        _options.KeyId = null;
        using var factory = CreateFactory(_options);

        var jwt = new JwtSecurityTokenHandler().ReadJwtToken(factory.Create());

        Assert.Equal(KeyIdProvider.ComputeThumbprint(_signingKey), jwt.Header.Kid);
    }

    [Fact]
    public void Payload_contains_required_claims()
    {
        var jwt = new JwtSecurityTokenHandler().ReadJwtToken(_factory.Create());

        Assert.Equal("my-service", jwt.Issuer);
        Assert.Equal("my-service", jwt.Subject);
        Assert.Equal(TestKeys.TokenEndpoint, Assert.Single(jwt.Audiences));
        Assert.True(Guid.TryParse(jwt.Id, out var jti), "jti должен быть GUID");
        Assert.NotEqual(Guid.Empty, jti);
    }

    [Fact]
    public void Lifetime_follows_settings()
    {
        var jwt = new JwtSecurityTokenHandler().ReadJwtToken(_factory.Create());

        Assert.Equal(FixedNow.UtcDateTime, jwt.ValidFrom);
        Assert.Equal(FixedNow.UtcDateTime.AddSeconds(120), jwt.ValidTo);
    }

    [Fact]
    public void Jti_differs_between_calls()
    {
        var handler = new JwtSecurityTokenHandler();

        var firstId = handler.ReadJwtToken(_factory.Create()).Id;
        var secondId = handler.ReadJwtToken(_factory.Create()).Id;

        Assert.NotEqual(firstId, secondId);
    }

    [Fact]
    public void Signature_verifies_with_the_public_key()
    {
        using var publicKey = RSA.Create();
        publicKey.ImportRSAPublicKey(_signingKey.ExportRSAPublicKey(), out var bytesRead);
        Assert.True(bytesRead > 0);

        var validation = new TokenValidationParameters
        {
            ValidIssuer = "my-service",
            ValidAudience = TestKeys.TokenEndpoint,
            IssuerSigningKey = new RsaSecurityKey(publicKey) { KeyId = "key-1" },
            ValidateLifetime = false   // время в тесте зафиксировано в прошлом
        };

        new JwtSecurityTokenHandler().ValidateToken(_factory.Create(), validation, out var validatedToken);

        Assert.NotNull(validatedToken);
    }

    [Fact]
    public void Explicit_audience_replaces_token_endpoint()
    {
        _options.Audience = "https://auth.example.com/realms/demo";

        var jwt = new JwtSecurityTokenHandler().ReadJwtToken(_factory.Create());

        Assert.Equal("https://auth.example.com/realms/demo", Assert.Single(jwt.Audiences));
    }

    [Fact]
    public void Missing_key_file_fails_on_first_use()
    {
        var options = TestKeys.JwtOptions(_directory.FileIn("missing.pem"));
        using var factory = CreateFactory(options);

        Assert.Throws<FileNotFoundException>(() => factory.Create());
    }
}
