using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Microsoft.Extensions.Options;
using OAuthM2M.Client;

namespace OAuthM2M.Client.Tests;

/// <summary>Временный каталог, который удаляется после теста.</summary>
internal sealed class TempDir : IDisposable
{
    public TempDir()
    {
        FullPath = Path.Combine(Path.GetTempPath(), "oauth-m2m-tests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(FullPath);
    }

    public string FullPath { get; }

    /// <summary>Путь к файлу внутри каталога.</summary>
    public string FileIn(string fileName) => Path.Combine(FullPath, fileName);

    public void Dispose()
    {
        try
        {
            Directory.Delete(FullPath, recursive: true);
        }
        catch (IOException)
        {
            // Уборка не критична для результата теста.
        }
    }
}

/// <summary>Файлы тестового самоподписанного сертификата.</summary>
internal sealed record SelfSignedFiles(string PfxPath, string CertificatePath, string KeyPath);

/// <summary>Сертификат УЦ и выписанный им сертификат, сохранённые в PEM.</summary>
internal sealed record TestPkiFiles(string CaCertificatePath, string LeafCertificatePath);

internal static class TestKeys
{
    public const string TokenEndpoint = "https://auth.example.com/realms/demo/protocol/openid-connect/token";

    /// <summary>Создаёт PEM-ключ PKCS#8. Возвращает путь к файлу и сам ключ (для проверки подписи).</summary>
    public static (string KeyPath, RSA Key) WritePrivateKey(
        TempDir directory,
        int bits = 2048,
        string? password = null,
        string fileName = "private.pem")
    {
        var rsa = RSA.Create(bits);

        var pem = password is null
            ? rsa.ExportPkcs8PrivateKeyPem()
            : rsa.ExportEncryptedPkcs8PrivateKeyPem(
                password,
                new PbeParameters(PbeEncryptionAlgorithm.Aes256Cbc, HashAlgorithmName.SHA256, 10_000));

        var keyPath = directory.FileIn(fileName);
        File.WriteAllText(keyPath, pem);
        return (keyPath, rsa);
    }

    /// <summary>Самоподписанный сертификат с ключом: PFX и пара PEM (сертификат и ключ).</summary>
    public static SelfSignedFiles WriteSelfSignedCertificate(TempDir directory, string pfxPassword = "pfx-pass")
    {
        using var rsa = RSA.Create(2048);
        var request = new CertificateRequest("CN=my-service", rsa, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        using var certificate = request.CreateSelfSigned(DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddDays(30));

        var pfxPath = directory.FileIn("client.pfx");
        var certificatePath = directory.FileIn("client.crt");
        var keyPath = directory.FileIn("client.key");

        File.WriteAllBytes(pfxPath, certificate.Export(X509ContentType.Pfx, pfxPassword));
        File.WriteAllText(certificatePath, certificate.ExportCertificatePem());
        File.WriteAllText(keyPath, rsa.ExportPkcs8PrivateKeyPem());
        return new SelfSignedFiles(pfxPath, certificatePath, keyPath);
    }

    /// <summary>Тестовый УЦ и сертификат, выписанный этим УЦ.</summary>
    public static TestPkiFiles WriteCertificateIssuedByCa(TempDir directory)
    {
        var notBefore = DateTimeOffset.UtcNow.AddDays(-1);
        var notAfter = DateTimeOffset.UtcNow.AddDays(30);

        using var caKey = RSA.Create(2048);
        var caRequest = new CertificateRequest("CN=Test CA", caKey, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        caRequest.CertificateExtensions.Add(new X509BasicConstraintsExtension(true, false, 0, true));
        caRequest.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.KeyCertSign, true));
        using var caCertificate = caRequest.CreateSelfSigned(notBefore, notAfter);

        using var leafKey = RSA.Create(2048);
        var leafRequest = new CertificateRequest("CN=server.example.com", leafKey, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        var serialNumber = new byte[] { 0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF };
        using var leafCertificate = leafRequest.Create(caCertificate, notBefore, notAfter, serialNumber);

        var caPath = directory.FileIn("ca.crt");
        var leafPath = directory.FileIn("leaf.crt");
        File.WriteAllText(caPath, caCertificate.ExportCertificatePem());
        File.WriteAllText(leafPath, leafCertificate.ExportCertificatePem());
        return new TestPkiFiles(caPath, leafPath);
    }

    /// <summary>Читает сертификат без ключа из PEM (CreateFromPemFile требует закрытый ключ в файле).</summary>
    public static X509Certificate2 LoadCertificate(string pemPath)
    {
        var certificates = new X509Certificate2Collection();
        certificates.ImportFromPem(File.ReadAllText(pemPath));
        return certificates[0];
    }

    public static OAuthClientOptions JwtOptions(string privateKeyPath) => new()
    {
        TokenEndpoint = TokenEndpoint,
        ClientId = "my-service",
        KeyId = "key-1",
        PrivateKeyPath = privateKeyPath,
        AssertionLifetimeSeconds = 120
    };

    public static IOptions<OAuthClientOptions> Wrap(OAuthClientOptions options) => Options.Create(options);
}

/// <summary>Фиксированное время: даёт предсказуемые значения exp и nbf.</summary>
internal sealed class FixedTimeProvider(DateTimeOffset utcNow) : TimeProvider
{
    public override DateTimeOffset GetUtcNow() => utcNow;
}
