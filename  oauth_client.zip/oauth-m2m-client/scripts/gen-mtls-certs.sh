#!/usr/bin/env bash
# Создаёт тестовый УЦ, клиентский сертификат (EKU clientAuth) и PFX для проверки mTLS.
# Только для тестового стенда: в рабочей среде сертификаты выпускает ваш УЦ.
# Использование: ./scripts/gen-mtls-certs.sh [каталог=./secrets/mtls] [CN=my-service] [пароль_pfx]
set -euo pipefail

OUT="${1:-./secrets/mtls}"
CN="${2:-my-service}"
PFX_PASSWORD="${3:-$(openssl rand -base64 18 | tr -d '/+=')}"

mkdir -p "$OUT"
chmod 700 "$OUT"
cd "$OUT"

# Тестовый УЦ.
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out ca.key
openssl req -x509 -new -key ca.key -sha256 -days 1825 -subj "/CN=Test M2M Root CA" -out ca.crt

# Клиентский ключ и запрос на сертификат.
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out client.key
openssl req -new -key client.key -subj "/CN=$CN" -out client.csr

# Подпись клиентского сертификата тестовым УЦ.
printf 'basicConstraints=CA:FALSE\nkeyUsage=digitalSignature\nextendedKeyUsage=clientAuth\n' > client.ext
openssl x509 -req -in client.csr -CA ca.crt -CAkey ca.key -CAcreateserial \
  -days 365 -sha256 -extfile client.ext -out client.crt

# PFX для .NET.
openssl pkcs12 -export -inkey client.key -in client.crt -certfile ca.crt \
  -out client.pfx -passout "pass:$PFX_PASSWORD"

chmod 600 ./*.key client.pfx
rm -f client.csr client.ext ca.srl

echo "Файлы в $OUT: ca.crt, client.crt, client.key, client.pfx"
echo "Пароль PFX: $PFX_PASSWORD"
