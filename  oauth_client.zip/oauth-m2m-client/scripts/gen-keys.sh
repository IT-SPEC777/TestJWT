#!/usr/bin/env bash
# Создаёт пару ключей RSA-2048 и самоподписанный сертификат без использования .NET.
# Для обычной работы достаточно команды `oauth-m2m init`; скрипт нужен для проверок без SDK.
# Использование: ./scripts/gen-keys.sh [каталог=./secrets] [CN=my-service] [дней=365]
set -euo pipefail

OUT="${1:-./secrets}"
CN="${2:-my-service}"
DAYS="${3:-365}"

mkdir -p "$OUT"
chmod 700 "$OUT"

# Приватный ключ (PKCS#8). На сервер не передаётся.
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out "$OUT/private.pem"
chmod 600 "$OUT/private.pem"

# Публичный ключ.
openssl rsa -in "$OUT/private.pem" -pubout -out "$OUT/public.pem"

# Самоподписанный сертификат для серверов, которым нужен сертификат, а не JWKS.
# Только для тестового стенда: в рабочей среде используйте сертификат вашего УЦ.
openssl req -new -x509 -key "$OUT/private.pem" -sha256 -days "$DAYS" -subj "/CN=$CN" -out "$OUT/client.crt"

echo "Файлы в $OUT: private.pem (не коммитить), public.pem, client.crt"
