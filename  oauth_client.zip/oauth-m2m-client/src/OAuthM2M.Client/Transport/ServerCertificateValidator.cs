using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace OAuthM2M.Client.Transport;

/// <summary>
/// Проверка сертификата сервера с дополнительными доверенными УЦ (корпоративными).
/// Используется и клиентом токенов, и клиентом NiFi, чтобы правила были одинаковыми.
/// </summary>
public static class ServerCertificateValidator
{
    /// <summary>Возвращает true, если сертификат сервера можно принять.</summary>
    /// <param name="certificate">Сертификат сервера.</param>
    /// <param name="chain">Цепочка, построенная платформой по системному хранилищу.</param>
    /// <param name="policyErrors">Ошибки, найденные платформой.</param>
    /// <param name="customRoots">Дополнительные доверенные УЦ (OAuth:ServerCaCertificatePath).</param>
    public static bool IsTrusted(
        X509Certificate? certificate,
        X509Chain? chain,
        SslPolicyErrors policyErrors,
        X509Certificate2Collection? customRoots)
    {
        if (policyErrors == SslPolicyErrors.None)
        {
            return true;
        }

        if (certificate is null || chain is null || customRoots is null || customRoots.Count == 0)
        {
            return false;
        }

        // Допускаем только случай, когда цепочка не дошла до доверенного корня.
        // Несовпадение имени хоста и прочие ошибки по-прежнему считаются отказом.
        if ((policyErrors & ~SslPolicyErrors.RemoteCertificateChainErrors) != 0)
        {
            return false;
        }

        using var customChain = new X509Chain();
        customChain.ChainPolicy.TrustMode = X509ChainTrustMode.CustomRootTrust;
        customChain.ChainPolicy.CustomTrustStore.AddRange(customRoots);
        customChain.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;

        // Промежуточные сертификаты, присланные сервером, нужны для построения цепочки.
        foreach (var element in chain.ChainElements)
        {
            customChain.ChainPolicy.ExtraStore.Add(element.Certificate);
        }

        // Сертификат, переданный платформой, освобождать нельзя; освобождаем только копию, созданную здесь.
        var leafCertificate = certificate as X509Certificate2;
        var createdCopy = leafCertificate is null;
        leafCertificate ??= new X509Certificate2(certificate);

        try
        {
            return customChain.Build(leafCertificate);
        }
        finally
        {
            if (createdCopy)
            {
                leafCertificate.Dispose();
            }
        }
    }
}
