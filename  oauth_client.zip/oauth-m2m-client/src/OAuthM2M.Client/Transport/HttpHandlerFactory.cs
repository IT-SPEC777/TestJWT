using System.Security.Cryptography.X509Certificates;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Client.Transport;

/// <summary>
/// Создаёт основной HTTP-обработчик для запросов токена: подключает клиентский сертификат (mTLS)
/// и дополнительные доверенные УЦ сервера.
/// </summary>
public static class HttpHandlerFactory
{
    public static SocketsHttpHandler Create(OAuthClientOptions options)
    {
        var handler = new SocketsHttpHandler
        {
            // Соединения периодически пересоздаются, чтобы подхватывать смену DNS и ротацию сертификатов.
            PooledConnectionLifetime = TimeSpan.FromMinutes(2)
        };

        if (options.AuthMethod == ClientAuthMethod.TlsClientAuth)
        {
            var clientCertificate = ClientCertificateLoader.Load(options);
            handler.SslOptions.ClientCertificates = new X509CertificateCollection { clientCertificate };
        }

        if (!string.IsNullOrWhiteSpace(options.ServerCaCertificatePath))
        {
            if (!File.Exists(options.ServerCaCertificatePath))
            {
                throw new FileNotFoundException(
                    $"Файл УЦ сервера не найден: {options.ServerCaCertificatePath}", options.ServerCaCertificatePath);
            }

            var trustedRoots = CertificateIo.LoadCertificates(options.ServerCaCertificatePath);

            handler.SslOptions.RemoteCertificateValidationCallback =
                (sender, serverCertificate, chain, policyErrors) =>
                    ServerCertificateValidator.IsTrusted(serverCertificate, chain, policyErrors, trustedRoots);
        }

        return handler;
    }
}
