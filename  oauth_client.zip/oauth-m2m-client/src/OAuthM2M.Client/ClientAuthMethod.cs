namespace OAuthM2M.Client;

/// <summary>Способ аутентификации клиента на токен-эндпоинте.</summary>
public enum ClientAuthMethod
{
    /// <summary>
    /// private_key_jwt (RFC 7523): клиент подписывает короткоживущий JWT своим приватным ключом
    /// и передаёт его в параметре client_assertion.
    /// </summary>
    PrivateKeyJwt = 0,

    /// <summary>
    /// tls_client_auth (RFC 8705): клиент предъявляет сертификат при установке TLS-соединения,
    /// дополнительных параметров в теле запроса нет.
    /// </summary>
    TlsClientAuth = 1
}
