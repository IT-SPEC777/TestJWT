using System.Net.Http.Headers;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OAuthM2M.Client.Security;
using OAuthM2M.Client.Transport;

namespace OAuthM2M.Client.NiFi;

/// <summary>
/// Отправляет JSON в NiFi (процессор HandleHttpRequest). Токен передаётся в заголовке
/// <c>Authorization: Bearer</c>. Проверка токена выполняется на стороне NiFi и в этот проект не входит.
/// </summary>
public sealed class NiFiHttpClient : IDisposable
{
    private readonly HttpClient _httpClient;
    private readonly NiFiOptions _options;
    private readonly ILogger<NiFiHttpClient> _logger;

    public NiFiHttpClient(IOptions<NiFiOptions> options, ILogger<NiFiHttpClient> logger)
    {
        _options = options.Value;
        _logger = logger;

        if (string.IsNullOrWhiteSpace(_options.Endpoint))
        {
            throw new InvalidOperationException("NiFi:Endpoint не задан.");
        }

        _httpClient = new HttpClient(CreateHandler(_options), disposeHandler: true)
        {
            Timeout = TimeSpan.FromSeconds(_options.TimeoutSeconds)
        };
    }

    public async Task SendJsonAsync(string json, string accessToken, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(json);
        ArgumentException.ThrowIfNullOrWhiteSpace(accessToken);

        using var request = new HttpRequestMessage(HttpMethod.Post, _options.Endpoint)
        {
            Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json")
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

        _logger.LogInformation("Отправка JSON в NiFi: {Endpoint}, размер {Size} симв.", _options.Endpoint, json.Length);

        try
        {
            using var response = await _httpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            var responseBody = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError(
                    "NiFi вернул {Status} {Reason}: {Body}", (int)response.StatusCode, response.ReasonPhrase, responseBody);
                throw new NiFiSendException($"NiFi вернул {(int)response.StatusCode} {response.ReasonPhrase}. {responseBody}");
            }

            _logger.LogInformation("NiFi принял JSON, статус {Status}", (int)response.StatusCode);
        }
        catch (NiFiSendException)
        {
            throw;
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            _logger.LogError("Таймаут запроса к NiFi: {Endpoint}", _options.Endpoint);
            throw new NiFiSendException("Таймаут запроса к NiFi.");
        }
        catch (HttpRequestException exception)
        {
            _logger.LogError(exception, "Сетевая или TLS-ошибка при обращении к NiFi");
            throw new NiFiSendException($"Сетевая или TLS-ошибка: {exception.Message}", exception);
        }
    }

    private static SocketsHttpHandler CreateHandler(NiFiOptions options)
    {
        var handler = new SocketsHttpHandler
        {
            PooledConnectionLifetime = TimeSpan.FromMinutes(2)
        };

        if (!string.IsNullOrWhiteSpace(options.ServerCaCertificatePath))
        {
            var trustedRoots = CertificateIo.LoadCertificates(options.ServerCaCertificatePath);

            // Те же правила, что и для сервера авторизации: свой УЦ добавляется как доверенный корень,
            // но несоответствие имени хоста по-прежнему считается ошибкой.
            handler.SslOptions.RemoteCertificateValidationCallback =
                (sender, serverCertificate, chain, policyErrors) =>
                    ServerCertificateValidator.IsTrusted(serverCertificate, chain, policyErrors, trustedRoots);
        }

        return handler;
    }

    public void Dispose() => _httpClient.Dispose();
}

/// <summary>Не удалось отправить данные в NiFi.</summary>
public sealed class NiFiSendException : Exception
{
    public NiFiSendException(string message, Exception? inner = null) : base(message, inner) { }
}
