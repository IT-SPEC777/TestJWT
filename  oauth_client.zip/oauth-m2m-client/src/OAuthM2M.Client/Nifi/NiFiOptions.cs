namespace OAuthM2M.Client.NiFi;

/// <summary>
/// Параметры отправки JSON в NiFi через процессор HandleHttpRequest (секция конфигурации <c>NiFi</c>).
/// </summary>
/// <remarks>
/// Секция необязательная: если <see cref="Endpoint"/> пуст, NiFi-клиент не регистрируется
/// и приложение только получает токен.
/// </remarks>
public sealed class NiFiOptions
{
    public const string SectionName = "NiFi";

    /// <summary>
    /// Адрес, на который клиент отправляет POST с JSON в теле,
    /// например <c>https://nifi.example.local:8443/data</c>.
    /// </summary>
    public string Endpoint { get; set; } = string.Empty;

    /// <summary>
    /// Файл с сертификатом УЦ сервера NiFi (PEM или DER). Нужен, если NiFi подписан корпоративным УЦ,
    /// которого нет в системном хранилище. Относительный путь считается от каталога файла конфигурации.
    /// </summary>
    public string? ServerCaCertificatePath { get; set; }

    /// <summary>Таймаут одного HTTP-запроса в секундах.</summary>
    public int TimeoutSeconds { get; set; } = 30;
}
