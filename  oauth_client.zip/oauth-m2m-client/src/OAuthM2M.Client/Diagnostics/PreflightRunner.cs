using System.Text.Json;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Client.Diagnostics;

/// <summary>
/// Проверки до запроса токена (команда doctor): конфигурация, ключ и discovery-документ сервера.
/// Большинство проблем при настройке private_key_jwt (неверный aud, не тот kid, метод не включён
/// на сервере) видно заранее, до того как сервер вернёт малоинформативный invalid_client.
/// </summary>
/// <remarks>
/// Discovery запрашивается обычным HttpClient без пользовательского УЦ и без клиентского сертификата,
/// поэтому для серверов с корпоративным УЦ эта проверка может завершиться предупреждением.
/// </remarks>
public sealed class PreflightRunner
{
    private readonly OAuthClientOptions _options;

    // Пока не используется: зарезервировано для проверки расхождения часов с сервером.
    private readonly TimeProvider _timeProvider;

    public PreflightRunner(OAuthClientOptions options, TimeProvider timeProvider)
    {
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(timeProvider);

        _options = options;
        _timeProvider = timeProvider;
    }

    public async Task<IReadOnlyList<CheckResult>> RunAsync(CancellationToken cancellationToken)
    {
        var results = new List<CheckResult>();

        // Конфигурация. Без корректного адреса остальные проверки не имеют смысла.
        if (!Uri.TryCreate(_options.TokenEndpoint, UriKind.Absolute, out var endpoint))
        {
            results.Add(new CheckResult("Конфигурация", "TokenEndpoint", CheckStatus.Failed,
                "Не задан или не является абсолютным URL."));
            return results;
        }

        results.Add(new CheckResult("Конфигурация", "TokenEndpoint", CheckStatus.Ok, endpoint.ToString()));
        results.Add(new CheckResult("Конфигурация", "ClientId", CheckStatus.Ok, _options.ClientId));
        results.Add(new CheckResult("Конфигурация", "AuthMethod", CheckStatus.Ok, _options.AuthMethod.ToString()));

        // Ключ проверяется только для private_key_jwt.
        if (_options.AuthMethod == ClientAuthMethod.PrivateKeyJwt)
        {
            results.Add(CheckPrivateKey());
        }

        // Discovery-документ сервера.
        using var discovery = await LoadDiscoveryAsync(endpoint, cancellationToken).ConfigureAwait(false);
        if (discovery is null)
        {
            results.Add(new CheckResult("Сервер", "Discovery", CheckStatus.Warning,
                "Не удалось получить discovery-документ.",
                "Проверьте путь /.well-known/openid-configuration и доступность хоста."));
            return results;
        }

        var discoveryRoot = discovery.RootElement;

        results.Add(CheckTokenEndpoint(discoveryRoot, endpoint));
        results.Add(CheckAuthMethod(discoveryRoot));

        // Алгоритм подписи относится только к private_key_jwt.
        if (_options.AuthMethod == ClientAuthMethod.PrivateKeyJwt)
        {
            results.Add(CheckSigningAlgorithm(discoveryRoot));
        }

        results.Add(CheckGrantTypes(discoveryRoot));
        results.Add(CheckAudienceCandidate(discoveryRoot));

        return results;
    }

    private CheckResult CheckPrivateKey()
    {
        if (string.IsNullOrWhiteSpace(_options.PrivateKeyPath))
        {
            return new CheckResult("Ключ", "Приватный ключ", CheckStatus.Failed,
                "OAuth:PrivateKeyPath не задан.",
                "Создайте ключ: oauth-m2m init --config <файл>.");
        }

        if (!File.Exists(_options.PrivateKeyPath))
        {
            return new CheckResult("Ключ", "Приватный ключ", CheckStatus.Failed,
                $"Файл не найден: {_options.PrivateKeyPath}",
                "Создайте ключ: oauth-m2m init --config <файл>.");
        }

        try
        {
            using var rsa = PrivateKeyLoader.Load(_options.PrivateKeyPath, _options.PrivateKeyPassword);
            var effectiveKeyId = string.IsNullOrWhiteSpace(_options.KeyId)
                ? KeyIdProvider.ComputeThumbprint(rsa)
                : _options.KeyId;

            return new CheckResult("Ключ", "Приватный ключ", CheckStatus.Ok,
                $"RSA-{rsa.KeySize}, kid={effectiveKeyId}");
        }
        catch (Exception exception)
        {
            return new CheckResult("Ключ", "Приватный ключ", CheckStatus.Failed,
                exception.Message,
                "Проверьте формат PEM и пароль.");
        }
    }

    private static CheckResult CheckTokenEndpoint(JsonElement discoveryRoot, Uri configuredEndpoint)
    {
        var advertised = JwtInspector.GetString(discoveryRoot, "token_endpoint");

        if (string.IsNullOrWhiteSpace(advertised))
        {
            return new CheckResult("Сервер", "token_endpoint", CheckStatus.Skipped,
                "В discovery-документе поля нет.");
        }

        return string.Equals(advertised, configuredEndpoint.ToString(), StringComparison.OrdinalIgnoreCase)
            ? new CheckResult("Сервер", "token_endpoint", CheckStatus.Ok, "совпадает с конфигом")
            : new CheckResult("Сервер", "token_endpoint", CheckStatus.Warning,
                $"discovery={advertised}, конфиг={configuredEndpoint}",
                "Если различие не связано с прокси или внешним адресом, скопируйте значение из discovery в OAuth:TokenEndpoint.");
    }

    private CheckResult CheckAuthMethod(JsonElement discoveryRoot)
    {
        // Какой метод нужен серверу, зависит от выбранного режима.
        var required = _options.AuthMethod == ClientAuthMethod.PrivateKeyJwt
            ? "private_key_jwt"
            : "tls_client_auth";

        if (!TryGetStringArray(discoveryRoot, "token_endpoint_auth_methods_supported", out var methods))
        {
            return new CheckResult("Сервер", "Метод аутентификации", CheckStatus.Warning,
                "Поле token_endpoint_auth_methods_supported отсутствует.");
        }

        // Для mTLS допустим и вариант с самоподписанным сертификатом клиента.
        var supported = methods.Contains(required)
                        || (required == "tls_client_auth" && methods.Contains("self_signed_tls_client_auth"));

        return supported
            ? new CheckResult("Сервер", "Метод аутентификации", CheckStatus.Ok, $"{required} поддерживается")
            : new CheckResult("Сервер", "Метод аутентификации", CheckStatus.Failed,
                $"{required} не поддерживается. Доступны: {string.Join(", ", methods)}",
                "Включите метод на стороне FAM/Keycloak или смените AuthMethod.");
    }

    private static CheckResult CheckSigningAlgorithm(JsonElement discoveryRoot)
    {
        if (!TryGetStringArray(discoveryRoot, "token_endpoint_auth_signing_alg_values_supported", out var algorithms))
        {
            return new CheckResult("Сервер", "Алгоритм подписи", CheckStatus.Warning,
                "Поле token_endpoint_auth_signing_alg_values_supported отсутствует.");
        }

        return algorithms.Contains("RS256")
            ? new CheckResult("Сервер", "Алгоритм подписи", CheckStatus.Ok, "RS256 поддерживается")
            : new CheckResult("Сервер", "Алгоритм подписи", CheckStatus.Failed,
                $"RS256 не поддерживается. Доступны: {string.Join(", ", algorithms)}");
    }

    private static CheckResult CheckGrantTypes(JsonElement discoveryRoot)
    {
        if (!TryGetStringArray(discoveryRoot, "grant_types_supported", out var grants))
        {
            return new CheckResult("Сервер", "Grant types", CheckStatus.Warning,
                "Поле grant_types_supported отсутствует.");
        }

        return grants.Contains("client_credentials")
            ? new CheckResult("Сервер", "Grant types", CheckStatus.Ok, "client_credentials поддерживается")
            : new CheckResult("Сервер", "Grant types", CheckStatus.Failed,
                $"client_credentials не поддерживается. Доступны: {string.Join(", ", grants)}",
                "Разрешите client_credentials для клиента.");
    }

    private static CheckResult CheckAudienceCandidate(JsonElement discoveryRoot)
    {
        // Без OAuth:Audience клиент отправляет token_endpoint, а Keycloak 26+ может ожидать issuer.
        var issuer = JwtInspector.GetString(discoveryRoot, "issuer");

        return string.IsNullOrWhiteSpace(issuer)
            ? new CheckResult("Сервер", "Audience", CheckStatus.Skipped, "В discovery-документе нет issuer.")
            : new CheckResult("Сервер", "Audience", CheckStatus.Ok,
                $"issuer={issuer}; при ошибке invalid_client попробуйте OAuth:Audience={issuer}");
    }

    private async Task<JsonDocument?> LoadDiscoveryAsync(Uri tokenEndpoint, CancellationToken cancellationToken)
    {
        // У Keycloak discovery лежит рядом с realm: /realms/<realm>/.well-known/openid-configuration,
        // у остальных серверов обычно в корне хоста. Пробуем оба варианта.
        var origin = new Uri(tokenEndpoint.GetLeftPart(UriPartial.Authority));

        var candidates = new[]
        {
            new Uri(origin, "/.well-known/openid-configuration"),
            new Uri(origin, tokenEndpoint.AbsolutePath.Replace(
                "/protocol/openid-connect/token",
                "/.well-known/openid-configuration",
                StringComparison.OrdinalIgnoreCase))
        };

        using var httpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };

        foreach (var candidate in candidates.Distinct())
        {
            try
            {
                using var response = await httpClient.GetAsync(candidate, cancellationToken).ConfigureAwait(false);
                if (!response.IsSuccessStatusCode)
                {
                    continue;
                }

                var json = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                return JsonDocument.Parse(json);
            }
            catch (Exception exception) when (
                exception is HttpRequestException or JsonException
                || (exception is OperationCanceledException && !cancellationToken.IsCancellationRequested))
            {
                // Сетевая ошибка, таймаут или не-JSON: пробуем следующий адрес.
            }
        }

        return null;
    }

    private static bool TryGetStringArray(JsonElement element, string name, out string[] values)
    {
        values = Array.Empty<string>();

        if (element.ValueKind != JsonValueKind.Object
            || !element.TryGetProperty(name, out var array)
            || array.ValueKind != JsonValueKind.Array)
        {
            return false;
        }

        values = array.EnumerateArray()
            .Where(item => item.ValueKind == JsonValueKind.String)
            .Select(item => item.GetString() ?? string.Empty)
            .ToArray();

        return values.Length > 0;
    }
}
