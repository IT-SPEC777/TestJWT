using OAuthM2M.Client.Tokens;

namespace OAuthM2M.Client.Diagnostics;

/// <summary>
/// Превращает ответ сервера об ошибке в список конкретных действий.
/// Сам по себе invalid_client не говорит, что именно настроено неверно; соответствие
/// «симптом - действие» описано также в docs/troubleshooting.md.
/// </summary>
public static class ErrorAdvisor
{
    public static IReadOnlyList<string> Advise(TokenRequestException exception, OAuthClientOptions options)
    {
        ArgumentNullException.ThrowIfNull(exception);
        ArgumentNullException.ThrowIfNull(options);

        var hints = new List<string>();
        var error = exception.Error ?? string.Empty;
        var message = exception.Message ?? string.Empty;

        if (error == "invalid_client")
        {
            if (options.AuthMethod == ClientAuthMethod.TlsClientAuth)
            {
                hints.Add("mTLS: проверьте, что сертификат доходит до сервера (прокси и балансировщик могут его не передавать) и что Subject DN совпадает с настройкой клиента.");
                hints.Add("Проверьте ключ сертификата: OAuth:ClientCertificateKeyPath и OAuth:ClientCertificatePassword.");
            }
            else
            {
                hints.Add("Проверьте OAuth:Audience: попробуйте token_endpoint и issuer из discovery-документа.");
                hints.Add("kid в JWKS на сервере должен совпадать с kid в JWT. Актуальный JWKS лежит рядом с ключом (файл *.jwks.json, его создаёт init).");
                hints.Add("Проверьте системное время (NTP): расхождение больше нескольких секунд даёт отказ по exp/nbf.");
                hints.Add("Запустите диагностику: oauth-m2m doctor --config <файл>.");
            }
        }
        else if (error == "unauthorized_client")
        {
            hints.Add("Клиенту не разрешён client_credentials. Keycloak: включите Service accounts roles; FAM: Allowed grant types.");
        }
        else if (error == "invalid_scope")
        {
            hints.Add("Запрошенный scope не выдан клиенту. Уберите OAuth:Scope или назначьте scope клиенту на сервере.");
        }

        if (message.Contains("SSL connection", StringComparison.OrdinalIgnoreCase))
        {
            hints.Add("TLS: если сервер подписан корпоративным УЦ, укажите его в OAuth:ServerCaCertificatePath.");
        }

        if (message.Contains("NameMismatch", StringComparison.OrdinalIgnoreCase))
        {
            hints.Add("Имя хоста в URL не совпадает с SAN сертификата сервера. Используйте имя из сертификата.");
        }

        return hints;
    }
}
