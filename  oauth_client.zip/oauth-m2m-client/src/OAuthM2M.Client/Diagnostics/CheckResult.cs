namespace OAuthM2M.Client.Diagnostics;

/// <summary>Итог одной проверки команды doctor.</summary>
public enum CheckStatus
{
    Ok,
    Warning,
    Failed,
    Skipped
}

/// <param name="Category">Группа проверок: «Конфигурация», «Ключ», «Сервер».</param>
/// <param name="Name">Короткое название проверки.</param>
/// <param name="Status">Итог.</param>
/// <param name="Detail">Что именно проверено и какие значения найдены.</param>
/// <param name="Hint">Что делать при предупреждении или ошибке (может быть пустым).</param>
public sealed record CheckResult(
    string Category,
    string Name,
    CheckStatus Status,
    string Detail,
    string? Hint = null);
