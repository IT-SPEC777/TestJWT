using System.Text.Json;
using Microsoft.IdentityModel.Tokens;

namespace OAuthM2M.Client.Diagnostics;

/// <summary>
/// Разбирает JWT без проверки подписи, только для отладки. При ошибке invalid_client обычно
/// первым делом смотрят заголовок (alg, kid) и payload (aud, iss, exp); команда
/// <c>assertion --Inspect=true</c> показывает их локально, без сторонних сервисов.
/// </summary>
public static class JwtInspector
{
    public static bool TryInspect(string? token, out InspectedJwt? inspected)
    {
        inspected = null;

        if (string.IsNullOrWhiteSpace(token))
        {
            return false;
        }

        var parts = token.Split('.');
        if (parts.Length < 2)
        {
            return false;
        }

        try
        {
            using var headerDocument = JsonDocument.Parse(Base64UrlEncoder.Decode(parts[0]));
            using var payloadDocument = JsonDocument.Parse(Base64UrlEncoder.Decode(parts[1]));

            // Clone: иначе элементы ссылались бы на документы, которые освобождаются при выходе из метода.
            inspected = new InspectedJwt(headerDocument.RootElement.Clone(), payloadDocument.RootElement.Clone());
            return true;
        }
        catch (FormatException)
        {
            return false;
        }
        catch (JsonException)
        {
            return false;
        }
    }

    public static string? GetString(JsonElement element, string name) =>
        element.ValueKind == JsonValueKind.Object
        && element.TryGetProperty(name, out var value)
        && value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;

    /// <summary>Читает claim в формате NumericDate (exp, iat, nbf) как момент времени.</summary>
    public static bool TryGetUnixTime(JsonElement element, string name, out DateTimeOffset moment)
    {
        moment = default;

        if (element.ValueKind != JsonValueKind.Object
            || !element.TryGetProperty(name, out var value)
            || value.ValueKind != JsonValueKind.Number
            || !value.TryGetInt64(out var seconds))
        {
            return false;
        }

        moment = DateTimeOffset.FromUnixTimeSeconds(seconds);
        return true;
    }

    /// <summary>Значение claim в виде текста: массивы через запятую, остальное как есть.</summary>
    public static string Format(JsonElement element) => element.ValueKind switch
    {
        JsonValueKind.Array => string.Join(", ", element.EnumerateArray().Select(Format)),
        JsonValueKind.String => element.GetString() ?? string.Empty,
        JsonValueKind other => element.GetRawText()
    };
}

/// <param name="Header">Заголовок JWT (JOSE).</param>
/// <param name="Payload">Claims.</param>
public sealed record InspectedJwt(JsonElement Header, JsonElement Payload);
