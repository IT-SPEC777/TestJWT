namespace OAuthM2M.Client.Diagnostics;

/// <summary>
/// Минимальная обёртка над ANSI-кодами для цветного вывода. Сторонняя библиотека для консоли
/// не используется: нужны только несколько цветов и жирный шрифт.
/// </summary>
public static class AnsiConsole
{
    private const string Reset = "\u001b[0m";

    /// <summary>
    /// Отключает цвета. По умолчанию включено, если вывод перенаправлен (файл, CI без терминала);
    /// CLI дополнительно выставляет его по флагу --no-color и переменной NO_COLOR.
    /// </summary>
    public static bool Disabled { get; set; } = Console.IsOutputRedirected;

    public static string Bold(string text) => Wrap(text, "\u001b[1m");
    public static string Dim(string text) => Wrap(text, "\u001b[2m");
    public static string Red(string text) => Wrap(text, "\u001b[31m");
    public static string Green(string text) => Wrap(text, "\u001b[32m");
    public static string Yellow(string text) => Wrap(text, "\u001b[33m");
    public static string Blue(string text) => Wrap(text, "\u001b[34m");
    public static string Magenta(string text) => Wrap(text, "\u001b[35m");
    public static string Cyan(string text) => Wrap(text, "\u001b[36m");

    /// <summary>Метка статуса проверки: [ OK ], [FAIL], [WARN], [SKIP].</summary>
    public static string StatusBadge(CheckStatus status) => status switch
    {
        CheckStatus.Ok => Green("[ OK ]"),
        CheckStatus.Failed => Red("[FAIL]"),
        CheckStatus.Warning => Yellow("[WARN]"),
        CheckStatus.Skipped => Dim("[SKIP]"),
        CheckStatus unknown => $"[{unknown}]"
    };

    private static string Wrap(string text, string prefix) =>
        Disabled ? text : $"{prefix}{text}{Reset}";
}
