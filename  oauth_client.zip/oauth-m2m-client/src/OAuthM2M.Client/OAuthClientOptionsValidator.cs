using Microsoft.Extensions.Options;

namespace OAuthM2M.Client;

/// <summary>
/// Проверяет настройки при первом обращении к <c>IOptions&lt;OAuthClientOptions&gt;.Value</c>.
/// Все найденные проблемы возвращаются списком, чтобы их можно было исправить за один проход.
/// </summary>
public sealed class OAuthClientOptionsValidator : IValidateOptions<OAuthClientOptions>
{
    public ValidateOptionsResult Validate(string? name, OAuthClientOptions options)
    {
        var errors = new List<string>();
        var section = OAuthClientOptions.SectionName;

        if (!Uri.TryCreate(options.TokenEndpoint, UriKind.Absolute, out var endpoint))
        {
            errors.Add($"{section}:TokenEndpoint не задан или не является абсолютным URL.");
        }
        else
        {
            var isHttps = endpoint.Scheme == Uri.UriSchemeHttps;
            var isLocalHttp = endpoint.Scheme == Uri.UriSchemeHttp && endpoint.IsLoopback;

            if (!isHttps && !isLocalHttp)
            {
                errors.Add($"{section}:TokenEndpoint должен быть https (http разрешён только для localhost).");
            }

            // Без TLS клиентский сертификат передать нельзя.
            if (options.AuthMethod == ClientAuthMethod.TlsClientAuth && !isHttps)
            {
                errors.Add($"Для AuthMethod=TlsClientAuth {section}:TokenEndpoint должен быть https.");
            }
        }

        if (string.IsNullOrWhiteSpace(options.ClientId))
        {
            errors.Add($"{section}:ClientId не задан.");
        }

        if (options.HttpTimeoutSeconds is < 1 or > 600)
        {
            errors.Add($"{section}:HttpTimeoutSeconds должен быть в диапазоне 1..600.");
        }

        switch (options.AuthMethod)
        {
            case ClientAuthMethod.PrivateKeyJwt:
                // KeyId не обязателен: если он пустой, kid вычисляется из ключа.
                if (string.IsNullOrWhiteSpace(options.PrivateKeyPath))
                {
                    errors.Add($"{section}:PrivateKeyPath не задан (создать ключ: oauth-m2m init --config <файл>).");
                }

                if (options.AssertionLifetimeSeconds is < 60 or > 300)
                {
                    errors.Add($"{section}:AssertionLifetimeSeconds должен быть в диапазоне 60..300.");
                }

                break;

            case ClientAuthMethod.TlsClientAuth:
                if (string.IsNullOrWhiteSpace(options.ClientCertificatePath))
                {
                    errors.Add($"{section}:ClientCertificatePath не задан (обязателен для TlsClientAuth).");
                }

                break;

            default:
                errors.Add($"Неизвестное значение {section}:AuthMethod: {options.AuthMethod}.");
                break;
        }

        return errors.Count == 0 ? ValidateOptionsResult.Success : ValidateOptionsResult.Fail(errors);
    }
}
