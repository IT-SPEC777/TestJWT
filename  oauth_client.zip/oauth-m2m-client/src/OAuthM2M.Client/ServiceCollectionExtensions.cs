using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;
using OAuthM2M.Client;
using OAuthM2M.Client.Security;
using OAuthM2M.Client.Tokens;
using OAuthM2M.Client.Transport;

namespace Microsoft.Extensions.DependencyInjection;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Регистрирует <see cref="IOAuthTokenClient"/> с типизированным HttpClient (через IHttpClientFactory),
    /// настройки из секции <c>OAuth</c> и их валидацию.
    /// </summary>
    public static IServiceCollection AddOAuthM2MClient(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<OAuthClientOptions>()
            .Bind(configuration.GetSection(OAuthClientOptions.SectionName));

        // Валидатор срабатывает при первом обращении к IOptions<OAuthClientOptions>.Value.
        services.TryAddEnumerable(
            ServiceDescriptor.Singleton<IValidateOptions<OAuthClientOptions>, OAuthClientOptionsValidator>());

        services.TryAddSingleton(TimeProvider.System);
        services.TryAddSingleton<IClientAssertionFactory, ClientAssertionFactory>();

        services.AddHttpClient<IOAuthTokenClient, OAuthTokenClient>((serviceProvider, httpClient) =>
            {
                var options = serviceProvider.GetRequiredService<IOptions<OAuthClientOptions>>().Value;
                httpClient.Timeout = TimeSpan.FromSeconds(options.HttpTimeoutSeconds);
            })
            .ConfigurePrimaryHttpMessageHandler(serviceProvider =>
                HttpHandlerFactory.Create(serviceProvider.GetRequiredService<IOptions<OAuthClientOptions>>().Value));

        return services;
    }
}
