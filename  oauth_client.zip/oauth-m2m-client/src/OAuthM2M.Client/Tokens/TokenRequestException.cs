namespace OAuthM2M.Client.Tokens;

/// <summary>Не удалось получить токен: сетевая ошибка, таймаут, отказ сервера или некорректный ответ.</summary>
public sealed class TokenRequestException : Exception
{
    public TokenRequestException(string message, int? statusCode = null, string? error = null, Exception? inner = null)
        : base(message, inner)
    {
        StatusCode = statusCode;
        Error = error;
    }

    /// <summary>HTTP-статус ответа; null, если ответа не было (сеть, TLS, таймаут).</summary>
    public int? StatusCode { get; }

    /// <summary>Поле error из ответа OAuth (invalid_client, invalid_scope и т. д.).</summary>
    public string? Error { get; }
}
