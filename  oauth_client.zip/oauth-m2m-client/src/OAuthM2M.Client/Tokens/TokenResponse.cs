using System.Text.Json.Serialization;

namespace OAuthM2M.Client.Tokens;

/// <summary>Успешный ответ токен-эндпоинта (RFC 6749, раздел 5.1).</summary>
public sealed class TokenResponse
{
    [JsonPropertyName("access_token")]
    public string AccessToken { get; set; } = string.Empty;

    /// <summary>Срок жизни токена в секундах.</summary>
    [JsonPropertyName("expires_in")]
    public int ExpiresIn { get; set; }

    [JsonPropertyName("token_type")]
    public string? TokenType { get; set; }

    [JsonPropertyName("scope")]
    public string? Scope { get; set; }
}
