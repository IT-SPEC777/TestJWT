using System.Net.Http.Headers;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Client.Tokens;

/// <summary>
/// Запрашивает access_token по client_credentials.
/// Способ аутентификации клиента (private_key_jwt или mTLS) задаётся настройкой OAuth:AuthMethod.
/// </summary>
public sealed class OAuthTokenClient : IOAuthTokenClient
{
    /// <summary>Фиксированное значение client_assertion_type для JWT-аутентификации (RFC 7523).</summary>
    public const string ClientAssertionType = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer";

    private readonly HttpClient _httpClient;
    private readonly IClientAssertionFactory _assertionFactory;
    private readonly OAuthClientOptions _options;
    private readonly ILogger<OAuthTokenClient> _logger;

    public OAuthTokenClient(
        HttpClient httpClient,
        IClientAssertionFactory assertionFactory,
        IOptions<OAuthClientOptions> options,
        ILogger<OAuthTokenClient> logger)
    {
        _httpClient = httpClient;
        _assertionFactory = assertionFactory;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<TokenResponse> RequestTokenAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var formFields = BuildFormFields();

            _logger.LogInformation(
                "Запрос токена: POST {Endpoint}, client_id={ClientId}, режим={AuthMethod}",
                _options.TokenEndpoint, _options.ClientId, _options.AuthMethod);

            using var request = new HttpRequestMessage(HttpMethod.Post, _options.TokenEndpoint)
            {
                // FormUrlEncodedContent сам выставляет Content-Type: application/x-www-form-urlencoded.
                Content = new FormUrlEncodedContent(formFields)
            };
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            using var response = await _httpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            var responseBody = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                var (error, description) = ParseOAuthError(responseBody);
                var statusCode = (int)response.StatusCode;

                _logger.LogError(
                    "Сервер отказал: HTTP {StatusCode} {Reason}, error={Error}, description={Description}",
                    statusCode, response.ReasonPhrase, error, description);

                var details = error is null ? responseBody : $"{error}: {description}";
                throw new TokenRequestException(
                    $"Сервер авторизации вернул {statusCode} {response.ReasonPhrase}. {details}", statusCode, error);
            }

            var token = JsonSerializer.Deserialize<TokenResponse>(responseBody)
                        ?? throw new TokenRequestException("Пустой ответ токен-эндпоинта.", (int)response.StatusCode);

            // Ответ 200 без токена считается ошибкой.
            if (string.IsNullOrWhiteSpace(token.AccessToken))
            {
                throw new TokenRequestException("В ответе отсутствует access_token.", (int)response.StatusCode);
            }

            _logger.LogInformation("Токен получен, expires_in={ExpiresIn} с", token.ExpiresIn);
            return token;
        }
        catch (TokenRequestException)
        {
            // Уже оформлено и записано в журнал выше.
            throw;
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            // Отмену запросил не вызывающий код, значит сработал таймаут HttpClient.
            _logger.LogError("Таймаут запроса к {Endpoint}", _options.TokenEndpoint);
            throw new TokenRequestException("Таймаут запроса к серверу авторизации.");
        }
        catch (HttpRequestException exception)
        {
            _logger.LogError(exception, "Сетевая или TLS-ошибка при обращении к {Endpoint}", _options.TokenEndpoint);
            throw new TokenRequestException($"Сетевая или TLS-ошибка: {exception.Message}", inner: exception);
        }
        catch (JsonException exception)
        {
            _logger.LogError(exception, "Не удалось разобрать JSON-ответ сервера");
            throw new TokenRequestException("Некорректный JSON в ответе сервера.", inner: exception);
        }
    }

    /// <summary>Поля формы запроса. В режиме private_key_jwt добавляется свежий client_assertion.</summary>
    private Dictionary<string, string> BuildFormFields()
    {
        var fields = new Dictionary<string, string>
        {
            ["grant_type"] = "client_credentials",
            ["client_id"] = _options.ClientId
        };

        if (!string.IsNullOrWhiteSpace(_options.Scope))
        {
            fields["scope"] = _options.Scope;
        }

        if (_options.AuthMethod == ClientAuthMethod.PrivateKeyJwt)
        {
            // Новый JWT на каждый запрос: jti не должен повторяться.
            fields["client_assertion_type"] = ClientAssertionType;
            fields["client_assertion"] = _assertionFactory.Create();
        }

        // При TlsClientAuth клиента подтверждает сертификат в TLS-рукопожатии, assertion не нужен.
        return fields;
    }

    /// <summary>Достаёт error и error_description из тела ответа, если это JSON.</summary>
    private static (string? Error, string? Description) ParseOAuthError(string responseBody)
    {
        try
        {
            using var document = JsonDocument.Parse(responseBody);
            var root = document.RootElement;
            if (root.ValueKind != JsonValueKind.Object)
            {
                return (null, null);
            }

            string? ReadString(string propertyName) =>
                root.TryGetProperty(propertyName, out var value) && value.ValueKind == JsonValueKind.String
                    ? value.GetString()
                    : null;

            return (ReadString("error"), ReadString("error_description"));
        }
        catch (JsonException)
        {
            // Тело не JSON (например, HTML от прокси): в сообщение пойдёт как есть.
            return (null, null);
        }
    }
}
