namespace OAuthM2M.Client.Tokens;

public interface IOAuthTokenClient
{
    /// <summary>Запрашивает access_token у сервера авторизации.</summary>
    /// <exception cref="TokenRequestException">Сервер отказал в выдаче токена или запрос не удался.</exception>
    Task<TokenResponse> RequestTokenAsync(CancellationToken cancellationToken = default);
}
