namespace OAuthM2M.Client.Security;

/// <summary>Маскирование токенов и других секретов перед выводом в консоль или журнал.</summary>
public static class SecretMasker
{
    /// <summary>
    /// Оставляет первые 8 и последние 4 символа и показывает длину.
    /// Короткие значения скрываются полностью.
    /// </summary>
    public static string Mask(string? value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return "<empty>";
        }

        return value.Length <= 16
            ? "***"
            : $"{value[..8]}...{value[^4..]} (len={value.Length})";
    }
}
