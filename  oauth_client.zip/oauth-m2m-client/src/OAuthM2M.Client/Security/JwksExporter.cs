namespace OAuthM2M.Client.Security;

/// <summary>
/// Строит публичный JWKS по настройкам клиента. Этот документ регистрируется на сервере авторизации,
/// а kid в нём должен совпадать с kid в заголовке client_assertion.
/// </summary>
public static class JwksExporter
{
    public static string ExportPublicJwks(OAuthClientOptions options)
    {
        ArgumentNullException.ThrowIfNull(options);

        if (string.IsNullOrWhiteSpace(options.PrivateKeyPath))
        {
            throw new InvalidOperationException("OAuth:PrivateKeyPath не задан.");
        }

        using var rsa = PrivateKeyLoader.Load(options.PrivateKeyPath, options.PrivateKeyPassword);

        // Та же логика выбора kid, что и в ClientAssertionFactory.
        var keyId = string.IsNullOrWhiteSpace(options.KeyId)
            ? KeyIdProvider.ComputeThumbprint(rsa)
            : options.KeyId;

        return KeyPairGenerator.BuildJwks(rsa, keyId);
    }
}
