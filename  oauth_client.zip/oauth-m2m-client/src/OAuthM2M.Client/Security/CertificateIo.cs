using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace OAuthM2M.Client.Security;

/// <summary>
/// Загрузка сертификатов. Конструкторы X509Certificate2(path/bytes) в .NET 9+ помечены устаревшими
/// (SYSLIB0057) в пользу X509CertificateLoader, а в .NET 8 этого класса нет, поэтому выбор API
/// сделан через условную компиляцию.
/// </summary>
internal static class CertificateIo
{
    public static X509Certificate2 LoadPkcs12(string path, string? password)
    {
#if NET9_0_OR_GREATER
        return X509CertificateLoader.LoadPkcs12FromFile(path, password);
#else
        return new X509Certificate2(path, password);
#endif
    }

    public static X509Certificate2 LoadPkcs12(byte[] data, string? password)
    {
#if NET9_0_OR_GREATER
        return X509CertificateLoader.LoadPkcs12(data, password);
#else
        return new X509Certificate2(data, password);
#endif
    }

    /// <summary>
    /// Читает один или несколько сертификатов без закрытых ключей: PEM (в том числе цепочку
    /// из нескольких сертификатов) или одиночный DER-файл.
    /// </summary>
    public static X509Certificate2Collection LoadCertificates(string path)
    {
        var bytes = File.ReadAllBytes(path);
        var certificates = new X509Certificate2Collection();
        var text = Encoding.ASCII.GetString(bytes);

        if (text.Contains("-----BEGIN CERTIFICATE-----", StringComparison.Ordinal))
        {
            certificates.ImportFromPem(text);
        }
        else
        {
#if NET9_0_OR_GREATER
            certificates.Add(X509CertificateLoader.LoadCertificate(bytes));
#else
            certificates.Add(new X509Certificate2(bytes));
#endif
        }

        return certificates;
    }
}
