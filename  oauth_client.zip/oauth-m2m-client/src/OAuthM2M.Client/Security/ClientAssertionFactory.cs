using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace OAuthM2M.Client.Security;

/// <summary>
/// Собирает и подписывает client_assertion по RFC 7523: алгоритм RS256, kid в заголовке,
/// claims iss, sub, aud, jti, iat, nbf, exp. Ключ читается при первом вызове и дальше переиспользуется.
/// </summary>
public sealed class ClientAssertionFactory : IClientAssertionFactory, IDisposable
{
    private readonly OAuthClientOptions _options;
    private readonly TimeProvider _timeProvider;
    private readonly ILogger<ClientAssertionFactory> _logger;
    private readonly JwtSecurityTokenHandler _handler = new();

    // Lazy: в режиме mTLS ключ не нужен, а команды вроде doctor не должны падать из-за его отсутствия до проверки.
    private readonly Lazy<(RSA Rsa, SigningCredentials Credentials)> _signingMaterial;

    public ClientAssertionFactory(
        IOptions<OAuthClientOptions> options,
        TimeProvider timeProvider,
        ILogger<ClientAssertionFactory> logger)
    {
        _options = options.Value;
        _timeProvider = timeProvider;
        _logger = logger;
        _signingMaterial = new Lazy<(RSA Rsa, SigningCredentials Credentials)>(LoadSigningMaterial);
    }

    public string Create()
    {
        var now = _timeProvider.GetUtcNow().UtcDateTime;
        var issuedAt = new DateTimeOffset(now).ToUnixTimeSeconds();

        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, _options.ClientId),

            // jti нужен серверу для защиты от повторного использования assertion.
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("D")),

            // iat должен быть числом (NumericDate), а не строкой.
            new(JwtRegisteredClaimNames.Iat, issuedAt.ToString(CultureInfo.InvariantCulture), ClaimValueTypes.Integer64)
        };

        var token = new JwtSecurityToken(
            issuer: _options.ClientId,
            audience: _options.EffectiveAudience,
            claims: claims,
            notBefore: now,
            expires: now.AddSeconds(_options.AssertionLifetimeSeconds),
            signingCredentials: _signingMaterial.Value.Credentials);

        var jwt = _handler.WriteToken(token);

        _logger.LogDebug(
            "Собран client_assertion: kid={Kid}, aud={Audience}, срок={LifetimeSeconds} с",
            _signingMaterial.Value.Credentials.Key.KeyId,
            _options.EffectiveAudience,
            _options.AssertionLifetimeSeconds);

        return jwt;
    }

    private (RSA Rsa, SigningCredentials Credentials) LoadSigningMaterial()
    {
        if (string.IsNullOrWhiteSpace(_options.PrivateKeyPath))
        {
            throw new InvalidOperationException("OAuth:PrivateKeyPath не задан.");
        }

        var rsa = PrivateKeyLoader.Load(_options.PrivateKeyPath, _options.PrivateKeyPassword);

        // Если kid не задан, берём отпечаток ключа: он совпадёт с kid в JWKS, сделанном из этого же ключа.
        var keyId = string.IsNullOrWhiteSpace(_options.KeyId)
            ? KeyIdProvider.ComputeThumbprint(rsa)
            : _options.KeyId;

        _logger.LogInformation("Загружен ключ подписи: {KeySizeBits} бит, kid={Kid}", rsa.KeySize, keyId);

        var securityKey = new RsaSecurityKey(rsa) { KeyId = keyId };
        return (rsa, new SigningCredentials(securityKey, SecurityAlgorithms.RsaSha256));
    }

    public void Dispose()
    {
        if (_signingMaterial.IsValueCreated)
        {
            _signingMaterial.Value.Rsa.Dispose();
        }
    }
}
