using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.IdentityModel.Tokens;

namespace OAuthM2M.Client.Security;

/// <summary>Файлы, созданные при генерации ключевой пары.</summary>
/// <param name="PrivateKeyPath">Приватный ключ (PKCS#8 PEM, на Unix права 0600).</param>
/// <param name="PublicKeyPath">Публичный ключ (SubjectPublicKeyInfo PEM).</param>
/// <param name="JwksPath">Публичный JWKS для регистрации на сервере.</param>
/// <param name="KeyId">Итоговый kid: заданный явно или отпечаток ключа.</param>
public sealed record KeyPairArtifacts(
    string PrivateKeyPath,
    string PublicKeyPath,
    string JwksPath,
    string KeyId);

/// <summary>
/// Генерация пары RSA-2048 для режима private_key_jwt. Используется командой init и тестами.
/// Рядом с приватным ключом создаются файлы <c>*.public.pem</c> и <c>*.jwks.json</c>.
/// </summary>
public static class KeyPairGenerator
{
    private const int KeySizeBits = 2048;

    private const UnixFileMode OwnerReadWrite = UnixFileMode.UserRead | UnixFileMode.UserWrite;

    /// <param name="privateKeyPath">Куда сохранить приватный ключ.</param>
    /// <param name="overwrite">Перезаписать существующий ключ. По умолчанию нет: старый ключ после этого не восстановить.</param>
    /// <param name="keyId">Свой kid; если не задан, берётся отпечаток ключа.</param>
    /// <param name="privateKeyPassword">Если задан, приватный ключ шифруется (AES-256).</param>
    public static KeyPairArtifacts Generate(
        string privateKeyPath,
        bool overwrite = false,
        string? keyId = null,
        string? privateKeyPassword = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(privateKeyPath);

        var fullPrivatePath = Path.GetFullPath(privateKeyPath);
        var directory = Path.GetDirectoryName(fullPrivatePath)
            ?? throw new ArgumentException("Не удалось определить каталог для ключа.", nameof(privateKeyPath));
        Directory.CreateDirectory(directory);

        if (File.Exists(fullPrivatePath) && !overwrite)
        {
            throw new IOException($"Файл уже существует: {fullPrivatePath}. Для перезаписи укажите --force.");
        }

        using var rsa = RSA.Create(KeySizeBits);

        var effectiveKeyId = string.IsNullOrWhiteSpace(keyId)
            ? KeyIdProvider.ComputeThumbprint(rsa)
            : keyId;

        var privatePem = string.IsNullOrEmpty(privateKeyPassword)
            ? rsa.ExportPkcs8PrivateKeyPem()
            : rsa.ExportEncryptedPkcs8PrivateKeyPem(
                privateKeyPassword,
                new PbeParameters(PbeEncryptionAlgorithm.Aes256Cbc, HashAlgorithmName.SHA256, 100_000));

        WritePrivateKey(fullPrivatePath, privatePem);

        var publicKeyPath = Path.ChangeExtension(fullPrivatePath, ".public.pem");
        File.WriteAllText(publicKeyPath, rsa.ExportSubjectPublicKeyInfoPem());

        var jwksPath = Path.ChangeExtension(fullPrivatePath, ".jwks.json");
        File.WriteAllText(jwksPath, BuildJwks(rsa, effectiveKeyId));

        return new KeyPairArtifacts(fullPrivatePath, publicKeyPath, jwksPath, effectiveKeyId);
    }

    /// <summary>
    /// Записывает приватный ключ. На Unix файл сразу создаётся с правами 0600, чтобы между созданием
    /// и последующим chmod его нельзя было прочитать другим пользователям.
    /// </summary>
    private static void WritePrivateKey(string path, string pem)
    {
        var streamOptions = new FileStreamOptions
        {
            Mode = FileMode.Create,
            Access = FileAccess.Write,
            Share = FileShare.None
        };

        if (!OperatingSystem.IsWindows())
        {
            streamOptions.UnixCreateMode = OwnerReadWrite;
        }

        using (var stream = new FileStream(path, streamOptions))
        using (var writer = new StreamWriter(stream))
        {
            writer.Write(pem);
        }

        // При перезаписи существующего файла UnixCreateMode не применяется, поэтому права ставим ещё раз.
        if (!OperatingSystem.IsWindows())
        {
            File.SetUnixFileMode(path, OwnerReadWrite);
        }
    }

    internal static string BuildJwks(RSA rsa, string keyId)
    {
        var parameters = rsa.ExportParameters(includePrivateParameters: false);

        var jwks = new
        {
            keys = new[]
            {
                new
                {
                    kty = "RSA",
                    use = "sig",
                    alg = "RS256",
                    kid = keyId,
                    n = Base64UrlEncoder.Encode(parameters.Modulus!),
                    e = Base64UrlEncoder.Encode(parameters.Exponent!)
                }
            }
        };

        return JsonSerializer.Serialize(jwks, new JsonSerializerOptions { WriteIndented = true });
    }
}
