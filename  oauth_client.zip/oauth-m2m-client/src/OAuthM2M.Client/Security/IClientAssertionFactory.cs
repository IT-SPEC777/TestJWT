namespace OAuthM2M.Client.Security;

/// <summary>
/// Источник client_assertion. Вынесен в интерфейс, чтобы подпись можно было заменить
/// (HSM, Vault, хранилище сертификатов ОС) без изменения остального кода.
/// </summary>
public interface IClientAssertionFactory
{
    /// <summary>Создаёт новый подписанный JWT с уникальным jti. Вызывается на каждый запрос токена.</summary>
    string Create();
}
