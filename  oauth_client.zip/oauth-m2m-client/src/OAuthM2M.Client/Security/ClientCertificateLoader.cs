using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace OAuthM2M.Client.Security;

/// <summary>Загрузка клиентского сертификата для mTLS: PFX/P12 либо пара файлов PEM (сертификат и ключ).</summary>
public static class ClientCertificateLoader
{
    /// <summary>Возвращает сертификат вместе с закрытым ключом. Освобождать результат должен вызывающий код.</summary>
    public static X509Certificate2 Load(OAuthClientOptions options)
    {
        var certificatePath = options.ClientCertificatePath
                              ?? throw new InvalidOperationException("OAuth:ClientCertificatePath не задан.");

        if (!File.Exists(certificatePath))
        {
            throw new FileNotFoundException($"Файл клиентского сертификата не найден: {certificatePath}", certificatePath);
        }

        X509Certificate2 certificate;

        if (IsPkcs12(certificatePath))
        {
            certificate = CertificateIo.LoadPkcs12(certificatePath, options.ClientCertificatePassword);
        }
        else
        {
            var keyPath = options.ClientCertificateKeyPath
                          ?? throw new InvalidOperationException(
                              "Для сертификата в PEM укажите OAuth:ClientCertificateKeyPath.");

            if (!File.Exists(keyPath))
            {
                throw new FileNotFoundException($"Файл ключа клиентского сертификата не найден: {keyPath}", keyPath);
            }

            certificate = string.IsNullOrEmpty(options.ClientCertificatePassword)
                ? X509Certificate2.CreateFromPemFile(certificatePath, keyPath)
                : X509Certificate2.CreateFromEncryptedPemFile(certificatePath, options.ClientCertificatePassword, keyPath);

            // На Windows ключ, импортированный из PEM, получается эфемерным, и SslStream его
            // не использует (клиентский сертификат тихо не отправляется). Обходим пересохранением через PKCS#12.
            if (OperatingSystem.IsWindows())
            {
                var pfxBytes = certificate.Export(X509ContentType.Pfx);
                certificate.Dispose();
                certificate = CertificateIo.LoadPkcs12(pfxBytes, password: null);
            }
        }

        // Сертификат без ключа для mTLS бесполезен; лучше упасть здесь, чем получить невнятную TLS-ошибку.
        if (!certificate.HasPrivateKey)
        {
            certificate.Dispose();
            throw new CryptographicException("В клиентском сертификате нет приватного ключа.");
        }

        return certificate;
    }

    private static bool IsPkcs12(string path) =>
        path.EndsWith(".pfx", StringComparison.OrdinalIgnoreCase) ||
        path.EndsWith(".p12", StringComparison.OrdinalIgnoreCase);
}
