using System.Security.Cryptography;
using Microsoft.IdentityModel.Tokens;

namespace OAuthM2M.Client.Security;

/// <summary>
/// Вычисляет идентификатор ключа (kid) как JWK Thumbprint по RFC 7638.
/// Для одного и того же ключа результат всегда одинаковый, поэтому kid не нужно согласовывать вручную
/// между JWT, JWKS и конфигом; при смене ключа kid меняется сам.
/// </summary>
public static class KeyIdProvider
{
    /// <summary>Возвращает отпечаток публичной части ключа (SHA-256, Base64Url).</summary>
    public static string ComputeThumbprint(RSA rsa)
    {
        ArgumentNullException.ThrowIfNull(rsa);

        var jwk = JsonWebKeyConverter.ConvertFromRSASecurityKey(new RsaSecurityKey(rsa));
        return Base64UrlEncoder.Encode(jwk.ComputeJwkThumbprint());
    }
}
