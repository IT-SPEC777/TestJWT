namespace OAuthM2M.Client;

/// <summary>
/// Настройки клиента, секция конфигурации <c>OAuth</c>.
/// Секретов в открытом виде здесь нет: в конфиге лежат только пути к файлам ключей и сертификатов.
/// </summary>
public sealed class OAuthClientOptions
{
    public const string SectionName = "OAuth";

    /// <summary>URL токен-эндпоинта. Допускается только https; http разрешён для localhost.</summary>
    public string TokenEndpoint { get; set; } = string.Empty;

    /// <summary>Идентификатор клиента (client_id), заданный на сервере авторизации.</summary>
    public string ClientId { get; set; } = string.Empty;

    /// <summary>Способ аутентификации клиента. По умолчанию private_key_jwt.</summary>
    public ClientAuthMethod AuthMethod { get; set; } = ClientAuthMethod.PrivateKeyJwt;

    /// <summary>Запрашиваемые scope через пробел. Необязательный параметр.</summary>
    public string? Scope { get; set; }

    // ----- private_key_jwt -----

    /// <summary>
    /// Значение claim aud в клиентском JWT. Если не задано, используется <see cref="TokenEndpoint"/>.
    /// Некоторые серверы (например, Keycloak 26+) ожидают issuer realm'а, тогда его нужно указать явно.
    /// </summary>
    public string? Audience { get; set; }

    /// <summary>
    /// Идентификатор ключа (kid в заголовке JWT). Если не задан, вычисляется из ключа по RFC 7638,
    /// и в этом случае совпадает с kid в JWKS, который создаёт команда init.
    /// </summary>
    public string? KeyId { get; set; }

    /// <summary>Путь к приватному ключу RSA в формате PEM (PKCS#8 или PKCS#1).</summary>
    public string? PrivateKeyPath { get; set; }

    /// <summary>Пароль к зашифрованному ключу. Лучше передавать через переменную окружения.</summary>
    public string? PrivateKeyPassword { get; set; }

    /// <summary>Время жизни client_assertion в секундах (допустимо 60-300).</summary>
    public int AssertionLifetimeSeconds { get; set; } = 120;

    // ----- mTLS -----

    /// <summary>Клиентский сертификат: .pfx/.p12 либо PEM (для PEM нужен <see cref="ClientCertificateKeyPath"/>).</summary>
    public string? ClientCertificatePath { get; set; }

    /// <summary>Приватный ключ клиентского сертификата в PEM, если сам сертификат тоже PEM.</summary>
    public string? ClientCertificateKeyPath { get; set; }

    /// <summary>Пароль к PFX или к зашифрованному PEM-ключу.</summary>
    public string? ClientCertificatePassword { get; set; }

    // ----- общие -----

    /// <summary>
    /// Корневой или промежуточный сертификат УЦ сервера (PEM или DER).
    /// Нужен, если сервер подписан корпоративным УЦ, которого нет в системном хранилище.
    /// </summary>
    public string? ServerCaCertificatePath { get; set; }

    /// <summary>Таймаут HTTP-запроса в секундах.</summary>
    public int HttpTimeoutSeconds { get; set; } = 30;

    /// <summary>Значение aud с учётом значения по умолчанию.</summary>
    public string EffectiveAudience =>
        string.IsNullOrWhiteSpace(Audience) ? TokenEndpoint : Audience;
}
