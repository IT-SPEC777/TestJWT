using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OAuthM2M.Client;
using OAuthM2M.Client.Diagnostics;
using OAuthM2M.Client.NiFi;
using OAuthM2M.Client.Security;
using OAuthM2M.Client.Tokens;

namespace OAuthM2M.Cli.Commands;

/// <summary>
/// run: получает access_token и, если в конфиге заданы NiFi:Endpoint и JsonPath,
/// отправляет JSON-файл в NiFi с токеном в заголовке Authorization.
/// </summary>
public sealed class RunCommand : ICommand
{
    public string Name => "run";
    public string Description => "Получить access_token и отправить JSON в NiFi.";

    public async Task<int> ExecuteAsync(string[] args, CancellationToken cancellationToken)
    {
        var (remainingArgs, configPath) = CommandConfiguration.ExtractConfigArgument(args);

        var builder = Host.CreateApplicationBuilder(new HostApplicationBuilderSettings
        {
            Args = remainingArgs,
            // appsettings.json лежит рядом с программой, а не в текущем каталоге.
            ContentRootPath = AppContext.BaseDirectory
        });

        // Журнал пишет Serilog (настраивается в Program.cs), стандартные провайдеры отключены.
        builder.Logging.ClearProviders();
        builder.Logging.AddSerilog(Serilog.Log.Logger);

        var configDirectory = Directory.GetCurrentDirectory();
        if (!string.IsNullOrWhiteSpace(configPath))
        {
            var fullConfigPath = Path.GetFullPath(configPath);
            configDirectory = Path.GetDirectoryName(fullConfigPath) ?? configDirectory;

            // Файл конфигурации добавляется поверх appsettings.json. Переменные окружения и аргументы
            // подключаются повторно, чтобы они по-прежнему имели приоритет над файлом.
            builder.Configuration
                .AddJsonFile(fullConfigPath, optional: false, reloadOnChange: false)
                .AddEnvironmentVariables()
                .AddCommandLine(remainingArgs);
        }

        builder.Services.AddOAuthM2MClient(builder.Configuration);

        // NiFi подключается только при заданном адресе: без него команда просто получает токен.
        var nifiEndpoint = builder.Configuration[$"{NiFiOptions.SectionName}:{nameof(NiFiOptions.Endpoint)}"];
        if (!string.IsNullOrWhiteSpace(nifiEndpoint))
        {
            builder.Services.Configure<NiFiOptions>(builder.Configuration.GetSection(NiFiOptions.SectionName));
            builder.Services.PostConfigure<NiFiOptions>(nifi =>
                nifi.ServerCaCertificatePath = CommandConfiguration.ResolvePath(nifi.ServerCaCertificatePath, configDirectory));
            builder.Services.AddSingleton<NiFiHttpClient>();
        }

        using var host = builder.Build();

        // Пути нужно привести к абсолютным до первого использования клиента: HTTP-обработчик
        // и фабрика assertion читают файлы при первом обращении. Обращение к .Value заодно запускает валидацию.
        var options = host.Services.GetRequiredService<IOptions<OAuthClientOptions>>().Value;
        CommandConfiguration.ResolveRelativePaths(options, configDirectory);

        var client = host.Services.GetRequiredService<IOAuthTokenClient>();

        TokenResponse token;
        try
        {
            token = await client.RequestTokenAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (TokenRequestException exception)
        {
            Console.Error.WriteLine(AnsiConsole.Red($"Токен не получен: {exception.Message}"));
            foreach (var hint in ErrorAdvisor.Advise(exception, options))
            {
                Console.Error.WriteLine($"  -> {hint}");
            }

            return 1;
        }

        Console.WriteLine($"Режим:        {options.AuthMethod}");
        Console.WriteLine($"token_type:   {token.TokenType}");
        Console.WriteLine($"expires_in:   {token.ExpiresIn} c");
        Console.WriteLine($"access_token: {SecretMasker.Mask(token.AccessToken)}");

        var jsonPath = builder.Configuration["JsonPath"];
        if (!string.IsNullOrWhiteSpace(nifiEndpoint) && !string.IsNullOrWhiteSpace(jsonPath))
        {
            var fullJsonPath = Path.IsPathRooted(jsonPath) ? jsonPath : Path.GetFullPath(jsonPath, configDirectory);
            var json = await File.ReadAllTextAsync(fullJsonPath, cancellationToken).ConfigureAwait(false);

            var nifi = host.Services.GetRequiredService<NiFiHttpClient>();
            await nifi.SendJsonAsync(json, token.AccessToken, cancellationToken).ConfigureAwait(false);

            Console.WriteLine($"JSON отправлен в NiFi: {fullJsonPath}");
        }

        return 0;
    }
}
