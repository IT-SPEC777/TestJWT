using System.Text.Json;
using OAuthM2M.Client.Diagnostics;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Cli.Commands;

/// <summary>
/// init: создаёт пару ключей RSA-2048 рядом с файлом конфигурации (каталог secrets)
/// и дописывает в секцию OAuth значения KeyId и PrivateKeyPath, если они ещё не заданы.
/// Значения, указанные вручную, не изменяются.
/// </summary>
public sealed class InitCommand : ICommand
{
    public string Name => "init";
    public string Description => "Сгенерировать пару ключей и дополнить конфиг (KeyId, PrivateKeyPath).";

    public Task<int> ExecuteAsync(string[] args, CancellationToken cancellationToken)
    {
        var configPath = GetOption(args, "--config");
        var overwrite = args.Contains("--force", StringComparer.OrdinalIgnoreCase);

        if (string.IsNullOrWhiteSpace(configPath))
        {
            Console.Error.WriteLine(AnsiConsole.Red("Укажите --config <файл.json>."));
            return Task.FromResult(2);
        }

        var fullConfigPath = Path.GetFullPath(configPath);
        var configDirectory = Path.GetDirectoryName(fullConfigPath) ?? ".";

        // Ключ создаётся рядом с конфигом, чтобы в JSON попал короткий относительный путь.
        var privateKeyPath = Path.Combine(configDirectory, "secrets", "private.pem");

        var artifacts = KeyPairGenerator.Generate(privateKeyPath, overwrite);
        Console.WriteLine($"{AnsiConsole.Green("[ OK ]")} Приватный ключ: {artifacts.PrivateKeyPath}");
        Console.WriteLine($"{AnsiConsole.Green("[ OK ]")} Публичный ключ: {artifacts.PublicKeyPath}");
        Console.WriteLine($"{AnsiConsole.Green("[ OK ]")} JWKS: {artifacts.JwksPath}");
        Console.WriteLine($"{AnsiConsole.Green("[ OK ]")} kid: {artifacts.KeyId}");

        FillConfigIfEmpty(fullConfigPath, artifacts);
        Console.WriteLine($"{AnsiConsole.Green("[ OK ]")} Конфиг обновлён: {fullConfigPath}");
        Console.WriteLine();
        Console.WriteLine(AnsiConsole.Dim(
            "Зарегистрируйте JWKS на сервере (FAM: раздел сертификатов / JWKs URI; Keycloak: Clients -> Keys)."));

        return Task.FromResult(0);
    }

    /// <summary>
    /// Переписывает конфиг, подставляя KeyId и PrivateKeyPath только в пустые или отсутствующие поля.
    /// Остальное содержимое сохраняется (комментарии в JSON при этом теряются).
    /// </summary>
    private static void FillConfigIfEmpty(string configPath, KeyPairArtifacts artifacts)
    {
        if (!File.Exists(configPath))
        {
            throw new FileNotFoundException(
                $"Конфиг не найден: {configPath}. Создайте его из шаблона config/*.json.", configPath);
        }

        var configDirectory = Path.GetDirectoryName(configPath) ?? ".";

        // В конфиге путь хранится относительным и с прямыми слэшами, чтобы файл работал и на Windows, и на Linux.
        var relativeKeyPath = Path.GetRelativePath(configDirectory, artifacts.PrivateKeyPath).Replace('\\', '/');

        using var document = JsonDocument.Parse(File.ReadAllText(configPath));
        using var buffer = new MemoryStream();

        using (var writer = new Utf8JsonWriter(buffer, new JsonWriterOptions { Indented = true }))
        {
            writer.WriteStartObject();

            foreach (var property in document.RootElement.EnumerateObject())
            {
                if (property.NameEquals("OAuth") && property.Value.ValueKind == JsonValueKind.Object)
                {
                    writer.WritePropertyName("OAuth");
                    WriteOAuthSection(writer, property.Value, artifacts, relativeKeyPath);
                }
                else
                {
                    writer.WritePropertyName(property.Name);
                    property.Value.WriteTo(writer);
                }
            }

            writer.WriteEndObject();
        }

        File.WriteAllBytes(configPath, buffer.ToArray());
    }

    private static void WriteOAuthSection(
        Utf8JsonWriter writer,
        JsonElement section,
        KeyPairArtifacts artifacts,
        string relativeKeyPath)
    {
        var keyIdWritten = false;
        var keyPathWritten = false;

        writer.WriteStartObject();

        foreach (var property in section.EnumerateObject())
        {
            // Пустое поле подменяем сгенерированным значением на месте. Дописывать второе поле
            // с тем же именем нельзя: провайдер конфигурации не принимает повторяющиеся ключи.
            if (property.NameEquals("KeyId"))
            {
                writer.WriteString("KeyId", IsEmptyString(property.Value) ? artifacts.KeyId : property.Value.GetString());
                keyIdWritten = true;
            }
            else if (property.NameEquals("PrivateKeyPath"))
            {
                writer.WriteString("PrivateKeyPath", IsEmptyString(property.Value) ? relativeKeyPath : property.Value.GetString());
                keyPathWritten = true;
            }
            else
            {
                writer.WritePropertyName(property.Name);
                property.Value.WriteTo(writer);
            }
        }

        if (!keyIdWritten)
        {
            writer.WriteString("KeyId", artifacts.KeyId);
        }

        if (!keyPathWritten)
        {
            writer.WriteString("PrivateKeyPath", relativeKeyPath);
        }

        writer.WriteEndObject();
    }

    private static bool IsEmptyString(JsonElement value) =>
        value.ValueKind != JsonValueKind.String || string.IsNullOrWhiteSpace(value.GetString());

    /// <summary>Значение параметра в формах "--имя значение" и "--имя=значение".</summary>
    private static string? GetOption(string[] args, string name)
    {
        for (var index = 0; index < args.Length; index++)
        {
            if (args[index].StartsWith(name + "=", StringComparison.OrdinalIgnoreCase))
            {
                return args[index][(name.Length + 1)..];
            }

            if (string.Equals(args[index], name, StringComparison.OrdinalIgnoreCase) && index + 1 < args.Length)
            {
                return args[index + 1];
            }
        }

        return null;
    }
}
