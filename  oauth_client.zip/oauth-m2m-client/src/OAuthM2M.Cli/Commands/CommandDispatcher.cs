using OAuthM2M.Client.Diagnostics;

namespace OAuthM2M.Cli.Commands;

/// <summary>Выбирает команду по первому аргументу и передаёт ей управление.</summary>
public sealed class CommandDispatcher
{
    private readonly IReadOnlyDictionary<string, ICommand> _commands;

    public CommandDispatcher(IEnumerable<ICommand> commands)
    {
        _commands = commands.ToDictionary(command => command.Name, StringComparer.OrdinalIgnoreCase);
    }

    public async Task<int> DispatchAsync(string[] args, CancellationToken cancellationToken)
    {
        // Команда - первый аргумент. Если он начинается с дефиса (или аргументов нет), выполняется run.
        var commandName = args.Length > 0 && !args[0].StartsWith('-') ? args[0] : "run";

        if (commandName.Equals("help", StringComparison.OrdinalIgnoreCase)
            || args.Any(argument => argument is "--help" or "-h"))
        {
            PrintHelp();
            return 0;
        }

        if (!_commands.TryGetValue(commandName, out var command))
        {
            Console.Error.WriteLine(AnsiConsole.Red($"Неизвестная команда: {commandName}"));
            PrintHelp();
            return 2;
        }

        return await command.ExecuteAsync(args, cancellationToken).ConfigureAwait(false);
    }

    public void PrintHelp()
    {
        Console.WriteLine(AnsiConsole.Bold("oauth-m2m - клиент OAuth 2.0 (client_credentials)"));
        Console.WriteLine();
        Console.WriteLine("Использование: oauth-m2m <команда> [параметры]");
        Console.WriteLine();
        Console.WriteLine("Команды:");
        foreach (var command in _commands.Values)
        {
            Console.WriteLine($"  {AnsiConsole.Cyan(command.Name.PadRight(10))} {command.Description}");
        }

        Console.WriteLine();
        Console.WriteLine("Параметры:");
        Console.WriteLine($"  {AnsiConsole.Cyan("--config <файл>".PadRight(22))} файл конфигурации (JSON)");
        Console.WriteLine($"  {AnsiConsole.Cyan("--Секция:Ключ=значение".PadRight(22))} переопределить параметр, например --OAuth:ClientId=my-service");
        Console.WriteLine($"  {AnsiConsole.Cyan("--force".PadRight(22))} init: перезаписать существующий ключ");
        Console.WriteLine($"  {AnsiConsole.Cyan("--Inspect=true".PadRight(22))} assertion: показать заголовок и claims");
        Console.WriteLine($"  {AnsiConsole.Cyan("--verbose".PadRight(22))} подробный журнал");
        Console.WriteLine($"  {AnsiConsole.Cyan("--no-color".PadRight(22))} без цветов (также учитывается NO_COLOR)");
    }
}
