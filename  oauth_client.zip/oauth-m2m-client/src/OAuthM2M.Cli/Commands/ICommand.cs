namespace OAuthM2M.Cli.Commands;

/// <summary>
/// Контракт CLI-команды. Новая команда добавляется реализацией этого интерфейса
/// и регистрацией в списке в Program.cs, остальной код менять не нужно.
/// </summary>
public interface ICommand
{
    /// <summary>Имя команды в командной строке (run, init, assertion, doctor).</summary>
    string Name { get; }

    /// <summary>Короткое описание для справки.</summary>
    string Description { get; }

    /// <summary>Выполняет команду и возвращает код возврата процесса.</summary>
    Task<int> ExecuteAsync(string[] args, CancellationToken cancellationToken);
}
