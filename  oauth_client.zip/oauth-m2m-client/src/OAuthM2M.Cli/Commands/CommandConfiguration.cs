using Microsoft.Extensions.Configuration;
using OAuthM2M.Client;

namespace OAuthM2M.Cli.Commands;

/// <summary>
/// Общая работа с конфигурацией для команд.
/// Источники по возрастанию приоритета: appsettings.json (рядом с программой), файл из --config,
/// переменные окружения (OAuth__ClientId), аргументы командной строки.
/// Относительные пути к ключам и сертификатам считаются от каталога файла конфигурации,
/// а если --config не указан - от текущего каталога.
/// </summary>
internal static class CommandConfiguration
{
    /// <summary>
    /// Читает секцию OAuth без валидации. Используется командами doctor и assertion,
    /// которые должны работать и на неполной конфигурации.
    /// </summary>
    public static OAuthClientOptions LoadOptions(string[] args)
    {
        // Значение --config известно только после первого прохода по аргументам.
        var preliminary = CreateBuilder(args, configFile: null).Build();
        var configFile = preliminary["config"];

        var configuration = string.IsNullOrWhiteSpace(configFile)
            ? preliminary
            : CreateBuilder(args, configFile).Build();

        var options = configuration.GetSection(OAuthClientOptions.SectionName).Get<OAuthClientOptions>()
                      ?? new OAuthClientOptions();

        var baseDirectory = string.IsNullOrWhiteSpace(configFile)
            ? Directory.GetCurrentDirectory()
            : Path.GetDirectoryName(Path.GetFullPath(configFile)) ?? Directory.GetCurrentDirectory();

        ResolveRelativePaths(options, baseDirectory);
        return options;
    }

    /// <summary>Выделяет --config из аргументов (формы "--config файл" и "--config=файл") и возвращает остальные.</summary>
    public static (string[] RemainingArgs, string? ConfigPath) ExtractConfigArgument(string[] args)
    {
        var remaining = new List<string>(args.Length);
        string? configPath = null;

        for (var index = 0; index < args.Length; index++)
        {
            if (args[index].StartsWith("--config=", StringComparison.OrdinalIgnoreCase))
            {
                configPath = args[index]["--config=".Length..];
            }
            else if (string.Equals(args[index], "--config", StringComparison.OrdinalIgnoreCase) && index + 1 < args.Length)
            {
                configPath = args[index + 1];
                index++;
            }
            else
            {
                remaining.Add(args[index]);
            }
        }

        return (remaining.ToArray(), configPath);
    }

    /// <summary>Приводит пути к ключам и сертификатам из секции OAuth к абсолютным.</summary>
    public static void ResolveRelativePaths(OAuthClientOptions options, string baseDirectory)
    {
        options.PrivateKeyPath = ResolvePath(options.PrivateKeyPath, baseDirectory);
        options.ClientCertificatePath = ResolvePath(options.ClientCertificatePath, baseDirectory);
        options.ClientCertificateKeyPath = ResolvePath(options.ClientCertificateKeyPath, baseDirectory);
        options.ServerCaCertificatePath = ResolvePath(options.ServerCaCertificatePath, baseDirectory);
    }

    public static string? ResolvePath(string? path, string baseDirectory) =>
        string.IsNullOrWhiteSpace(path) || Path.IsPathRooted(path)
            ? path
            : Path.GetFullPath(path, baseDirectory);

    private static IConfigurationBuilder CreateBuilder(string[] args, string? configFile)
    {
        var builder = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: true);

        if (!string.IsNullOrWhiteSpace(configFile))
        {
            builder.AddJsonFile(Path.GetFullPath(configFile), optional: false);
        }

        return builder
            .AddEnvironmentVariables()
            .AddCommandLine(args);
    }
}
