using OAuthM2M.Client.Diagnostics;

namespace OAuthM2M.Cli.Commands;

/// <summary>
/// doctor: проверяет конфигурацию, ключ и discovery-документ сервера и печатает отчёт.
/// Нужна, чтобы увидеть вероятную причину invalid_client до запроса токена.
/// </summary>
public sealed class DoctorCommand : ICommand
{
    public string Name => "doctor";
    public string Description => "Проверить конфиг, ключ и discovery сервера.";

    public async Task<int> ExecuteAsync(string[] args, CancellationToken cancellationToken)
    {
        var options = CommandConfiguration.LoadOptions(args);

        var runner = new PreflightRunner(options, TimeProvider.System);
        var results = await runner.RunAsync(cancellationToken).ConfigureAwait(false);

        CheckResultRenderer.Render(results, Console.Out);

        // Предупреждения не считаются ошибкой, код возврата 1 только при Failed.
        return results.Any(result => result.Status == CheckStatus.Failed) ? 1 : 0;
    }
}
