using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using OAuthM2M.Client.Diagnostics;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Cli.Commands;

/// <summary>
/// assertion: подписывает client_assertion локально, без обращения к серверу.
/// Результат можно подставить в curl и проверить запрос к серверу вручную,
/// а с параметром <c>--Inspect=true</c> посмотреть заголовок и claims.
/// </summary>
public sealed class AssertionCommand : ICommand
{
    public string Name => "assertion";
    public string Description => "Сгенерировать client_assertion локально (для curl/отладки).";

    public Task<int> ExecuteAsync(string[] args, CancellationToken cancellationToken)
    {
        var options = CommandConfiguration.LoadOptions(args);

        using var factory = new ClientAssertionFactory(
            Options.Create(options),
            TimeProvider.System,
            NullLogger<ClientAssertionFactory>.Instance);

        var assertion = factory.Create();

        if (args.Contains("--Inspect=true", StringComparer.OrdinalIgnoreCase))
        {
            if (!JwtInspector.TryInspect(assertion, out var inspected) || inspected is null)
            {
                Console.Error.WriteLine(AnsiConsole.Red("Не удалось разобрать JWT."));
                return Task.FromResult(1);
            }

            Console.WriteLine(AnsiConsole.Bold("Header:"));
            Console.WriteLine(inspected.Header.GetRawText());
            Console.WriteLine();
            Console.WriteLine(AnsiConsole.Bold("Payload:"));
            Console.WriteLine(inspected.Payload.GetRawText());
            return Task.FromResult(0);
        }

        // Без --Inspect выводится только JWT, чтобы результат можно было подставить в $(...).
        Console.WriteLine(assertion);
        return Task.FromResult(0);
    }
}
