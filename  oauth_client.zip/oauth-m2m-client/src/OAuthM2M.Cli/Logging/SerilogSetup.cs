using Serilog;
using Serilog.Events;

namespace OAuthM2M.Cli.Logging;

/// <summary>
/// Настройка Serilog: файл с ротацией по дням и вывод в консоль.
/// В консоль попадают предупреждения и ошибки (остальное печатают сами команды),
/// в файл - сообщения уровня Information и выше. С флагом --verbose оба уровня снижаются до Debug.
/// В журнал не должны попадать токены, ключи и client_assertion.
/// </summary>
internal static class SerilogSetup
{
    private const int RetainedFiles = 14;

    public static Serilog.ILogger Create(bool verbose, bool noColor)
    {
        var fileLevel = verbose ? LogEventLevel.Debug : LogEventLevel.Information;
        var consoleLevel = verbose ? LogEventLevel.Debug : LogEventLevel.Warning;

        var configuration = new LoggerConfiguration()
            .MinimumLevel.Is(fileLevel)
            .Enrich.FromLogContext()
            .WriteTo.File(
                path: Path.Combine(ResolveLogDirectory(), "oauth-m2m-.log"),   // дата добавляется перед расширением
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: RetainedFiles,
                restrictedToMinimumLevel: fileLevel,
                outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
            .WriteTo.Console(
                restrictedToMinimumLevel: consoleLevel,
                theme: noColor ? Serilog.Sinks.SystemConsole.Themes.AnsiConsoleTheme.None : null,
                outputTemplate: "[{Level:u3}] {Message:lj}{NewLine}{Exception}");

        return configuration.CreateLogger();
    }

    /// <summary>
    /// Журнал пишется в каталог logs рядом с программой. Если там нет прав на запись
    /// (например, установка в Program Files), используется временный каталог.
    /// </summary>
    private static string ResolveLogDirectory()
    {
        var preferred = Path.Combine(AppContext.BaseDirectory, "logs");

        try
        {
            Directory.CreateDirectory(preferred);
            return preferred;
        }
        catch (UnauthorizedAccessException)
        {
            var fallback = Path.Combine(Path.GetTempPath(), "oauth-m2m", "logs");
            Directory.CreateDirectory(fallback);
            return fallback;
        }
    }
}
