// oauth-m2m: консольный клиент OAuth 2.0 (client_credentials) с отправкой JSON в NiFi.
//
// Использование: oauth-m2m <команда> [параметры]
// Команды: run (по умолчанию), init, assertion, doctor. Команда указывается первым аргументом.
// Общие флаги: --verbose (подробный журнал), --no-color (без цветов), --help.
// Коды возврата: 0 - успех, 1 - ошибка выполнения, 2 - ошибка конфигурации, 130 - отмена (Ctrl+C).
using Microsoft.Extensions.Options;
using OAuthM2M.Cli.Commands;
using OAuthM2M.Cli.Logging;
using OAuthM2M.Client.Diagnostics;

// Общие флаги разбираются здесь и убираются из аргументов. Иначе провайдер командной строки
// воспримет "--verbose" без значения как пару "--verbose <следующий аргумент>" и потеряет соседний параметр.
var verbose = args.Any(argument => IsFlag(argument, "--verbose"));
var noColor = args.Any(argument => IsFlag(argument, "--no-color"))
              || !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("NO_COLOR"));
args = args.Where(argument => !IsFlag(argument, "--verbose") && !IsFlag(argument, "--no-color")).ToArray();

AnsiConsole.Disabled = AnsiConsole.Disabled || noColor;
Serilog.Log.Logger = SerilogSetup.Create(verbose, noColor);

// По Ctrl+C не обрываем процесс сразу, а отменяем текущую операцию.
using var cancellation = new CancellationTokenSource();
Console.CancelKeyPress += (sender, eventArgs) =>
{
    eventArgs.Cancel = true;
    cancellation.Cancel();
};

var dispatcher = new CommandDispatcher(new ICommand[]
{
    new RunCommand(),
    new InitCommand(),
    new AssertionCommand(),
    new DoctorCommand()
});

try
{
    return await dispatcher.DispatchAsync(args, cancellation.Token);
}
catch (OptionsValidationException exception)
{
    Console.Error.WriteLine(AnsiConsole.Red("Ошибка конфигурации:"));
    foreach (var failure in exception.Failures)
    {
        Console.Error.WriteLine($"  - {failure}");
    }

    Serilog.Log.Error("Конфигурация не прошла проверку: {Failures}", string.Join("; ", exception.Failures));
    return 2;
}
catch (OperationCanceledException)
{
    Console.Error.WriteLine("Операция отменена.");
    return 130;
}
catch (Exception exception)
{
    Console.Error.WriteLine(AnsiConsole.Red($"Ошибка: {exception.Message}"));
    Serilog.Log.Error(exception, "Команда завершилась ошибкой");
    return 1;
}
finally
{
    // Без этого последние записи могут не попасть в файл журнала.
    Serilog.Log.CloseAndFlush();
}

static bool IsFlag(string argument, string flag) =>
    string.Equals(argument, flag, StringComparison.OrdinalIgnoreCase);
