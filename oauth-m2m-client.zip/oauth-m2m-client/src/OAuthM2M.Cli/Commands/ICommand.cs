namespace OAuthM2M.Cli.Commands;

/// <summary>
/// Общий контракт CLI-команды. Зачем: держать Program.cs тонким диспетчером,
/// чтобы добавление новой команды не требовало правок в main-методе.
/// </summary>
public interface ICommand
{
    /// <summary>Имя команды в CLI (run/init/assertion/doctor).</summary>
    string Name { get; }

    /// <summary>Короткое описание для --help.</summary>
    string Description { get; }

    /// <summary>Выполнить команду. Возвращает код выхода процесса.</summary>
    Task<int> ExecuteAsync(string[] args, CancellationToken cancellationToken);
}