using System.Text.Json;
using OAuthM2M.Client.Diagnostics;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Cli.Commands;

/// <summary>
/// Генерация ключа + автодополнение конфига.
/// Зачем: убрать ручную правку JSON после `openssl genpkey` — KeyId и PrivateKeyPath
/// детерминированно заполняются из сгенерированного ключа, если их нет в конфиге.
/// </summary>
public sealed class InitCommand : ICommand
{
    public string Name => "init";
    public string Description => "Сгенерировать пару ключей и дополнить конфиг (KeyId, PrivateKeyPath).";

    public Task<int> ExecuteAsync(string[] args, CancellationToken cancellationToken)
    {
        // Простой ручной разбор: в промышленном варианте — System.CommandLine.
        string? configPath = GetOption(args, "--config");
        var overwrite = args.Contains("--force", StringComparer.OrdinalIgnoreCase);

        if (string.IsNullOrWhiteSpace(configPath))
        {
            Console.Error.WriteLine(AnsiConsole.Red("Укажите --config <файл.json>."));
            return Task.FromResult(2);
        }

        var fullConfigPath = Path.GetFullPath(configPath);

        // 1) Генерируем ключ рядом с конфигом, чтобы пути в JSON были относительными.
        var configDirectory = Path.GetDirectoryName(fullConfigPath) ?? ".";
        var privateKeyPath = Path.Combine(configDirectory, "secrets", "private.pem");

        var artifacts = KeyPairGenerator.Generate(privateKeyPath, overwrite);
        Console.WriteLine($"{AnsiConsole.Green("[ OK ]")} Ключ: {artifacts.PrivateKeyPath}");
        Console.WriteLine($"{AnsiConsole.Green("[ OK ]")} Публичный: {artifacts.PublicKeyPath}");
        Console.WriteLine($"{AnsiConsole.Green("[ OK ]")} JWKS: {artifacts.JwksPath}");
        Console.WriteLine($"{AnsiConsole.Green("[ OK ]")} kid: {artifacts.KeyId}");

        // 2) Дополняем конфиг, не перетирая вручную заданные поля.
        var updated = FillConfigIfEmpty(fullConfigPath, artifacts);
        Console.WriteLine($"{AnsiConsole.Green("[ OK ]")} Конфиг обновлён: {updated}");
        Console.WriteLine();
        Console.WriteLine(AnsiConsole.Dim(
            "Зарегистрируйте JWKS на сервере (FAM: вкладка «Сертификаты» / JWKs URI; Keycloak: Keys → Import)."));

        return Task.FromResult(0);
    }

    private static string FillConfigIfEmpty(string configPath, KeyPairArtifacts artifacts)
    {
        if (!File.Exists(configPath))
        {
            throw new FileNotFoundException(
                $"Конфиг не найден: {configPath}. Создайте его из шаблона config/*.json.", configPath);
        }

        using var document = JsonDocument.Parse(File.ReadAllText(configPath));
        using var buffer = new MemoryStream();

        using (var writer = new Utf8JsonWriter(buffer, new JsonWriterOptions { Indented = true }))
        {
            writer.WriteStartObject();
            foreach (var property in document.RootElement.EnumerateObject())
            {
                if (property.NameEquals("OAuth") && property.Value.ValueKind == JsonValueKind.Object)
                {
                    writer.WritePropertyName("OAuth");
                    writer.WriteStartObject();
                    foreach (var oauthProperty in property.Value.EnumerateObject())
                    {
                        writer.WritePropertyName(oauthProperty.Name);
                        oauthProperty.Value.WriteTo(writer);
                    }

                    // KeyId — только если пусто.
                    var keyId = ReadString(property.Value, "KeyId");
                    if (string.IsNullOrWhiteSpace(keyId))
                    {
                        writer.WriteString("KeyId", artifacts.KeyId);
                    }

                    // PrivateKeyPath — только если пусто; сохраняем относительный путь от конфига.
                    var privateKeyPath = ReadString(property.Value, "PrivateKeyPath");
                    if (string.IsNullOrWhiteSpace(privateKeyPath))
                    {
                        var configDirectory = Path.GetDirectoryName(Path.GetFullPath(configPath)) ?? ".";
                        var relative = Path.GetRelativePath(configDirectory, artifacts.PrivateKeyPath);
                        writer.WriteString("PrivateKeyPath", relative);
                    }

                    writer.WriteEndObject();
                }
                else
                {
                    writer.WritePropertyName(property.Name);
                    property.Value.WriteTo(writer);
                }
            }

            writer.WriteEndObject();
        }

        File.WriteAllBytes(configPath, buffer.ToArray());
        return configPath;
    }

    private static string? ReadString(JsonElement element, string name) =>
        element.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;

    private static string? GetOption(string[] args, string name)
    {
        for (var index = 0; index < args.Length - 1; index++)
        {
            if (string.Equals(args[index], name, StringComparison.OrdinalIgnoreCase))
            {
                return args[index + 1];
            }
        }

        return null;
    }
}