using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using OAuthM2M.Client;
using OAuthM2M.Client.Security;
using OAuthM2M.Client.Tokens;

namespace OAuthM2M.Cli.Commands;

/// <summary>
/// Основная команда: получить access_token в FAM.
/// Шаг 3 (gRPC в NiFi) подключается отдельно, если задан NiFi:Endpoint.
/// </summary>
public sealed class RunCommand : ICommand
{
    public string Name => "run";

    public string Description => "Получить access_token (и опционально отправить JSON в NiFi по gRPC).";

    public async Task<int> ExecuteAsync(string[] args, CancellationToken cancellationToken)
    {
        // Соглашение: --config=<файл> или --config <файл>.
        // Host.CreateApplicationBuilder понимает только --key=value,
        // поэтому извлекаем путь вручную и нормализуем остальные аргументы.
        var (normalizedArgs, configPath) = NormalizeArgs(args);

        var builder = Host.CreateApplicationBuilder(new HostApplicationBuilderSettings
        {
            Args = normalizedArgs,
            ContentRootPath = AppContext.BaseDirectory
        });

        // Пользовательский конфиг поверх appsettings.json, env и args.
        if (!string.IsNullOrWhiteSpace(configPath))
        {
            builder.Configuration
                .AddJsonFile(Path.GetFullPath(configPath), optional: false, reloadOnChange: false)
                .AddEnvironmentVariables()
                .AddCommandLine(normalizedArgs);
        }

        builder.Services.AddOAuthM2MClient(builder.Configuration);
        using var host = builder.Build();

        // Обращение к IOptions<> запускает валидацию OAuthClientOptions.
        var options = host.Services.GetRequiredService<IOptions<OAuthClientOptions>>().Value;
        var client = host.Services.GetRequiredService<IOAuthTokenClient>();

        var token = await client.RequestTokenAsync(cancellationToken).ConfigureAwait(false);

        Console.WriteLine($"Режим:        {options.AuthMethod}");
        Console.WriteLine($"token_type:   {token.TokenType}");
        Console.WriteLine($"expires_in:   {token.ExpiresIn} c");
        Console.WriteLine($"access_token: {SecretMasker.Mask(token.AccessToken)}");

        return 0;
    }

    /// <summary>
    /// Извлекает путь к конфигу из --config=<файл> или --config <файл>,
    /// возвращает остальные аргументы (Host их разберёт сам).
    /// </summary>
    private static (string[] NormalizedArgs, string? ConfigPath) NormalizeArgs(string[] args)
    {
        var normalized = new List<string>(args.Length);
        string? configPath = null;

        for (var index = 0; index < args.Length; index++)
        {
            var argument = args[index];

            // --config=path
            if (argument.StartsWith("--config=", StringComparison.OrdinalIgnoreCase))
            {
                configPath = argument["--config=".Length..];
                continue;
            }

            // --config path
            if (string.Equals(argument, "--config", StringComparison.OrdinalIgnoreCase)
                && index + 1 < args.Length)
            {
                configPath = args[index + 1];
                index++;
                continue;
            }

            normalized.Add(argument);
        }

        return (normalized.ToArray(), configPath);
    }
}