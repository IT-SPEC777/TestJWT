using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using OAuthM2M.Client;
using OAuthM2M.Client.Diagnostics;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Cli.Commands;

/// <summary>
/// Локальная генерация client_assertion — без запроса токена.
/// Зачем: удобно вставить JWT в curl (диагностика FAM/Keycloak),
/// не гоняя полный цикл получения access_token.
/// </summary>
public sealed class AssertionCommand : ICommand
{
    public string Name => "assertion";
    public string Description => "Сгенерировать client_assertion локально (для curl/отладки).";

    public Task<int> ExecuteAsync(string[] args, CancellationToken cancellationToken)
    {
        var configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: true)
            .AddEnvironmentVariables()
            .AddCommandLine(args)
            .Build();

        var extraConfig = configuration["config"];
        if (!string.IsNullOrWhiteSpace(extraConfig))
        {
            configuration = new ConfigurationBuilder()
                .SetBasePath(AppContext.BaseDirectory)
                .AddJsonFile("appsettings.json", optional: true)
                .AddJsonFile(Path.GetFullPath(extraConfig), optional: false)
                .AddEnvironmentVariables()
                .AddCommandLine(args)
                .Build();
        }

        var options = configuration.GetSection(OAuthClientOptions.SectionName)
            .Get<OAuthClientOptions>() ?? new OAuthClientOptions();

        using var factory = new ClientAssertionFactory(
            Options.Create(options),
            TimeProvider.System,
            Microsoft.Extensions.Logging.Abstractions.NullLogger<ClientAssertionFactory>.Instance);

        var assertion = factory.Create();

        if (args.Contains("--Inspect=true", StringComparer.OrdinalIgnoreCase))
        {
            if (!JwtInspector.TryInspect(assertion, out var inspected) || inspected is null)
            {
                Console.Error.WriteLine(AnsiConsole.Red("Не удалось разобрать JWT."));
                return Task.FromResult(1);
            }

            Console.WriteLine(AnsiConsole.Bold("Header:"));
            Console.WriteLine(inspected.Header.GetRawText());
            Console.WriteLine();
            Console.WriteLine(AnsiConsole.Bold("Payload:"));
            Console.WriteLine(inspected.Payload.GetRawText());
            return Task.FromResult(0);
        }

        Console.WriteLine(assertion);
        return Task.FromResult(0);
    }
}