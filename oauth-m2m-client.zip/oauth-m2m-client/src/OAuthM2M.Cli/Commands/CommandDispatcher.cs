using OAuthM2M.Client.Diagnostics;

namespace OAuthM2M.Cli.Commands;

/// <summary>
/// Находит команду по имени и делегирует выполнение.
/// Зачем: единая точка обработки «неизвестная команда» и --help.
/// </summary>
public sealed class CommandDispatcher
{
    private readonly IReadOnlyDictionary<string, ICommand> _commands;

    public CommandDispatcher(IEnumerable<ICommand> commands)
    {
        _commands = commands.ToDictionary(command => command.Name, StringComparer.OrdinalIgnoreCase);
    }

    public async Task<int> DispatchAsync(string[] args, CancellationToken cancellationToken)
    {
        var commandName = args.FirstOrDefault(argument => !argument.StartsWith('-')) ?? "run";

        if (!_commands.TryGetValue(commandName, out var command))
        {
            Console.Error.WriteLine(AnsiConsole.Red($"Неизвестная команда: {commandName}"));
            PrintHelp();
            return 2;
        }

        return await command.ExecuteAsync(args, cancellationToken).ConfigureAwait(false);
    }

    public void PrintHelp()
    {
        Console.WriteLine(AnsiConsole.Bold("oauth-m2m — M2M-клиент OAuth 2.0 (client_credentials)"));
        Console.WriteLine();
        foreach (var command in _commands.Values)
        {
            Console.WriteLine($"  {AnsiConsole.Cyan(command.Name.PadRight(10))} {command.Description}");
        }
    }
}