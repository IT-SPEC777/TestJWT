using Microsoft.Extensions.Configuration;
using OAuthM2M.Client;
using OAuthM2M.Client.Diagnostics;

namespace OAuthM2M.Cli.Commands;

/// <summary>
/// Диагностика: конфиг, ключ, discovery сервера. Печатает цветной отчёт.
/// Зачем: пользователь должен видеть причину invalid_client до запроса токена.
/// </summary>
public sealed class DoctorCommand : ICommand
{
    public string Name => "doctor";
    public string Description => "Проверить конфиг, ключ и discovery сервера.";

    public async Task<int> ExecuteAsync(string[] args, CancellationToken cancellationToken)
    {
        var configurationBuilder = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: true)
            .AddEnvironmentVariables()
            .AddCommandLine(args);

        var preliminary = configurationBuilder.Build();
        var extraConfig = preliminary["config"];

        var configuration = string.IsNullOrWhiteSpace(extraConfig)
            ? preliminary
            : new ConfigurationBuilder()
                .SetBasePath(AppContext.BaseDirectory)
                .AddJsonFile("appsettings.json", optional: true)
                .AddJsonFile(Path.GetFullPath(extraConfig), optional: false)
                .AddEnvironmentVariables()
                .AddCommandLine(args)
                .Build();

        var options = configuration.GetSection(OAuthClientOptions.SectionName)
            .Get<OAuthClientOptions>() ?? new OAuthClientOptions();

        var runner = new PreflightRunner(options, TimeProvider.System);
        var results = await runner.RunAsync(cancellationToken).ConfigureAwait(false);

        CheckResultRenderer.Render(results, Console.Out);

        return results.Any(result => result.Status == CheckStatus.Failed) ? 1 : 0;
    }
}