// oauth-m2m: консольный M2M-клиент OAuth 2.0 (client_credentials).
// Команды: run (по умолчанию), init, assertion, doctor.
// Коды возврата: 0 — успех, 1 — ошибка выполнения, 2 — ошибка конфигурации, 130 — отмена.
using Microsoft.Extensions.Options;
using OAuthM2M.Cli.Commands;
using OAuthM2M.Client.Diagnostics;

using var cancellation = new CancellationTokenSource();
Console.CancelKeyPress += (sender, eventArgs) =>
{
    eventArgs.Cancel = true;
    cancellation.Cancel();
};

var dispatcher = new CommandDispatcher(new ICommand[]
{
    new RunCommand(),
    new InitCommand(),
    new AssertionCommand(),
    new DoctorCommand()
});

try
{
    return await dispatcher.DispatchAsync(args, cancellation.Token);
}
catch (OptionsValidationException exception)
{
    Console.Error.WriteLine(AnsiConsole.Red("Ошибка конфигурации:"));
    foreach (var failure in exception.Failures)
    {
        Console.Error.WriteLine($"  - {failure}");
    }

    return 2;
}
catch (OperationCanceledException)
{
    Console.Error.WriteLine("Операция отменена.");
    return 130;
}
catch (Exception exception)
{
    Console.Error.WriteLine(AnsiConsole.Red($"Ошибка: {exception.Message}"));
    return 1;
}