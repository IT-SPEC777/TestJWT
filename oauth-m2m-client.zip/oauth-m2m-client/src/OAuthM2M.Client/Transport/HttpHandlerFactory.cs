using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Client.Transport;

/// <summary>Создаёт primary-handler: клиентский сертификат (mTLS) и доверие к собственному СА сервера.</summary>
public static class HttpHandlerFactory
{
    public static SocketsHttpHandler Create(OAuthClientOptions options)
    {
        var handler = new SocketsHttpHandler
        {
            // Периодически пересоздаём соединения: подхватываем ротацию DNS/сертификатов.
            PooledConnectionLifetime = TimeSpan.FromMinutes(2)
        };

        if (options.AuthMethod == ClientAuthMethod.TlsClientAuth)
        {
            var cert = ClientCertificateLoader.Load(options);
            handler.SslOptions.ClientCertificates = new X509CertificateCollection { cert };
        }

        if (!string.IsNullOrWhiteSpace(options.ServerCaCertificatePath))
        {
            ConfigureCustomServerTrust(handler, options.ServerCaCertificatePath);
        }

        return handler;
    }

    private static void ConfigureCustomServerTrust(SocketsHttpHandler handler, string caPath)
    {
        if (!File.Exists(caPath))
        {
            throw new FileNotFoundException($"Файл СА сервера не найден: {caPath}", caPath);
        }

        var trusted = CertificateIo.LoadCertificates(caPath);

        handler.SslOptions.RemoteCertificateValidationCallback = (_, certificate, chain, errors) =>
        {
            if (errors == SslPolicyErrors.None)
            {
                return true;
            }

            // Допускаем только «недоверенный корень». Несовпадение имени и пр. остаются ошибкой.
            if (certificate is null || chain is null || (errors & ~SslPolicyErrors.RemoteCertificateChainErrors) != 0)
            {
                return false;
            }

            using var custom = new X509Chain();
            custom.ChainPolicy.TrustMode = X509ChainTrustMode.CustomRootTrust;
            custom.ChainPolicy.CustomTrustStore.AddRange(trusted);
            custom.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;
            foreach (var element in chain.ChainElements)
            {
                custom.ChainPolicy.ExtraStore.Add(element.Certificate);
            }

            // Сертификат, переданный платформой, не освобождаем — только созданный нами.
            var leaf = certificate as X509Certificate2;
            var created = leaf is null;
            leaf ??= new X509Certificate2(certificate);
            try
            {
                return custom.Build(leaf);
            }
            finally
            {
                if (created)
                {
                    leaf.Dispose();
                }
            }
        };
    }
}
