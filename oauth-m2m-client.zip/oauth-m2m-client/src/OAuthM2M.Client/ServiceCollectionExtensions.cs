using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;
using OAuthM2M.Client;
using OAuthM2M.Client.Security;
using OAuthM2M.Client.Tokens;
using OAuthM2M.Client.Transport;

namespace Microsoft.Extensions.DependencyInjection;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Регистрирует <see cref="IOAuthTokenClient"/> (типизированный HttpClient через IHttpClientFactory),
    /// настройки из секции "OAuth" и валидацию.
    /// </summary>
    public static IServiceCollection AddOAuthM2MClient(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<OAuthClientOptions>()
            .Bind(configuration.GetSection(OAuthClientOptions.SectionName));
        services.TryAddEnumerable(
            ServiceDescriptor.Singleton<IValidateOptions<OAuthClientOptions>, OAuthClientOptionsValidator>());

        services.TryAddSingleton(TimeProvider.System);
        services.TryAddSingleton<IClientAssertionFactory, ClientAssertionFactory>();

        services.AddHttpClient<IOAuthTokenClient, OAuthTokenClient>((sp, client) =>
            {
                var o = sp.GetRequiredService<IOptions<OAuthClientOptions>>().Value;
                client.Timeout = TimeSpan.FromSeconds(o.HttpTimeoutSeconds);
            })
            .ConfigurePrimaryHttpMessageHandler(sp =>
                HttpHandlerFactory.Create(sp.GetRequiredService<IOptions<OAuthClientOptions>>().Value));

        return services;
    }
}
