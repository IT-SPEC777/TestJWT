using Microsoft.Extensions.Options;

namespace OAuthM2M.Client;

/// <summary>Проверка настроек при первом обращении к <see cref="IOptions{TOptions}"/>.</summary>
public sealed class OAuthClientOptionsValidator : IValidateOptions<OAuthClientOptions>
{
    public ValidateOptionsResult Validate(string? name, OAuthClientOptions options)
    {
        var errors = new List<string>();
        var p = OAuthClientOptions.SectionName;

        if (!Uri.TryCreate(options.TokenEndpoint, UriKind.Absolute, out var uri))
        {
            errors.Add($"{p}:TokenEndpoint не задан или не является абсолютным URL.");
        }
        else
        {
            var https = uri.Scheme == Uri.UriSchemeHttps;
            var localHttp = uri.Scheme == Uri.UriSchemeHttp && uri.IsLoopback;
            if (!https && !localHttp)
            {
                errors.Add($"{p}:TokenEndpoint должен быть https (http разрешён только для localhost).");
            }

            if (options.AuthMethod == ClientAuthMethod.TlsClientAuth && !https)
            {
                errors.Add($"Для AuthMethod=TlsClientAuth {p}:TokenEndpoint должен быть https.");
            }
        }

        if (string.IsNullOrWhiteSpace(options.ClientId))
        {
            errors.Add($"{p}:ClientId не задан.");
        }

        if (options.HttpTimeoutSeconds is < 1 or > 600)
        {
            errors.Add($"{p}:HttpTimeoutSeconds должен быть в диапазоне 1..600.");
        }

        switch (options.AuthMethod)
        {
            case ClientAuthMethod.PrivateKeyJwt:
                if (string.IsNullOrWhiteSpace(options.KeyId))
                {
                    errors.Add($"{p}:KeyId (kid) не задан.");
                }

                if (string.IsNullOrWhiteSpace(options.PrivateKeyPath))
                {
                    errors.Add($"{p}:PrivateKeyPath не задан.");
                }

                if (options.AssertionLifetimeSeconds is < 60 or > 300)
                {
                    errors.Add($"{p}:AssertionLifetimeSeconds должен быть в диапазоне 60..300.");
                }

                break;

            case ClientAuthMethod.TlsClientAuth:
                if (string.IsNullOrWhiteSpace(options.ClientCertificatePath))
                {
                    errors.Add($"{p}:ClientCertificatePath не задан (нужен для TlsClientAuth).");
                }

                break;

            default:
                errors.Add($"Неизвестный {p}:AuthMethod: {options.AuthMethod}.");
                break;
        }

        return errors.Count == 0 ? ValidateOptionsResult.Success : ValidateOptionsResult.Fail(errors);
    }
}
