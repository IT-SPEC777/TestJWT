namespace OAuthM2M.Client.Tokens;

public interface IOAuthTokenClient
{
    /// <exception cref="TokenRequestException">Сервер отказал или запрос не удался.</exception>
    Task<TokenResponse> RequestTokenAsync(CancellationToken cancellationToken = default);
}
