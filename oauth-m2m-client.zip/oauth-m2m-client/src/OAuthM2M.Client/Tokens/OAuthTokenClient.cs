using System.Net.Http.Headers;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Client.Tokens;

/// <summary>Запрашивает access_token (client_credentials) в режиме private_key_jwt или mTLS.</summary>
public sealed class OAuthTokenClient : IOAuthTokenClient
{
    public const string ClientAssertionType = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer";

    private readonly HttpClient _http;
    private readonly IClientAssertionFactory _assertions;
    private readonly OAuthClientOptions _options;
    private readonly ILogger<OAuthTokenClient> _logger;

    public OAuthTokenClient(
        HttpClient http,
        IClientAssertionFactory assertions,
        IOptions<OAuthClientOptions> options,
        ILogger<OAuthTokenClient> logger)
    {
        _http = http;
        _assertions = assertions;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<TokenResponse> RequestTokenAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var form = BuildForm();

            _logger.LogInformation(
                "POST {Endpoint}, client_id={ClientId}, режим={Method}",
                _options.TokenEndpoint, _options.ClientId, _options.AuthMethod);

            using var request = new HttpRequestMessage(HttpMethod.Post, _options.TokenEndpoint)
            {
                // Content-Type: application/x-www-form-urlencoded
                Content = new FormUrlEncodedContent(form)
            };
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            using var response = await _http.SendAsync(request, cancellationToken).ConfigureAwait(false);
            var body = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                var (error, description) = ParseOAuthError(body);
                var status = (int)response.StatusCode;
                _logger.LogError(
                    "Авторизация не удалась: HTTP {Status} {Reason}, error={Error}, description={Description}",
                    status, response.ReasonPhrase, error, description);

                var details = error is null ? body : $"{error}: {description}";
                throw new TokenRequestException(
                    $"Сервер авторизации вернул {status} {response.ReasonPhrase}. {details}", status, error);
            }

            var token = JsonSerializer.Deserialize<TokenResponse>(body)
                        ?? throw new TokenRequestException("Пустой ответ токен-эндпоинта.", (int)response.StatusCode);

            if (string.IsNullOrWhiteSpace(token.AccessToken))
            {
                throw new TokenRequestException("В ответе отсутствует access_token.", (int)response.StatusCode);
            }

            _logger.LogInformation("Токен получен, expires_in={ExpiresIn}s", token.ExpiresIn);
            return token;
        }
        catch (TokenRequestException)
        {
            throw;
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            _logger.LogError("Таймаут запроса к {Endpoint}", _options.TokenEndpoint);
            throw new TokenRequestException("Таймаут запроса к серверу авторизации.");
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Сетевая/TLS-ошибка при обращении к {Endpoint}", _options.TokenEndpoint);
            throw new TokenRequestException($"Сетевая или TLS-ошибка: {ex.Message}", inner: ex);
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "Не удалось разобрать JSON-ответ");
            throw new TokenRequestException("Некорректный JSON в ответе сервера.", inner: ex);
        }
    }

    private Dictionary<string, string> BuildForm()
    {
        var form = new Dictionary<string, string>
        {
            ["grant_type"] = "client_credentials",
            ["client_id"] = _options.ClientId
        };

        if (!string.IsNullOrWhiteSpace(_options.Scope))
        {
            form["scope"] = _options.Scope!;
        }

        if (_options.AuthMethod == ClientAuthMethod.PrivateKeyJwt)
        {
            form["client_assertion_type"] = ClientAssertionType;
            form["client_assertion"] = _assertions.Create();   // свежий JWT на каждый запрос
        }

        // TlsClientAuth: клиент аутентифицируется сертификатом в TLS-рукопожатии, assertion не нужен.
        return form;
    }

    private static (string? Error, string? Description) ParseOAuthError(string body)
    {
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.ValueKind != JsonValueKind.Object)
            {
                return (null, null);
            }

            string? Read(string name) =>
                doc.RootElement.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String
                    ? v.GetString()
                    : null;

            return (Read("error"), Read("error_description"));
        }
        catch (JsonException)
        {
            return (null, null);
        }
    }
}
