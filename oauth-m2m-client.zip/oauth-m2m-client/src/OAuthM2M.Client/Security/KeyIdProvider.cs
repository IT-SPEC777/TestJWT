using System.Security.Cryptography;
using Microsoft.IdentityModel.Tokens;

namespace OAuthM2M.Client.Security;

/// <summary>
/// Вычисляет стабильный <c>kid</c> по RFC 7638 (JWK Thumbprint) для RSA-ключа.
/// Зачем: если администратор FAM/Keycloak не задал <c>KeyId</c> вручную,
/// клиент должен сам сгенерировать детерминированный идентификатор —
/// иначе сервер не сможет сопоставить подпись с зарегистрированным ключом.
/// </summary>
public static class KeyIdProvider
{
    /// <summary>
    /// Возвращает Base64Url-кодированный thumbprint публичной части ключа.
    /// Один и тот же ключ всегда даёт один и тот же kid — это важно для ротации:
    /// новый ключ → новый kid, старый kid можно спокойно вывести из эксплуатации.
    /// </summary>
    public static string ComputeThumbprint(RSA rsa)
    {
        ArgumentNullException.ThrowIfNull(rsa);

        var jwk = JsonWebKeyConverter.ConvertFromRSASecurityKey(new RsaSecurityKey(rsa));
        return Base64UrlEncoder.Encode(jwk.ComputeJwkThumbprint());
    }
}