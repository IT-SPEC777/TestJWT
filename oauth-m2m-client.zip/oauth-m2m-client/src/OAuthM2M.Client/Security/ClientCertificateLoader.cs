using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace OAuthM2M.Client.Security;

/// <summary>Загрузка клиентского сертификата для mTLS: PFX/P12 или пара PEM (сертификат + ключ).</summary>
public static class ClientCertificateLoader
{
    public static X509Certificate2 Load(OAuthClientOptions options)
    {
        var path = options.ClientCertificatePath
                   ?? throw new InvalidOperationException("OAuth:ClientCertificatePath не задан.");

        if (!File.Exists(path))
        {
            throw new FileNotFoundException($"Файл клиентского сертификата не найден: {path}", path);
        }

        X509Certificate2 cert;
        if (IsPkcs12(path))
        {
            cert = CertificateIo.LoadPkcs12(path, options.ClientCertificatePassword);
        }
        else
        {
            var keyPath = options.ClientCertificateKeyPath
                          ?? throw new InvalidOperationException(
                              "Для сертификата в PEM укажите OAuth:ClientCertificateKeyPath.");
            if (!File.Exists(keyPath))
            {
                throw new FileNotFoundException($"Файл ключа клиентского сертификата не найден: {keyPath}", keyPath);
            }

            cert = string.IsNullOrEmpty(options.ClientCertificatePassword)
                ? X509Certificate2.CreateFromPemFile(path, keyPath)
                : X509Certificate2.CreateFromEncryptedPemFile(path, options.ClientCertificatePassword, keyPath);

            // Windows: ключи, импортированные из PEM, «эфемерные» и не работают в SslStream —
            // перегоняем через PKCS#12 в памяти.
            if (OperatingSystem.IsWindows())
            {
                var pfx = cert.Export(X509ContentType.Pfx);
                cert.Dispose();
                cert = CertificateIo.LoadPkcs12(pfx, null);
            }
        }

        if (!cert.HasPrivateKey)
        {
            cert.Dispose();
            throw new CryptographicException("В клиентском сертификате нет приватного ключа.");
        }

        return cert;
    }

    private static bool IsPkcs12(string path) =>
        path.EndsWith(".pfx", StringComparison.OrdinalIgnoreCase) ||
        path.EndsWith(".p12", StringComparison.OrdinalIgnoreCase);
}
