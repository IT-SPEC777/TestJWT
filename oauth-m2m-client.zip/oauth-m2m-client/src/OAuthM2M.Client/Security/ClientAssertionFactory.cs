using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace OAuthM2M.Client.Security;

/// <summary>
/// Собирает и подписывает client_assertion (RFC 7523): RS256, заголовок с kid,
/// claims iss/sub/aud/jti/iat/nbf/exp. Ключ загружается лениво и один раз.
/// </summary>
public sealed class ClientAssertionFactory : IClientAssertionFactory, IDisposable
{
    private readonly OAuthClientOptions _options;
    private readonly TimeProvider _timeProvider;
    private readonly ILogger<ClientAssertionFactory> _logger;
    private readonly JwtSecurityTokenHandler _handler = new();
    private readonly Lazy<(RSA Rsa, SigningCredentials Credentials)> _signingMaterial;

    public ClientAssertionFactory(
        IOptions<OAuthClientOptions> options,
        TimeProvider timeProvider,
        ILogger<ClientAssertionFactory> logger)
    {
        _options = options.Value;
        _timeProvider = timeProvider;
        _logger = logger;
        _signingMaterial = new Lazy<(RSA, SigningCredentials)>(LoadSigningMaterial);
    }

    public string Create()
    {
        var now = _timeProvider.GetUtcNow().UtcDateTime;
        var issuedAt = new DateTimeOffset(now).ToUnixTimeSeconds();

        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, _options.ClientId),
            // jti обязателен: FAM/Keycloak отвергают повторный assertion (replay protection).
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("D")),
            new(JwtRegisteredClaimNames.Iat, issuedAt.ToString(CultureInfo.InvariantCulture), ClaimValueTypes.Integer64)
        };

        var token = new JwtSecurityToken(
            issuer: _options.ClientId,
            audience: _options.EffectiveAudience,
            claims: claims,
            notBefore: now,
            expires: now.AddSeconds(_options.AssertionLifetimeSeconds),
            signingCredentials: _signingMaterial.Value.Credentials);

        var jwt = _handler.WriteToken(token);

        _logger.LogDebug(
            "Собран client_assertion: kid={Kid}, aud={Audience}, lifetime={LifetimeSeconds}s",
            _signingMaterial.Value.Credentials.Key.KeyId,
            _options.EffectiveAudience,
            _options.AssertionLifetimeSeconds);

        return jwt;
    }

    private (RSA Rsa, SigningCredentials Credentials) LoadSigningMaterial()
    {
        if (string.IsNullOrWhiteSpace(_options.PrivateKeyPath))
        {
            throw new InvalidOperationException("OAuth:PrivateKeyPath не задан.");
        }

        var rsa = PrivateKeyLoader.Load(_options.PrivateKeyPath, _options.PrivateKeyPassword);

        // Если админ не задал kid — считаем thumbprint: тогда kid в JWT совпадёт с kid в JWKS,
        // который сгенерирован из того же ключа.
        var keyId = string.IsNullOrWhiteSpace(_options.KeyId)
            ? KeyIdProvider.ComputeThumbprint(rsa)
            : _options.KeyId!;

        _logger.LogInformation(
            "Загружен ключ подписи: размер={KeySizeBits} бит, kid={Kid}",
            rsa.KeySize,
            keyId);

        var securityKey = new RsaSecurityKey(rsa) { KeyId = keyId };
        return (rsa, new SigningCredentials(securityKey, SecurityAlgorithms.RsaSha256));
    }

    public void Dispose()
    {
        if (_signingMaterial.IsValueCreated)
        {
            _signingMaterial.Value.Rsa.Dispose();
        }
    }
}