using System.Security.Cryptography;

namespace OAuthM2M.Client.Security;

/// <summary>
/// Публичный JWKS из <see cref="OAuthClientOptions"/>.
/// Зачем: администратор FAM/Keycloak регистрирует ключ клиента именно документом JWKS
/// (а не отдельными n/e), и kid внутри должен совпадать с kid в заголовке client_assertion.
/// </summary>
public static class JwksExporter
{
    public static string ExportPublicJwks(OAuthClientOptions options)
    {
        ArgumentNullException.ThrowIfNull(options);

        if (string.IsNullOrWhiteSpace(options.PrivateKeyPath))
        {
            throw new InvalidOperationException("OAuth:PrivateKeyPath не задан.");
        }

        using var rsa = PrivateKeyLoader.Load(options.PrivateKeyPath, options.PrivateKeyPassword);

        // Если kid не задан явно — берём thumbprint (детерминированный, стабильный).
        var keyId = string.IsNullOrWhiteSpace(options.KeyId)
            ? KeyIdProvider.ComputeThumbprint(rsa)
            : options.KeyId!;

        return KeyPairGenerator.BuildJwks(rsa, keyId);
    }
}