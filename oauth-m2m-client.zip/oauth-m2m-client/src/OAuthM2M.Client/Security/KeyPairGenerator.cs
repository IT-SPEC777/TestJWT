using System.Security.Cryptography;
using System.Text.Json;

namespace OAuthM2M.Client.Security;

/// <summary>Результат генерации ключевой пары.</summary>
/// <param name="PrivateKeyPath">Путь к приватному ключу (PKCS#8 PEM, права 600 на Unix).</param>
/// <param name="PublicKeyPath">Путь к публичному ключу (SPKI PEM).</param>
/// <param name="JwksPath">Путь к публичному JWKS-документу (для регистрации на сервере).</param>
/// <param name="KeyId">Итоговый kid (явно заданный или thumbprint ключа).</param>
public sealed record KeyPairArtifacts(
    string PrivateKeyPath,
    string PublicKeyPath,
    string JwksPath,
    string KeyId);

/// <summary>
/// Генерация RSA-2048 пары и сопутствующих артефактов для режима <c>private_key_jwt</c>.
/// Вынесено из CLI, чтобы <c>init</c>-команда и тесты пользовались одним и тем же кодом.
/// </summary>
public static class KeyPairGenerator
{
    private const int KeySizeBits = 2048;

    /// <summary>
    /// Создаёт пару ключей, публичный ключ и JWKS в одном каталоге.
    /// </summary>
    /// <param name="privateKeyPath">Куда положить приватный ключ.</param>
    /// <param name="overwrite">Перезаписывать существующие файлы (по умолчанию — нет).</param>
    /// <param name="keyId">Явный kid; если <c>null</c> — thumbprint ключа.</param>
    /// <param name="privateKeyPassword">Если задан, PEM шифруется.</param>
    public static KeyPairArtifacts Generate(
        string privateKeyPath,
        bool overwrite = false,
        string? keyId = null,
        string? privateKeyPassword = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(privateKeyPath);

        var fullPrivatePath = Path.GetFullPath(privateKeyPath);
        var directory = Path.GetDirectoryName(fullPrivatePath)
            ?? throw new ArgumentException("Не удалось определить каталог для ключа.", nameof(privateKeyPath));
        Directory.CreateDirectory(directory);

        if (File.Exists(fullPrivatePath) && !overwrite)
        {
            throw new IOException(
                $"Файл уже существует: {fullPrivatePath}. Для перезаписи укажите --force.");
        }

        using var rsa = RSA.Create(KeySizeBits);

        var effectiveKeyId = string.IsNullOrWhiteSpace(keyId)
            ? KeyIdProvider.ComputeThumbprint(rsa)
            : keyId!;

        var privatePem = string.IsNullOrEmpty(privateKeyPassword)
            ? rsa.ExportPkcs8PrivateKeyPem()
            : rsa.ExportEncryptedPkcs8PrivateKeyPem(
                privateKeyPassword,
                new PbeParameters(PbeEncryptionAlgorithm.Aes256Cbc, HashAlgorithmName.SHA256, 100_000));

        File.WriteAllText(fullPrivatePath, privatePem);
        RestrictPermissions(fullPrivatePath);

        var publicKeyPath = Path.ChangeExtension(fullPrivatePath, ".public.pem");
        File.WriteAllText(publicKeyPath, rsa.ExportSubjectPublicKeyInfoPem());

        var jwksPath = Path.ChangeExtension(fullPrivatePath, ".jwks.json");
        File.WriteAllText(jwksPath, BuildJwks(rsa, effectiveKeyId));

        return new KeyPairArtifacts(fullPrivatePath, publicKeyPath, jwksPath, effectiveKeyId);
    }

    private static void RestrictPermissions(string path)
    {
        if (OperatingSystem.IsWindows())
        {
            return; // POSIX-права неприменимы; защита — на уровне ACL каталога/секретов CI.
        }

        // Владелец: чтение/запись. Никакого group/other.
        File.SetUnixFileMode(path, UnixFileMode.UserRead | UnixFileMode.UserWrite);
    }

    internal static string BuildJwks(RSA rsa, string keyId)
    {
        var parameters = rsa.ExportParameters(includePrivateParameters: false);

        var jwks = new
        {
            keys = new[]
            {
                new
                {
                    kty = "RSA",
                    use = "sig",
                    alg = "RS256",
                    kid = keyId,
                    n = Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode(parameters.Modulus!),
                    e = Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode(parameters.Exponent!)
                }
            }
        };

        return JsonSerializer.Serialize(jwks, new JsonSerializerOptions { WriteIndented = true });
    }
}