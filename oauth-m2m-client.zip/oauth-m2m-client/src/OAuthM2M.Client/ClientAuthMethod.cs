namespace OAuthM2M.Client;

/// <summary>Способ аутентификации клиента на токен-эндпоинте.</summary>
public enum ClientAuthMethod
{
    /// <summary>private_key_jwt (RFC 7523): подписанный JWT в client_assertion.</summary>
    PrivateKeyJwt = 0,

    /// <summary>tls_client_auth (RFC 8705): взаимный TLS, клиентский сертификат в handshake.</summary>
    TlsClientAuth = 1
}
