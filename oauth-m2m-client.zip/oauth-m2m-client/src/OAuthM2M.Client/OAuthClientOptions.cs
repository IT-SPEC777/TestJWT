namespace OAuthM2M.Client;

/// <summary>
/// Настройки клиента. Секция конфигурации <c>OAuth</c>.
/// Секретов в открытом виде здесь нет: только пути к файлам ключей/сертификатов.
/// </summary>
public sealed class OAuthClientOptions
{
    public const string SectionName = "OAuth";

    /// <summary>URL токен-эндпоинта (https; http допускается только для localhost).</summary>
    public string TokenEndpoint { get; set; } = string.Empty;

    /// <summary>client_id сервиса.</summary>
    public string ClientId { get; set; } = string.Empty;

    /// <summary>PrivateKeyJwt (по умолчанию) или TlsClientAuth.</summary>
    public ClientAuthMethod AuthMethod { get; set; } = ClientAuthMethod.PrivateKeyJwt;

    /// <summary>Необязательный scope.</summary>
    public string? Scope { get; set; }

    // ---------- private_key_jwt ----------

    /// <summary>
    /// aud клиентского JWT. Если не задан — используется <see cref="TokenEndpoint"/>.
    /// Для Keycloak 26+ допустим также issuer realm'а (https://host/realms/realm).
    /// </summary>
    public string? Audience { get; set; }

    /// <summary>Идентификатор ключа (kid в заголовке JWT).</summary>
    public string? KeyId { get; set; }

    /// <summary>Путь к приватному ключу RSA в PEM (PKCS#8 или PKCS#1).</summary>
    public string? PrivateKeyPath { get; set; }

    /// <summary>Пароль к зашифрованному PEM (ENCRYPTED PRIVATE KEY). Лучше передавать через переменную окружения.</summary>
    public string? PrivateKeyPassword { get; set; }

    /// <summary>Время жизни client_assertion, секунд (60..300).</summary>
    public int AssertionLifetimeSeconds { get; set; } = 120;

    // ---------- mTLS ----------

    /// <summary>Клиентский сертификат: .pfx/.p12 либо PEM (тогда нужен <see cref="ClientCertificateKeyPath"/>).</summary>
    public string? ClientCertificatePath { get; set; }

    /// <summary>Приватный ключ клиентского сертификата (PEM), если сертификат в PEM.</summary>
    public string? ClientCertificateKeyPath { get; set; }

    /// <summary>Пароль к PFX или к зашифрованному PEM-ключу.</summary>
    public string? ClientCertificatePassword { get; set; }

    // ---------- общее ----------

    /// <summary>Файл с корневым/промежуточным сертификатом СА сервера (PEM/DER), если он не в системном хранилище.</summary>
    public string? ServerCaCertificatePath { get; set; }

    /// <summary>Таймаут HTTP-запроса, секунд.</summary>
    public int HttpTimeoutSeconds { get; set; } = 30;

    /// <summary>aud с учётом значения по умолчанию.</summary>
    public string EffectiveAudience =>
        string.IsNullOrWhiteSpace(Audience) ? TokenEndpoint : Audience;
}
