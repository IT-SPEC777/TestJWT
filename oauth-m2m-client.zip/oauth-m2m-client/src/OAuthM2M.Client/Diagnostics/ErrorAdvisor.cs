using OAuthM2M.Client.Tokens;

namespace OAuthM2M.Client.Diagnostics;

/// <summary>
/// Превращает «сырые» ответы сервера в человеческие подсказки: что настроить.
/// Зачем: текст <c>invalid_client</c> от FAM/Keycloak не говорит, что именно не так;
/// таблица «симптом → действие» уже есть в docs/troubleshooting.md — здесь она в коде.
/// </summary>
public static class ErrorAdvisor
{
    public static IReadOnlyList<string> Advise(TokenRequestException exception, OAuthClientOptions options)
    {
        ArgumentNullException.ThrowIfNull(exception);
        ArgumentNullException.ThrowIfNull(options);

        var hints = new List<string>();
        var error = exception.Error ?? string.Empty;
        var message = exception.Message ?? string.Empty;

        if (error == "invalid_client")
        {
            if (options.AuthMethod == ClientAuthMethod.TlsClientAuth)
            {
                hints.Add("mTLS: проверьте, что сертификат доходит до сервера (прокси/балансировщик) и Subject DN совпадает с настройкой клиента.");
                hints.Add("Проверьте ключ в сертификате: OAuth:ClientCertificateKeyPath / OAuth:ClientCertificatePassword.");
            }
            else
            {
                hints.Add("Проверьте OAuth:Audience (token_endpoint или issuer из discovery — пробуйте оба).");
                hints.Add("Проверьте, что kid в JWKS совпадает с OAuth:KeyId (или thumbprint): oauth-m2m --PrintJwks=true.");
                hints.Add("Проверьте системное время (NTP): расхождение > нескольких секунд даёт отказ по exp/nbf.");
                hints.Add("Запустите диагностику: oauth-m2m doctor --config <файл>.");
            }
        }
        else if (error == "unauthorized_client")
        {
            hints.Add("Клиенту не разрешён client_credentials. Включите его (Keycloak: Service accounts roles; FAM: Allowed grant types).");
        }
        else if (error == "invalid_scope")
        {
            hints.Add("Запрошенный scope не выдан клиенту. Уберите OAuth:Scope или выдайте scope в сервере.");
        }

        if (message.Contains("SSL connection", StringComparison.OrdinalIgnoreCase))
        {
            hints.Add("TLS: укажите OAuth:ServerCaCertificatePath, если сервер подписан непубличным УЦ.");
        }

        if (message.Contains("NameMismatch", StringComparison.OrdinalIgnoreCase))
        {
            hints.Add("Имя хоста в URL не совпадает с SAN сертификата сервера. Используйте FQDN из сертификата.");
        }

        return hints;
    }
}