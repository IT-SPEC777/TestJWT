namespace OAuthM2M.Client.Diagnostics;

/// <summary>
/// Мини-обёртка над ANSI-последовательностями. Зачем не брать Spectre.Console:
/// для консольного клиента M2M это лишняя зависимость; нам нужны только цвета.
/// Всё в один файл, чтобы CLI оставался тонким.
/// </summary>
public static class AnsiConsole
{
    private const string Reset = "\u001b[0m";

    /// <summary>Цвет выключен (например, вывод перенаправлен в файл или CI без TTY).</summary>
    public static bool Disabled { get; set; } = Console.IsOutputRedirected;

    public static string Bold(string text) => Wrap(text, "\u001b[1m");
    public static string Dim(string text) => Wrap(text, "\u001b[2m");
    public static string Red(string text) => Wrap(text, "\u001b[31m");
    public static string Green(string text) => Wrap(text, "\u001b[32m");
    public static string Yellow(string text) => Wrap(text, "\u001b[33m");
    public static string Blue(string text) => Wrap(text, "\u001b[34m");
    public static string Magenta(string text) => Wrap(text, "\u001b[35m");
    public static string Cyan(string text) => Wrap(text, "\u001b[36m");

    /// <summary>Метка статуса в стиле [ OK ] / [FAIL] / [WARN] / [SKIP].</summary>
    public static string StatusBadge(CheckStatus status) => status switch
    {
        CheckStatus.Ok => Green("[ OK ]"),
        CheckStatus.Failed => Red("[FAIL]"),
        CheckStatus.Warning => Yellow("[WARN]"),
        CheckStatus.Skipped => Dim("[SKIP]"),
        _ => "[????]"
    };

    private static string Wrap(string text, string prefix) =>
        Disabled ? text : $"{prefix}{text}{Reset}";
}