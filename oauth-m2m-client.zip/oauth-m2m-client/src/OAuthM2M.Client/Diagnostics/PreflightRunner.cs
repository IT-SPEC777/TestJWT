using System.Text.Json;
using OAuthM2M.Client.Security;

namespace OAuthM2M.Client.Diagnostics;

/// <summary>
/// Preflight-проверки «до запроса токена»: ключ, конфиг, discovery сервера.
/// Зачем: 80% проблем M2M — это неверный audience, не тот kid или отсутствие
/// private_key_jwt на сервере. Всё это видно ДО того, как сервер вернёт невнятный invalid_client.
/// </summary>
public sealed class PreflightRunner
{
    private readonly OAuthClientOptions _options;

    public PreflightRunner(OAuthClientOptions options, TimeProvider timeProvider)
    {
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(timeProvider);

        _options = options;

        // TimeProvider в текущих проверках не используется, но оставлен в сигнатуре:
        // в будущем сюда добавятся проверки рассинхронизации часов (exp/nbf), а сейчас
        // это просто явная точка расширения без побочных эффектов.
        _ = timeProvider;
    }

    public async Task<IReadOnlyList<CheckResult>> RunAsync(CancellationToken cancellationToken)
    {
        var results = new List<CheckResult>();

        // --- конфигурация ---
        if (!Uri.TryCreate(_options.TokenEndpoint, UriKind.Absolute, out var endpoint))
        {
            results.Add(new CheckResult("Конфигурация", "TokenEndpoint", CheckStatus.Failed,
                "Не задан или не абсолютный URL."));
            return results;
        }

        results.Add(new CheckResult("Конфигурация", "TokenEndpoint", CheckStatus.Ok, endpoint.ToString()));
        results.Add(new CheckResult("Конфигурация", "ClientId", CheckStatus.Ok, _options.ClientId));
        results.Add(new CheckResult("Конфигурация", "AuthMethod", CheckStatus.Ok, _options.AuthMethod.ToString()));

        // --- ключ (только для private_key_jwt) ---
        if (_options.AuthMethod == ClientAuthMethod.PrivateKeyJwt)
        {
            var keyCheck = CheckPrivateKey();
            if (keyCheck is not null)
            {
                results.Add(keyCheck);
            }
        }

        // --- discovery сервера ---
        using var discovery = await LoadDiscoveryAsync(endpoint, cancellationToken).ConfigureAwait(false);
        if (discovery is null)
        {
            results.Add(new CheckResult("Сервер", "Discovery", CheckStatus.Warning,
                "Не удалось получить discovery-документ.",
                "Убедитесь, что путь /.well-known/openid-configuration верный и хост доступен."));
            return results;
        }

        // ВАЖНО: у JsonDocument нет свойства Value — работаем с RootElement.
        var discoveryRoot = discovery.RootElement;

        results.Add(CheckTokenEndpoint(discoveryRoot, endpoint));
        results.Add(CheckAuthMethod(discoveryRoot));
        results.Add(CheckSigningAlg(discoveryRoot));
        results.Add(CheckGrantTypes(discoveryRoot));
        results.Add(CheckAudienceCandidate(discoveryRoot));

        return results;
    }

    private CheckResult? CheckPrivateKey()
    {
        if (string.IsNullOrWhiteSpace(_options.PrivateKeyPath))
        {
            return new CheckResult("Ключ", "Приватный ключ", CheckStatus.Failed,
                "OAuth:PrivateKeyPath не задан.",
                "Сгенерируйте ключ: oauth-m2m init --config <файл>.");
        }

        if (!File.Exists(_options.PrivateKeyPath))
        {
            return new CheckResult("Ключ", "Приватный ключ", CheckStatus.Failed,
                $"Файл не найден: {_options.PrivateKeyPath}",
                "Сгенерируйте ключ: oauth-m2m init --config <файл>.");
        }

        try
        {
            using var rsa = PrivateKeyLoader.Load(_options.PrivateKeyPath, _options.PrivateKeyPassword);
            var effectiveKeyId = string.IsNullOrWhiteSpace(_options.KeyId)
                ? KeyIdProvider.ComputeThumbprint(rsa)
                : _options.KeyId!;

            return new CheckResult("Ключ", "Приватный ключ", CheckStatus.Ok,
                $"RSA-{rsa.KeySize}, kid={effectiveKeyId}");
        }
        catch (Exception exception)
        {
            return new CheckResult("Ключ", "Приватный ключ", CheckStatus.Failed,
                exception.Message,
                "Проверьте пароль/формат PEM.");
        }
    }

    private static CheckResult CheckTokenEndpoint(JsonElement discoveryRoot, Uri configuredEndpoint)
    {
        var advertised = JwtInspector.GetString(discoveryRoot, "token_endpoint");

        if (string.IsNullOrWhiteSpace(advertised))
        {
            return new CheckResult("Сервер", "token_endpoint", CheckStatus.Skipped,
                "Поле отсутствует в discovery.");
        }

        return string.Equals(advertised, configuredEndpoint.ToString(), StringComparison.OrdinalIgnoreCase)
            ? new CheckResult("Сервер", "token_endpoint", CheckStatus.Ok, "совпадает с конфигом.")
            : new CheckResult("Сервер", "token_endpoint", CheckStatus.Warning,
                $"discovery={advertised}, конфиг={configuredEndpoint}",
                "Скопируйте значение из discovery в OAuth:TokenEndpoint.");
    }

    private static CheckResult CheckAuthMethod(JsonElement discoveryRoot)
    {
        if (!TryGetStringArray(discoveryRoot, "token_endpoint_auth_methods_supported", out var methods))
        {
            return new CheckResult("Сервер", "Метод аутентификации", CheckStatus.Warning,
                "Поле token_endpoint_auth_methods_supported отсутствует.");
        }

        return methods.Contains("private_key_jwt")
            ? new CheckResult("Сервер", "Метод аутентификации", CheckStatus.Ok, "private_key_jwt поддерживается.")
            : new CheckResult("Сервер", "Метод аутентификации", CheckStatus.Failed,
                $"private_key_jwt не поддерживается. Доступны: {string.Join(", ", methods)}",
                "Включите private_key_jwt на стороне FAM/Keycloak или смените AuthMethod.");
    }

    private static CheckResult CheckSigningAlg(JsonElement discoveryRoot)
    {
        if (!TryGetStringArray(discoveryRoot, "token_endpoint_auth_signing_alg_values_supported", out var algs))
        {
            return new CheckResult("Сервер", "Алгоритм подписи", CheckStatus.Warning,
                "Поле ..._signing_alg_values_supported отсутствует.");
        }

        return algs.Contains("RS256")
            ? new CheckResult("Сервер", "Алгоритм подписи", CheckStatus.Ok, "RS256 поддерживается.")
            : new CheckResult("Сервер", "Алгоритм подписи", CheckStatus.Failed,
                $"RS256 не поддерживается. Доступны: {string.Join(", ", algs)}");
    }

    private static CheckResult CheckGrantTypes(JsonElement discoveryRoot)
    {
        if (!TryGetStringArray(discoveryRoot, "grant_types_supported", out var grants))
        {
            return new CheckResult("Сервер", "Grant types", CheckStatus.Warning,
                "Поле grant_types_supported отсутствует.");
        }

        return grants.Contains("client_credentials")
            ? new CheckResult("Сервер", "Grant types", CheckStatus.Ok, "client_credentials поддерживается.")
            : new CheckResult("Сервер", "Grant types", CheckStatus.Failed,
                $"client_credentials не поддерживается. Доступны: {string.Join(", ", grants)}",
                "Включите client_credentials у клиента.");
    }

    private static CheckResult CheckAudienceCandidate(JsonElement discoveryRoot)
    {
        // Если OAuth:Audience не задан, клиент по умолчанию шлёт token_endpoint.
        // Для Keycloak 26+ ожидается issuer — подсказываем альтернативу.
        var issuer = JwtInspector.GetString(discoveryRoot, "issuer");

        return string.IsNullOrWhiteSpace(issuer)
            ? new CheckResult("Сервер", "Audience", CheckStatus.Skipped, "issuer отсутствует в discovery.")
            : new CheckResult("Сервер", "Audience", CheckStatus.Ok,
                $"issuer={issuer}; при ошибке invalid_client попробуйте OAuth:Audience={issuer}");
    }

    private async Task<JsonDocument?> LoadDiscoveryAsync(Uri tokenEndpoint, CancellationToken cancellationToken)
    {
        // token_endpoint обычно вида https://host/realms/<realm>/protocol/openid-connect/token.
        // Discovery — по /realms/<realm>/.well-known/openid-configuration для Keycloak
        // и по /.well-known/openid-configuration для FAM.
        var origin = new Uri(tokenEndpoint.GetLeftPart(UriPartial.Authority));

        var candidates = new[]
        {
            new Uri(origin, "/.well-known/openid-configuration"),
            new Uri(origin, tokenEndpoint.AbsolutePath.Replace(
                "/protocol/openid-connect/token",
                "/.well-known/openid-configuration",
                StringComparison.OrdinalIgnoreCase))
        };

        using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };

        foreach (var candidate in candidates.Distinct())
        {
            try
            {
                using var response = await http.GetAsync(candidate, cancellationToken).ConfigureAwait(false);
                if (!response.IsSuccessStatusCode)
                {
                    continue;
                }

                var json = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                return JsonDocument.Parse(json);
            }
            catch (HttpRequestException)
            {
                // Пробуем следующий кандидат: OIDC-провайдеры разворачивают discovery по-разному.
            }
        }

        return null;
    }

    private static bool TryGetStringArray(JsonElement element, string name, out string[] values)
    {
        values = Array.Empty<string>();

        if (element.ValueKind != JsonValueKind.Object
            || !element.TryGetProperty(name, out var array)
            || array.ValueKind != JsonValueKind.Array)
        {
            return false;
        }

        values = array.EnumerateArray()
            .Where(item => item.ValueKind == JsonValueKind.String)
            .Select(item => item.GetString() ?? string.Empty)
            .ToArray();

        return values.Length > 0;
    }
}