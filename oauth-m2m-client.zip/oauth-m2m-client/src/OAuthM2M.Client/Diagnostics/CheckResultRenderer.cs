using System.Text;

namespace OAuthM2M.Client.Diagnostics;

/// <summary>
/// Печатает результаты проверок в цвете. Группирует по категории, даёт итог внизу.
/// Зачем: preflight должен быть читаемым «с одного взгляда» в терминале и в CI-логе.
/// </summary>
public static class CheckResultRenderer
{
    public static void Render(IReadOnlyList<CheckResult> results, TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(results);

        var failed = 0;
        var warnings = 0;

        foreach (var group in results.GroupBy(result => result.Category))
        {
            output.WriteLine(AnsiConsole.Bold(group.Key));

            foreach (var result in group)
            {
                var statusBadge = AnsiConsole.StatusBadge(result.Status);
                output.WriteLine($"  {statusBadge} {result.Name}: {result.Detail}");

                if (!string.IsNullOrWhiteSpace(result.Hint))
                {
                    output.WriteLine($"         {AnsiConsole.Dim("→ " + result.Hint)}");
                }

                switch (result.Status)
                {
                    case CheckStatus.Failed:
                        failed++;
                        break;
                    case CheckStatus.Warning:
                        warnings++;
                        break;
                }
            }

            output.WriteLine();
        }

        var summary = new StringBuilder();
        if (failed == 0 && warnings == 0)
        {
            summary.Append(AnsiConsole.Green("Всё в порядке"));
        }
        else
        {
            if (failed > 0)
            {
                summary.Append(AnsiConsole.Red($"Ошибок: {failed}"));
            }

            if (warnings > 0)
            {
                if (failed > 0)
                {
                    summary.Append(", ");
                }

                summary.Append(AnsiConsole.Yellow($"предупреждений: {warnings}"));
            }
        }

        output.WriteLine(summary.ToString());
    }
}