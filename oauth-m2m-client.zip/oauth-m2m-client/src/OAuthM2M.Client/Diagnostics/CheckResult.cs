namespace OAuthM2M.Client.Diagnostics;

/// <summary>Результат одной проверки preflight/doctor.</summary>
public enum CheckStatus
{
    Ok,
    Warning,
    Failed,
    Skipped
}

/// <param name="Category">Группа проверки: «Конфигурация», «Сервер», «Ключ» и т. п.</param>
/// <param name="Name">Короткое имя проверки.</param>
/// <param name="Status">Результат.</param>
/// <param name="Detail">Деталь: что проверено, какие значения.</param>
/// <param name="Hint">Что делать при Warning/Failed (может быть пустым).</param>
public sealed record CheckResult(
    string Category,
    string Name,
    CheckStatus Status,
    string Detail,
    string? Hint = null);