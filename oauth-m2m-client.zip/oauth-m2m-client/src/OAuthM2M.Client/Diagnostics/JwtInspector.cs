using System.Text.Json;
using Microsoft.IdentityModel.Tokens;

namespace OAuthM2M.Client.Diagnostics;

/// <summary>
/// Разбирает JWT без проверки подписи — только для отладки.
/// Зачем: когда <c>invalid_client</c>, первым делом смотрят, что реально в заголовке (kid/alg)
/// и payload (aud/iss/exp). Делать это на jwt.io в проде — плохо; команда <c>assertion --inspect</c>
/// выводит claims локально.
/// </summary>
public static class JwtInspector
{
    public static bool TryInspect(string? token, out InspectedJwt? inspected)
    {
        inspected = null;

        if (string.IsNullOrWhiteSpace(token))
        {
            return false;
        }

        var parts = token.Split('.');
        if (parts.Length < 2)
        {
            return false;
        }

        try
        {
            using var headerDoc = JsonDocument.Parse(Base64UrlEncoder.Decode(parts[0]));
            using var payloadDoc = JsonDocument.Parse(Base64UrlEncoder.Decode(parts[1]));
            inspected = new InspectedJwt(headerDoc.RootElement.Clone(), payloadDoc.RootElement.Clone());
            return true;
        }
        catch (FormatException)
        {
            return false;
        }
        catch (JsonException)
        {
            return false;
        }
    }

    public static string? GetString(JsonElement element, string name) =>
        element.ValueKind == JsonValueKind.Object
        && element.TryGetProperty(name, out var value)
        && value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;

    public static bool TryGetUnixTime(JsonElement element, string name, out DateTimeOffset moment)
    {
        moment = default;

        if (element.ValueKind != JsonValueKind.Object
            || !element.TryGetProperty(name, out var value)
            || value.ValueKind != JsonValueKind.Number
            || !value.TryGetInt64(out var seconds))
        {
            return false;
        }

        moment = DateTimeOffset.FromUnixTimeSeconds(seconds);
        return true;
    }

    /// <summary>Для строк/массивов/чисел даёт компактное человекочитаемое значение.</summary>
    public static string Format(JsonElement element) => element.ValueKind switch
    {
        JsonValueKind.Array => string.Join(", ", element.EnumerateArray().Select(Format)),
        JsonValueKind.String => element.GetString() ?? string.Empty,
        _ => element.GetRawText()
    };
}

/// <param name="Header">Разобранный JOSE-заголовок.</param>
/// <param name="Payload">Разобранные claims.</param>
public sealed record InspectedJwt(JsonElement Header, JsonElement Payload);